(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_756b85fa._.js",
  "static/chunks/node_modules_react_1cad9b0b._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
  "static/chunks/node_modules_react-dom_f14d0471._.js",
  "static/chunks/node_modules_axios_lib_9aa2336a._.js",
  "static/chunks/node_modules_ed95c6d7._.js",
  "static/chunks/[root-of-the-server]__069a3384._.js",
  "static/chunks/_80f77ce5._.css"
],
    source: "entry"
});
