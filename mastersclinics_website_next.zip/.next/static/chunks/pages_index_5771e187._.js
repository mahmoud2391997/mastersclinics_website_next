(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__a4ab0c14._.js",
  "static/chunks/node_modules_next_0085ff26._.js",
  "static/chunks/node_modules_react_1cad9b0b._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
  "static/chunks/node_modules_react-dom_f14d0471._.js",
  "static/chunks/node_modules_@mui_system_93e0f7bc._.js",
  "static/chunks/node_modules_framer-motion_dist_es_14aab0e3._.js",
  "static/chunks/node_modules_motion-dom_dist_es_7471bf7b._.js",
  "static/chunks/node_modules_axios_lib_9aa2336a._.js",
  "static/chunks/node_modules_swiper_1e7dbd3e._.js",
  "static/chunks/node_modules_react-slick_lib_e66a6002._.js",
  "static/chunks/node_modules_43fe0c0e._.js",
  "static/chunks/node_modules_59bed48c._.css"
],
    source: "entry"
});
