(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/helpers/images/about.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/about.555f2f87.jpg");}}),
"[project]/helpers/images/about.jpg.mjs { IMAGE => \"[project]/helpers/images/about.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$about$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/about.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$about$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 1210,
    height: 644,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAPUlEQVR42nXMywkAMQgAUfsvQvGDogUIyha3SQGZ64OB7xHMTGa6u4gQkZmpanfD7lZVRBxAxGPMfOG1+gESUULWGAYf/wAAAABJRU5ErkJggg==",
    blurWidth: 8,
    blurHeight: 4
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/doctors/1.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/1.f8227211.jpg");}}),
"[project]/helpers/images/doctors/1.jpg.mjs { IMAGE => \"[project]/helpers/images/doctors/1.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$doctors$2f$1$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/doctors/1.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$doctors$2f$1$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 70,
    height: 70,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAATklEQVR42pWOMQrAMAgA/T8kBRc3fYKjin1cTaRjhtwghwcivAfgGDLTzNw9Imq21xLKEHGMMeckomejqlBdRKp1YObyFXITP+3r1PVXH3jKhl83GOsLAAAAAElFTkSuQmCC",
    blurWidth: 8,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/doctors/2.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/2.f8227211.jpg");}}),
"[project]/helpers/images/doctors/2.jpg.mjs { IMAGE => \"[project]/helpers/images/doctors/2.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$doctors$2f$2$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/doctors/2.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$doctors$2f$2$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 70,
    height: 70,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAATklEQVR42pWOMQrAMAgA/T8kBRc3fYKjin1cTaRjhtwghwcivAfgGDLTzNw9Imq21xLKEHGMMeckomejqlBdRKp1YObyFXITP+3r1PVXH3jKhl83GOsLAAAAAElFTkSuQmCC",
    blurWidth: 8,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/doctors/3.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/3.f8227211.jpg");}}),
"[project]/helpers/images/doctors/3.jpg.mjs { IMAGE => \"[project]/helpers/images/doctors/3.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$doctors$2f$3$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/doctors/3.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$doctors$2f$3$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 70,
    height: 70,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAATklEQVR42pWOMQrAMAgA/T8kBRc3fYKjin1cTaRjhtwghwcivAfgGDLTzNw9Imq21xLKEHGMMeckomejqlBdRKp1YObyFXITP+3r1PVXH3jKhl83GOsLAAAAAElFTkSuQmCC",
    blurWidth: 8,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/doctors/4.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/4.f8227211.jpg");}}),
"[project]/helpers/images/doctors/4.jpg.mjs { IMAGE => \"[project]/helpers/images/doctors/4.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$doctors$2f$4$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/doctors/4.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$doctors$2f$4$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 70,
    height: 70,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAATklEQVR42pWOMQrAMAgA/T8kBRc3fYKjin1cTaRjhtwghwcivAfgGDLTzNw9Imq21xLKEHGMMeckomejqlBdRKp1YObyFXITP+3r1PVXH3jKhl83GOsLAAAAAElFTkSuQmCC",
    blurWidth: 8,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/signeture.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/signeture.21105556.png");}}),
"[project]/helpers/images/signeture.png.mjs { IMAGE => \"[project]/helpers/images/signeture.png (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$signeture$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/signeture.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$signeture$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 277,
    height: 58,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAAQklEQVR42iWKSwqAMBDFMq8L/7alKroQQRC8/wk70EUWIQFNJ4oP1kWsz2i9CeV3T84CGnefjsZ8YUNB6SXkz9tWAUi8AlfYdRMPAAAAAElFTkSuQmCC",
    blurWidth: 8,
    blurHeight: 2
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/slider/2.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/2.169af324.png");}}),
"[project]/helpers/images/slider/2.png.mjs { IMAGE => \"[project]/helpers/images/slider/2.png (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$slider$2f$2$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/slider/2.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$slider$2f$2$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 784,
    height: 1000,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAIAAABVpBlvAAAANklEQVR42p3MoREAMAhDUfZfg4MDG5GYDldEXU2vcXni27pmb0QyIjKzqtwdgEmaP9rdh37zG60MZ0sL2nmJAAAAAElFTkSuQmCC",
    blurWidth: 6,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/service-single/1.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/1.2743e616.jpg");}}),
"[project]/helpers/images/service-single/1.jpg.mjs { IMAGE => \"[project]/helpers/images/service-single/1.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$1$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/service-single/1.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$1$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 897,
    height: 521,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAASklEQVR42nWNOQ4AIQwDeT+Iio5P5FakZB+3gZ6pLMsjt+9By0wiQkQAwAszR0Rz9zFG732tVWHOufdW1WPURETMrNTyqj3G6+MHT9FTPqn8qQ0AAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 5
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/service-single/2.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/2.2743e616.jpg");}}),
"[project]/helpers/images/service-single/2.jpg.mjs { IMAGE => \"[project]/helpers/images/service-single/2.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$2$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/service-single/2.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$2$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 897,
    height: 521,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAASklEQVR42nWNOQ4AIQwDeT+Iio5P5FakZB+3gZ6pLMsjt+9By0wiQkQAwAszR0Rz9zFG732tVWHOufdW1WPURETMrNTyqj3G6+MHT9FTPqn8qQ0AAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 5
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/service-single/3.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/3.2743e616.jpg");}}),
"[project]/helpers/images/service-single/3.jpg.mjs { IMAGE => \"[project]/helpers/images/service-single/3.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$3$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/service-single/3.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$3$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 897,
    height: 521,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAASklEQVR42nWNOQ4AIQwDeT+Iio5P5FakZB+3gZ6pLMsjt+9By0wiQkQAwAszR0Rz9zFG732tVWHOufdW1WPURETMrNTyqj3G6+MHT9FTPqn8qQ0AAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 5
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/service-single/4.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/4.2743e616.jpg");}}),
"[project]/helpers/images/service-single/4.jpg.mjs { IMAGE => \"[project]/helpers/images/service-single/4.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$4$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/service-single/4.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$4$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 897,
    height: 521,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAASklEQVR42nWNOQ4AIQwDeT+Iio5P5FakZB+3gZ6pLMsjt+9By0wiQkQAwAszR0Rz9zFG732tVWHOufdW1WPURETMrNTyqj3G6+MHT9FTPqn8qQ0AAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 5
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/service-single/5.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/5.2743e616.jpg");}}),
"[project]/helpers/images/service-single/5.jpg.mjs { IMAGE => \"[project]/helpers/images/service-single/5.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$5$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/service-single/5.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$5$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 897,
    height: 521,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAASklEQVR42nWNOQ4AIQwDeT+Iio5P5FakZB+3gZ6pLMsjt+9By0wiQkQAwAszR0Rz9zFG732tVWHOufdW1WPURETMrNTyqj3G6+MHT9FTPqn8qQ0AAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 5
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/service-single/6.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/6.2743e616.jpg");}}),
"[project]/helpers/images/service-single/6.jpg.mjs { IMAGE => \"[project]/helpers/images/service-single/6.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$6$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/service-single/6.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$6$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 897,
    height: 521,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAASklEQVR42nWNOQ4AIQwDeT+Iio5P5FakZB+3gZ6pLMsjt+9By0wiQkQAwAszR0Rz9zFG732tVWHOufdW1WPURETMrNTyqj3G6+MHT9FTPqn8qQ0AAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 5
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/project/1.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/1.2c49641e.jpg");}}),
"[project]/helpers/images/project/1.jpg.mjs { IMAGE => \"[project]/helpers/images/project/1.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$1$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/project/1.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$1$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 415,
    height: 550,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAIAAABVpBlvAAAANUlEQVR42p3MIQ4AMAgEQf7/CnIIsORO9nFNmrqahpUj1taT/ZGkzIwIAO7e3UayqnC6NN1vk9pm9AB6D6QAAAAASUVORK5CYII=",
    blurWidth: 6,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/project/2.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/2.2c49641e.jpg");}}),
"[project]/helpers/images/project/2.jpg.mjs { IMAGE => \"[project]/helpers/images/project/2.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$2$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/project/2.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$2$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 415,
    height: 550,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAIAAABVpBlvAAAANUlEQVR42p3MIQ4AMAgEQf7/CnIIsORO9nFNmrqahpUj1taT/ZGkzIwIAO7e3UayqnC6NN1vk9pm9AB6D6QAAAAASUVORK5CYII=",
    blurWidth: 6,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/project/3.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/3.2c49641e.jpg");}}),
"[project]/helpers/images/project/3.jpg.mjs { IMAGE => \"[project]/helpers/images/project/3.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$3$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/project/3.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$3$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 415,
    height: 550,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAIAAABVpBlvAAAANUlEQVR42p3MIQ4AMAgEQf7/CnIIsORO9nFNmrqahpUj1taT/ZGkzIwIAO7e3UayqnC6NN1vk9pm9AB6D6QAAAAASUVORK5CYII=",
    blurWidth: 6,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/project/4.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/4.2c49641e.jpg");}}),
"[project]/helpers/images/project/4.jpg.mjs { IMAGE => \"[project]/helpers/images/project/4.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$4$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/project/4.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$4$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 415,
    height: 550,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAIAAABVpBlvAAAANUlEQVR42p3MIQ4AMAgEQf7/CnIIsORO9nFNmrqahpUj1taT/ZGkzIwIAO7e3UayqnC6NN1vk9pm9AB6D6QAAAAASUVORK5CYII=",
    blurWidth: 6,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/project/5.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/5.2c49641e.jpg");}}),
"[project]/helpers/images/project/5.jpg.mjs { IMAGE => \"[project]/helpers/images/project/5.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$5$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/project/5.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$5$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 415,
    height: 550,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAIAAABVpBlvAAAANUlEQVR42p3MIQ4AMAgEQf7/CnIIsORO9nFNmrqahpUj1taT/ZGkzIwIAO7e3UayqnC6NN1vk9pm9AB6D6QAAAAASUVORK5CYII=",
    blurWidth: 6,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/project/6.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/6.2c49641e.jpg");}}),
"[project]/helpers/images/project/6.jpg.mjs { IMAGE => \"[project]/helpers/images/project/6.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$6$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/project/6.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$6$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 415,
    height: 550,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAIAAABVpBlvAAAANUlEQVR42p3MIQ4AMAgEQf7/CnIIsORO9nFNmrqahpUj1taT/ZGkzIwIAO7e3UayqnC6NN1vk9pm9AB6D6QAAAAASUVORK5CYII=",
    blurWidth: 6,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/project-single/1.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/1.3c68feac.jpg");}}),
"[project]/helpers/images/project-single/1.jpg.mjs { IMAGE => \"[project]/helpers/images/project-single/1.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$1$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/project-single/1.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$1$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 1326,
    height: 700,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAO0lEQVR42nWMsQkAMAgEf/8hRC0EsVfQDBchdb54OA4O5zN0t7urqoi8Z+aqwsxExDIRrTCzFZmJX+oCDmpCytE13eIAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 4
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/project-single/2.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/2.3c68feac.jpg");}}),
"[project]/helpers/images/project-single/2.jpg.mjs { IMAGE => \"[project]/helpers/images/project-single/2.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$2$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/project-single/2.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$2$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 1326,
    height: 700,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAO0lEQVR42nWMsQkAMAgEf/8hRC0EsVfQDBchdb54OA4O5zN0t7urqoi8Z+aqwsxExDIRrTCzFZmJX+oCDmpCytE13eIAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 4
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/project-single/3.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/3.3c68feac.jpg");}}),
"[project]/helpers/images/project-single/3.jpg.mjs { IMAGE => \"[project]/helpers/images/project-single/3.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$3$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/project-single/3.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$3$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 1326,
    height: 700,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAO0lEQVR42nWMsQkAMAgEf/8hRC0EsVfQDBchdb54OA4O5zN0t7urqoi8Z+aqwsxExDIRrTCzFZmJX+oCDmpCytE13eIAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 4
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/project-single/4.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/4.3c68feac.jpg");}}),
"[project]/helpers/images/project-single/4.jpg.mjs { IMAGE => \"[project]/helpers/images/project-single/4.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$4$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/project-single/4.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$4$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 1326,
    height: 700,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAO0lEQVR42nWMsQkAMAgEf/8hRC0EsVfQDBchdb54OA4O5zN0t7urqoi8Z+aqwsxExDIRrTCzFZmJX+oCDmpCytE13eIAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 4
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/project-single/5.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/5.3c68feac.jpg");}}),
"[project]/helpers/images/project-single/5.jpg.mjs { IMAGE => \"[project]/helpers/images/project-single/5.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$5$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/project-single/5.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$5$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 1326,
    height: 700,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAO0lEQVR42nWMsQkAMAgEf/8hRC0EsVfQDBchdb54OA4O5zN0t7urqoi8Z+aqwsxExDIRrTCzFZmJX+oCDmpCytE13eIAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 4
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/project-single/6.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/6.3c68feac.jpg");}}),
"[project]/helpers/images/project-single/6.jpg.mjs { IMAGE => \"[project]/helpers/images/project-single/6.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$6$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/project-single/6.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$6$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 1326,
    height: 700,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAO0lEQVR42nWMsQkAMAgEf/8hRC0EsVfQDBchdb54OA4O5zN0t7urqoi8Z+aqwsxExDIRrTCzFZmJX+oCDmpCytE13eIAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 4
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/testimonial/1.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/1.331685b1.jpg");}}),
"[project]/helpers/images/testimonial/1.jpg.mjs { IMAGE => \"[project]/helpers/images/testimonial/1.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$testimonial$2f$1$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/testimonial/1.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$testimonial$2f$1$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 80,
    height: 80,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAATUlEQVR42oXNMQ7AIAhAUe/u1kEC3AQSQmkPV9G4tfUNxvATKPeH8hfc/VzmP4OZHUNrrb+1VkQUkQwA0KdENBszq2quiohriWF3/NUDMhSFq9sJa0EAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/testimonial/2.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/2.331685b1.jpg");}}),
"[project]/helpers/images/testimonial/2.jpg.mjs { IMAGE => \"[project]/helpers/images/testimonial/2.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$testimonial$2f$2$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/testimonial/2.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$testimonial$2f$2$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 80,
    height: 80,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAATUlEQVR42oXNMQ7AIAhAUe/u1kEC3AQSQmkPV9G4tfUNxvATKPeH8hfc/VzmP4OZHUNrrb+1VkQUkQwA0KdENBszq2quiohriWF3/NUDMhSFq9sJa0EAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/testimonial/3.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/3.331685b1.jpg");}}),
"[project]/helpers/images/testimonial/3.jpg.mjs { IMAGE => \"[project]/helpers/images/testimonial/3.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$testimonial$2f$3$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/testimonial/3.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$testimonial$2f$3$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 80,
    height: 80,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAATUlEQVR42oXNMQ7AIAhAUe/u1kEC3AQSQmkPV9G4tfUNxvATKPeH8hfc/VzmP4OZHUNrrb+1VkQUkQwA0KdENBszq2quiohriWF3/NUDMhSFq9sJa0EAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/team/1.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/1.0392cd80.png");}}),
"[project]/helpers/images/team/1.png.mjs { IMAGE => \"[project]/helpers/images/team/1.png (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$1$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/team/1.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$1$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 364,
    height: 547,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAL0lEQVR42pWMsQkAMBAC3X8P+V6xy3CRdKlCDhSuOawbvNz2zJDsS0LHQz0JPnsbi4VWKQCZhPkAAAAASUVORK5CYII=",
    blurWidth: 5,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/team/2.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/2.0392cd80.png");}}),
"[project]/helpers/images/team/2.png.mjs { IMAGE => \"[project]/helpers/images/team/2.png (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$2$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/team/2.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$2$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 364,
    height: 547,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAL0lEQVR42pWMsQkAMBAC3X8P+V6xy3CRdKlCDhSuOawbvNz2zJDsS0LHQz0JPnsbi4VWKQCZhPkAAAAASUVORK5CYII=",
    blurWidth: 5,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/team/3.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/3.0392cd80.png");}}),
"[project]/helpers/images/team/3.png.mjs { IMAGE => \"[project]/helpers/images/team/3.png (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$3$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/team/3.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$3$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 364,
    height: 547,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAL0lEQVR42pWMsQkAMBAC3X8P+V6xy3CRdKlCDhSuOawbvNz2zJDsS0LHQz0JPnsbi4VWKQCZhPkAAAAASUVORK5CYII=",
    blurWidth: 5,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/team/4.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/4.9941eaa9.png");}}),
"[project]/helpers/images/team/4.png.mjs { IMAGE => \"[project]/helpers/images/team/4.png (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$4$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/team/4.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$4$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 370,
    height: 520,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAIAAABVpBlvAAAAM0lEQVR42p3MMQoAIAxD0d7/HJFC14RMHk4UnFykb/zDj/mIv2Q7MwGMQ9JOVYWLZHT3C60qZ0smO5jfAAAAAElFTkSuQmCC",
    blurWidth: 6,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/team/5.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/5.859d9202.png");}}),
"[project]/helpers/images/team/5.png.mjs { IMAGE => \"[project]/helpers/images/team/5.png (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$5$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/team/5.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$5$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 387,
    height: 557,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAIAAABVpBlvAAAAOElEQVR42p2MuQkAMAwDvf8Y/sC1BWoyXJw6TYgKwV1xsq7JmwKgqhHh7vPdfZSZVdVwZpKU3/wGpj1nPHsrOOgAAAAASUVORK5CYII=",
    blurWidth: 6,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/team/6.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/6.a4c2b897.png");}}),
"[project]/helpers/images/team/6.png.mjs { IMAGE => \"[project]/helpers/images/team/6.png (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$6$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/team/6.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$6$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 396,
    height: 592,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAALklEQVR42pXMsQ0AIAwDwew/h+0B7JbhEIiGKsp313ytv+qcBIAkkrafeTse/jaFJVYOkrsZngAAAABJRU5ErkJggg==",
    blurWidth: 5,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/team-single/1.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/1.f3486d3e.jpg");}}),
"[project]/helpers/images/team-single/1.jpg.mjs { IMAGE => \"[project]/helpers/images/team-single/1.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$1$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/team-single/1.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$1$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 580,
    height: 920,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAK0lEQVR42pXMoQ0AMAwDwew/h2Vzm3a44iggyrMjX69Xm5MAICnJ9vDx9wGIqVYd9AHtbgAAAABJRU5ErkJggg==",
    blurWidth: 5,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/team-single/2.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/2.f3486d3e.jpg");}}),
"[project]/helpers/images/team-single/2.jpg.mjs { IMAGE => \"[project]/helpers/images/team-single/2.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$2$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/team-single/2.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$2$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 580,
    height: 920,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAK0lEQVR42pXMoQ0AMAwDwew/h2Vzm3a44iggyrMjX69Xm5MAICnJ9vDx9wGIqVYd9AHtbgAAAABJRU5ErkJggg==",
    blurWidth: 5,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/team-single/3.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/3.f3486d3e.jpg");}}),
"[project]/helpers/images/team-single/3.jpg.mjs { IMAGE => \"[project]/helpers/images/team-single/3.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$3$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/team-single/3.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$3$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 580,
    height: 920,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAK0lEQVR42pXMoQ0AMAwDwew/h2Vzm3a44iggyrMjX69Xm5MAICnJ9vDx9wGIqVYd9AHtbgAAAABJRU5ErkJggg==",
    blurWidth: 5,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/team-single/4.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/4.f3486d3e.jpg");}}),
"[project]/helpers/images/team-single/4.jpg.mjs { IMAGE => \"[project]/helpers/images/team-single/4.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$4$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/team-single/4.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$4$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 580,
    height: 920,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAK0lEQVR42pXMoQ0AMAwDwew/h2Vzm3a44iggyrMjX69Xm5MAICnJ9vDx9wGIqVYd9AHtbgAAAABJRU5ErkJggg==",
    blurWidth: 5,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/team-single/5.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/5.f3486d3e.jpg");}}),
"[project]/helpers/images/team-single/5.jpg.mjs { IMAGE => \"[project]/helpers/images/team-single/5.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$5$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/team-single/5.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$5$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 580,
    height: 920,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAK0lEQVR42pXMoQ0AMAwDwew/h2Vzm3a44iggyrMjX69Xm5MAICnJ9vDx9wGIqVYd9AHtbgAAAABJRU5ErkJggg==",
    blurWidth: 5,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/team-single/6.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/6.f3486d3e.jpg");}}),
"[project]/helpers/images/team-single/6.jpg.mjs { IMAGE => \"[project]/helpers/images/team-single/6.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$6$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/team-single/6.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$6$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 580,
    height: 920,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAK0lEQVR42pXMoQ0AMAwDwew/h2Vzm3a44iggyrMjX69Xm5MAICnJ9vDx9wGIqVYd9AHtbgAAAABJRU5ErkJggg==",
    blurWidth: 5,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/blog/img-1.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/img-1.f68debd3.jpg");}}),
"[project]/helpers/images/blog/img-1.jpg.mjs { IMAGE => \"[project]/helpers/images/blog/img-1.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2f$img$2d$1$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/blog/img-1.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2f$img$2d$1$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 415,
    height: 340,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAIAAAC6O5sJAAAARUlEQVR42pXNsQnAUAgEUMe30dY1DBFBzXA57BP4rxDhlKPnA/0F97oWFnfvbspMVTUzZhYRXshoZnAVEb7whFlVdFz+AnTodkg8deBRAAAAAElFTkSuQmCC",
    blurWidth: 8,
    blurHeight: 7
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/blog/img-2.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/img-2.f68debd3.jpg");}}),
"[project]/helpers/images/blog/img-2.jpg.mjs { IMAGE => \"[project]/helpers/images/blog/img-2.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2f$img$2d$2$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/blog/img-2.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2f$img$2d$2$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 415,
    height: 340,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAIAAAC6O5sJAAAARUlEQVR42pXNsQnAUAgEUMe30dY1DBFBzXA57BP4rxDhlKPnA/0F97oWFnfvbspMVTUzZhYRXshoZnAVEb7whFlVdFz+AnTodkg8deBRAAAAAElFTkSuQmCC",
    blurWidth: 8,
    blurHeight: 7
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/blog/img-3.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/img-3.f68debd3.jpg");}}),
"[project]/helpers/images/blog/img-3.jpg.mjs { IMAGE => \"[project]/helpers/images/blog/img-3.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2f$img$2d$3$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/blog/img-3.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2f$img$2d$3$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 415,
    height: 340,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAIAAAC6O5sJAAAARUlEQVR42pXNsQnAUAgEUMe30dY1DBFBzXA57BP4rxDhlKPnA/0F97oWFnfvbspMVTUzZhYRXshoZnAVEb7whFlVdFz+AnTodkg8deBRAAAAAElFTkSuQmCC",
    blurWidth: 8,
    blurHeight: 7
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/blog-details/1.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/1.bbe63256.jpg");}}),
"[project]/helpers/images/blog-details/1.jpg.mjs { IMAGE => \"[project]/helpers/images/blog-details/1.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$1$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/blog-details/1.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$1$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 419,
    height: 285,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAASUlEQVR42nWNOwrAMAxDff4QCAQvvobrD9g9XNUhYwQaxOMhei8hNCLc3cyek6qizGRmEZlz7r3HGGstMOpuGMCQsFUV6m/cPj53RlPFkh0zygAAAABJRU5ErkJggg==",
    blurWidth: 8,
    blurHeight: 5
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/blog-details/2.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/2.bbe63256.jpg");}}),
"[project]/helpers/images/blog-details/2.jpg.mjs { IMAGE => \"[project]/helpers/images/blog-details/2.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$2$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/blog-details/2.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$2$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 419,
    height: 285,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAASUlEQVR42nWNOwrAMAxDff4QCAQvvobrD9g9XNUhYwQaxOMhei8hNCLc3cyek6qizGRmEZlz7r3HGGstMOpuGMCQsFUV6m/cPj53RlPFkh0zygAAAABJRU5ErkJggg==",
    blurWidth: 8,
    blurHeight: 5
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/blog-details/3.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/3.bbe63256.jpg");}}),
"[project]/helpers/images/blog-details/3.jpg.mjs { IMAGE => \"[project]/helpers/images/blog-details/3.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$3$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/blog-details/3.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$3$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 419,
    height: 285,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAASUlEQVR42nWNOwrAMAxDff4QCAQvvobrD9g9XNUhYwQaxOMhei8hNCLc3cyek6qizGRmEZlz7r3HGGstMOpuGMCQsFUV6m/cPj53RlPFkh0zygAAAABJRU5ErkJggg==",
    blurWidth: 8,
    blurHeight: 5
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/logo.svg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/logo.d83ade23.svg");}}),
"[project]/helpers/images/logo.svg.mjs { IMAGE => \"[project]/helpers/images/logo.svg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2e$svg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/logo.svg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2e$svg__$28$static__in__ecmascript$29$__["default"],
    width: 223,
    height: 60,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/logo-2.svg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/logo-2.95b25a07.svg");}}),
"[project]/helpers/images/logo-2.svg.mjs { IMAGE => \"[project]/helpers/images/logo-2.svg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/logo-2.svg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$29$__["default"],
    width: 223,
    height: 60,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/slider/slide-1.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/slide-1.d7b414cc.jpg");}}),
"[project]/helpers/images/slider/slide-1.jpg.mjs { IMAGE => \"[project]/helpers/images/slider/slide-1.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$slider$2f$slide$2d$1$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/slider/slide-1.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$slider$2f$slide$2d$1$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 1920,
    height: 991,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAO0lEQVR42nWMuQ0AQAjD2H8GxFMgUdCDxA13WYCUsWV6x2h3M9PMVFVEmDkiupsAq8rd8YLBgDczdKU+CUtCuzYSW5QAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 4
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/slider/slide-2.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/slide-2.d7b414cc.jpg");}}),
"[project]/helpers/images/slider/slide-2.jpg.mjs { IMAGE => \"[project]/helpers/images/slider/slide-2.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$slider$2f$slide$2d$2$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/slider/slide-2.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$slider$2f$slide$2d$2$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 1920,
    height: 991,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAO0lEQVR42nWMuQ0AQAjD2H8GxFMgUdCDxA13WYCUsWV6x2h3M9PMVFVEmDkiupsAq8rd8YLBgDczdKU+CUtCuzYSW5QAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 4
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/slider/slide-3.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/slide-3.d7b414cc.jpg");}}),
"[project]/helpers/images/slider/slide-3.jpg.mjs { IMAGE => \"[project]/helpers/images/slider/slide-3.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$slider$2f$slide$2d$3$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/slider/slide-3.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$slider$2f$slide$2d$3$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 1920,
    height: 991,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAIAAAA8r+mnAAAAO0lEQVR42nWMuQ0AQAjD2H8GxFMgUdCDxA13WYCUsWV6x2h3M9PMVFVEmDkiupsAq8rd8YLBgDczdKU+CUtCuzYSW5QAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 4
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/cta-2.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/cta-2.51d2fffd.png");}}),
"[project]/helpers/images/cta-2.png.mjs { IMAGE => \"[project]/helpers/images/cta-2.png (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$cta$2d$2$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/cta-2.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$cta$2d$2$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 538,
    height: 535,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAP0lEQVR42q3NuQ0AMQhEUfovAFawQBcckouz5dyBJb9wJvgwDuD+qCoz+zYR+bfMhO52d0QkojUxs6pGBLyLTy6eiBvXlLFVAAAAAElFTkSuQmCC",
    blurWidth: 8,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/team-single/arrow.svg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/arrow.20fcd769.svg");}}),
"[project]/helpers/images/team-single/arrow.svg.mjs { IMAGE => \"[project]/helpers/images/team-single/arrow.svg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$arrow$2e$svg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/team-single/arrow.svg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$arrow$2e$svg__$28$static__in__ecmascript$29$__["default"],
    width: 25,
    height: 25,
    blurDataURL: null,
    blurWidth: 0,
    blurHeight: 0
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/checkout/img-1.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/img-1.e710979f.png");}}),
"[project]/helpers/images/checkout/img-1.png.mjs { IMAGE => \"[project]/helpers/images/checkout/img-1.png (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$checkout$2f$img$2d$1$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/checkout/img-1.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$checkout$2f$img$2d$1$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 58,
    height: 18,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAATUlEQVR42gFCAL3/ADs2JE1IUUeJAT1wjwA+c5MAPnWWADFZbQA6aYoAPXGVAAAMFRcGSHyqAC9WawA7bYcAO22EAER8ngBDe6cARoCsS9wSqS7GCAwAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 2
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/checkout/img-2.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/img-2.8f323282.png");}}),
"[project]/helpers/images/checkout/img-2.png.mjs { IMAGE => \"[project]/helpers/images/checkout/img-2.png (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$checkout$2f$img$2d$2$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/checkout/img-2.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$checkout$2f$img$2d$2$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 100,
    height: 59,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAYAAAB4ka1VAAAAkElEQVR42lWNoQ7CMBRFb/sKWboWeFkncARBMsWHYJibIEEjEDj4AZA4JJvAwDdgScDh0f2OgWDLdsxNbk5ygD8KoO5vAgXVIRCahIBeE+2OPVFcF7I4pGJrA+hamBib3OeZfy+z0p/S8pPP/HQUJrXAknjPUX4bx8/HJnpdVnx2VnIrYwETC7hhH26gYar/C3wbGHL55o86AAAAAElFTkSuQmCC",
    blurWidth: 8,
    blurHeight: 5
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/checkout/img-3.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/img-3.6f86c956.png");}}),
"[project]/helpers/images/checkout/img-3.png.mjs { IMAGE => \"[project]/helpers/images/checkout/img-3.png (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$checkout$2f$img$2d$3$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/checkout/img-3.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$checkout$2f$img$2d$3$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 59,
    height: 21,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAbklEQVR42gFjAJz/AE0TRpdIE0KHQBE7exkHGCkRBRAaOhE4YUEVQIE+FD6RAE4XS6lIF0eeUBlPvkwYTahGF0eVSRpMmkgaTK5EGknAAEUZR5ZKG026TRxRvUwdU7c/GUWUOxlChUIdS6k+HEi3BEQcYCWXMHEAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 3
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/instagram/1.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/1.ab286e6a.jpg");}}),
"[project]/helpers/images/instagram/1.jpg.mjs { IMAGE => \"[project]/helpers/images/instagram/1.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$1$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/instagram/1.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$1$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 112,
    height: 100,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAIAAAC6O5sJAAAAS0lEQVR42pVNMQ7AQAjy/8vlltsc/IJVY7SPK23nG44EQkIAujegbdDd7m5mqnp9gKkqAkWEmeecay3oGAPxO5WZEYES9G9jho7PH9cTd3c46LPFAAAAAElFTkSuQmCC",
    blurWidth: 8,
    blurHeight: 7
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/instagram/2.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/2.ab286e6a.jpg");}}),
"[project]/helpers/images/instagram/2.jpg.mjs { IMAGE => \"[project]/helpers/images/instagram/2.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$2$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/instagram/2.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$2$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 112,
    height: 100,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAIAAAC6O5sJAAAAS0lEQVR42pVNMQ7AQAjy/8vlltsc/IJVY7SPK23nG44EQkIAujegbdDd7m5mqnp9gKkqAkWEmeecay3oGAPxO5WZEYES9G9jho7PH9cTd3c46LPFAAAAAElFTkSuQmCC",
    blurWidth: 8,
    blurHeight: 7
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/instagram/3.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/3.ab286e6a.jpg");}}),
"[project]/helpers/images/instagram/3.jpg.mjs { IMAGE => \"[project]/helpers/images/instagram/3.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$3$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/instagram/3.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$3$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 112,
    height: 100,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAIAAAC6O5sJAAAAS0lEQVR42pVNMQ7AQAjy/8vlltsc/IJVY7SPK23nG44EQkIAujegbdDd7m5mqnp9gKkqAkWEmeecay3oGAPxO5WZEYES9G9jho7PH9cTd3c46LPFAAAAAElFTkSuQmCC",
    blurWidth: 8,
    blurHeight: 7
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/instagram/4.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/4.ab286e6a.jpg");}}),
"[project]/helpers/images/instagram/4.jpg.mjs { IMAGE => \"[project]/helpers/images/instagram/4.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$4$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/instagram/4.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$4$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 112,
    height: 100,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAIAAAC6O5sJAAAAS0lEQVR42pVNMQ7AQAjy/8vlltsc/IJVY7SPK23nG44EQkIAujegbdDd7m5mqnp9gKkqAkWEmeecay3oGAPxO5WZEYES9G9jho7PH9cTd3c46LPFAAAAAElFTkSuQmCC",
    blurWidth: 8,
    blurHeight: 7
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/instagram/5.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/5.ab286e6a.jpg");}}),
"[project]/helpers/images/instagram/5.jpg.mjs { IMAGE => \"[project]/helpers/images/instagram/5.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$5$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/instagram/5.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$5$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 112,
    height: 100,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAIAAAC6O5sJAAAAS0lEQVR42pVNMQ7AQAjy/8vlltsc/IJVY7SPK23nG44EQkIAujegbdDd7m5mqnp9gKkqAkWEmeecay3oGAPxO5WZEYES9G9jho7PH9cTd3c46LPFAAAAAElFTkSuQmCC",
    blurWidth: 8,
    blurHeight: 7
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/instagram/6.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/6.ab286e6a.jpg");}}),
"[project]/helpers/images/instagram/6.jpg.mjs { IMAGE => \"[project]/helpers/images/instagram/6.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$6$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/instagram/6.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$6$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 112,
    height: 100,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAIAAAC6O5sJAAAAS0lEQVR42pVNMQ7AQAjy/8vlltsc/IJVY7SPK23nG44EQkIAujegbdDd7m5mqnp9gKkqAkWEmeecay3oGAPxO5WZEYES9G9jho7PH9cTd3c46LPFAAAAAElFTkSuQmCC",
    blurWidth: 8,
    blurHeight: 7
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/service-single/img-1.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/img-1.6b47ab92.jpg");}}),
"[project]/helpers/images/service-single/img-1.jpg.mjs { IMAGE => \"[project]/helpers/images/service-single/img-1.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$img$2d$1$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/service-single/img-1.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$img$2d$1$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 433,
    height: 350,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAIAAABxZ0isAAAAPElEQVR42pWNywkAMAhDs/8IUj9DKCh0uEp79tB3CCTvEOwBjKKqzExEmFlV1yUikJm9vt6uk4jcHd8fB6W4ZSApmx4sAAAAAElFTkSuQmCC",
    blurWidth: 8,
    blurHeight: 6
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/service-single/img-2.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/img-2.6b47ab92.jpg");}}),
"[project]/helpers/images/service-single/img-2.jpg.mjs { IMAGE => \"[project]/helpers/images/service-single/img-2.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$img$2d$2$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/service-single/img-2.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$img$2d$2$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 433,
    height: 350,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAIAAABxZ0isAAAAPElEQVR42pWNywkAMAhDs/8IUj9DKCh0uEp79tB3CCTvEOwBjKKqzExEmFlV1yUikJm9vt6uk4jcHd8fB6W4ZSApmx4sAAAAAElFTkSuQmCC",
    blurWidth: 8,
    blurHeight: 6
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/blog/about-widget.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/about-widget.8b21702c.jpg");}}),
"[project]/helpers/images/blog/about-widget.jpg.mjs { IMAGE => \"[project]/helpers/images/blog/about-widget.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2f$about$2d$widget$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/blog/about-widget.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2f$about$2d$widget$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 200,
    height: 200,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAPklEQVR42q2NuwkAMAhE3X8Bv4hbiJDhYiBtioBXHMe94sF6BP5BVUUEIjKzmRFRd2ZeICKq2lcPdz9gTr4BOoOIPC2Xz9MAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/blog-details/comments-author/img-1.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/img-1.331685b1.jpg");}}),
"[project]/helpers/images/blog-details/comments-author/img-1.jpg.mjs { IMAGE => \"[project]/helpers/images/blog-details/comments-author/img-1.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$comments$2d$author$2f$img$2d$1$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/blog-details/comments-author/img-1.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$comments$2d$author$2f$img$2d$1$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 80,
    height: 80,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAATUlEQVR42oXNMQ7AIAhAUe/u1kEC3AQSQmkPV9G4tfUNxvATKPeH8hfc/VzmP4OZHUNrrb+1VkQUkQwA0KdENBszq2quiohriWF3/NUDMhSFq9sJa0EAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/blog-details/comments-author/img-2.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/img-2.331685b1.jpg");}}),
"[project]/helpers/images/blog-details/comments-author/img-2.jpg.mjs { IMAGE => \"[project]/helpers/images/blog-details/comments-author/img-2.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$comments$2d$author$2f$img$2d$2$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/blog-details/comments-author/img-2.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$comments$2d$author$2f$img$2d$2$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 80,
    height: 80,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAATUlEQVR42oXNMQ7AIAhAUe/u1kEC3AQSQmkPV9G4tfUNxvATKPeH8hfc/VzmP4OZHUNrrb+1VkQUkQwA0KdENBszq2quiohriWF3/NUDMhSFq9sJa0EAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/blog-details/comments-author/img-3.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/img-3.331685b1.jpg");}}),
"[project]/helpers/images/blog-details/comments-author/img-3.jpg.mjs { IMAGE => \"[project]/helpers/images/blog-details/comments-author/img-3.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$comments$2d$author$2f$img$2d$3$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/blog-details/comments-author/img-3.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$comments$2d$author$2f$img$2d$3$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 80,
    height: 80,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAATUlEQVR42oXNMQ7AIAhAUe/u1kEC3AQSQmkPV9G4tfUNxvATKPeH8hfc/VzmP4OZHUNrrb+1VkQUkQwA0KdENBszq2quiohriWF3/NUDMhSFq9sJa0EAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/blog-details/author.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/author.705ecc1f.jpg");}}),
"[project]/helpers/images/blog-details/author.jpg.mjs { IMAGE => \"[project]/helpers/images/blog-details/author.jpg (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$author$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/blog-details/author.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$author$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 120,
    height: 120,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAQUlEQVR42q3NMQoAMQhEUe/fiyyyiCCeQBEkh0tInyKQVw1M8WEcwP1RVapKRIj4b2tHBHS3u3+bmYkIM2cmvItPPo6ISzEAb4gAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 8
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/images/error-404.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/error-404.837cad6b.png");}}),
"[project]/helpers/images/error-404.png.mjs { IMAGE => \"[project]/helpers/images/error-404.png (static in ecmascript)\" } [client] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$error$2d$404$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/error-404.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$error$2d$404$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 700,
    height: 500,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAIAAABxZ0isAAAAPklEQVR42pWNMQoAMAgD/f8sVgVnX+Cg9HG13R16QwhcILAHYBSZaWZExMwi0qUzIqCq3H09VBURe3HF98cBfwBkojzPF2UAAAAASUVORK5CYII=",
    blurWidth: 8,
    blurHeight: 6
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/api/Services.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/* Single image */ __turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$1$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$1$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/service-single/1.jpg.mjs { IMAGE => "[project]/helpers/images/service-single/1.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$2$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$2$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/service-single/2.jpg.mjs { IMAGE => "[project]/helpers/images/service-single/2.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$3$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$3$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/service-single/3.jpg.mjs { IMAGE => "[project]/helpers/images/service-single/3.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$4$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$4$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/service-single/4.jpg.mjs { IMAGE => "[project]/helpers/images/service-single/4.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$5$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$5$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/service-single/5.jpg.mjs { IMAGE => "[project]/helpers/images/service-single/5.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$6$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$6$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/service-single/6.jpg.mjs { IMAGE => "[project]/helpers/images/service-single/6.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
;
;
;
;
;
;
const Services = [
    {
        id: 1,
        icon: 'flaticon-tooth',
        simage: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$1$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$1$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        title: 'Dental Care',
        description: 'We have more doctor for your dental illness. We are here for your better treatment',
        slug: 'Dental-Care'
    },
    {
        id: 2,
        icon: 'flaticon-mortar',
        simage: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$2$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$2$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        title: 'Pharmacology',
        description: 'We have more doctor for your dental illness. We are here for your better treatment',
        slug: 'Pharmacology'
    },
    {
        id: 3,
        icon: 'flaticon-bone',
        simage: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$3$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$3$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        title: 'Orthopedic',
        description: 'We have more doctor for your dental illness. We are here for your better treatment',
        slug: 'Orthopedic'
    },
    {
        id: 4,
        icon: 'flaticon-baby',
        simage: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$4$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$4$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        title: 'Gyneological',
        description: 'We have more doctor for your dental illness. We are here for your better treatment',
        slug: 'Gyneological'
    },
    {
        id: 5,
        icon: 'flaticon-rehabilitation',
        simage: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$5$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$5$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        title: 'Rehabilitation',
        description: 'We have more doctor for your dental illness. We are here for your better treatment',
        slug: 'Rehabilitation'
    },
    {
        id: 6,
        icon: 'flaticon-microsurgery',
        simage: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$6$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$6$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        title: 'Heart Surgery',
        description: 'We have more doctor for your dental illness. We are here for your better treatment',
        slug: 'Heart Surgery'
    }
];
const __TURBOPACK__default__export__ = Services;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/api/projects.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$1$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2f$1$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/project/1.jpg.mjs { IMAGE => "[project]/helpers/images/project/1.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$2$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2f$2$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/project/2.jpg.mjs { IMAGE => "[project]/helpers/images/project/2.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$3$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2f$3$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/project/3.jpg.mjs { IMAGE => "[project]/helpers/images/project/3.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$4$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2f$4$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/project/4.jpg.mjs { IMAGE => "[project]/helpers/images/project/4.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$5$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2f$5$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/project/5.jpg.mjs { IMAGE => "[project]/helpers/images/project/5.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$6$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2f$6$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/project/6.jpg.mjs { IMAGE => "[project]/helpers/images/project/6.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$1$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$1$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/project-single/1.jpg.mjs { IMAGE => "[project]/helpers/images/project-single/1.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$2$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$2$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/project-single/2.jpg.mjs { IMAGE => "[project]/helpers/images/project-single/2.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$3$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$3$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/project-single/3.jpg.mjs { IMAGE => "[project]/helpers/images/project-single/3.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$4$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$4$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/project-single/4.jpg.mjs { IMAGE => "[project]/helpers/images/project-single/4.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$5$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$5$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/project-single/5.jpg.mjs { IMAGE => "[project]/helpers/images/project-single/5.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$6$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$6$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/project-single/6.jpg.mjs { IMAGE => "[project]/helpers/images/project-single/6.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
;
;
;
;
;
;
;
;
;
;
;
;
const Projects = [
    {
        id: '1',
        title: 'Heart Institure',
        subtitle: 'Treatment',
        docomunt: 'Quis id at rhoncus consequat. Aliquam in. Velit phasellus augue tristique integer arcu. Elit sed vestibulum tristique suspendisse ut sit',
        slug: 'Heart-Institure',
        pimg1: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$1$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2f$1$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        pSimg: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$1$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$1$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        location: '7 Lake Street,London',
        date: '15 Dec 2024'
    },
    {
        id: '2',
        title: 'Orthopaedics Center',
        subtitle: 'Treatment',
        docomunt: 'Quis id at rhoncus consequat. Aliquam in. Velit phasellus augue tristique integer arcu. Elit sed vestibulum tristique suspendisse ut sit',
        slug: 'Orthopaedics-Center',
        pimg1: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$2$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2f$2$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        pSimg: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$2$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$2$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        location: '7 Lake Street,London',
        date: '15 Dec 2024'
    },
    {
        id: '3',
        title: 'Neurology Services',
        subtitle: 'Treatment',
        docomunt: 'Quis id at rhoncus consequat. Aliquam in. Velit phasellus augue tristique integer arcu. Elit sed vestibulum tristique suspendisse ut sit',
        slug: 'Neurology-Services',
        pimg1: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$3$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2f$3$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        pSimg: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$3$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$3$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        location: '7 Lake Street,London',
        date: '15 Dec 2024'
    },
    {
        id: '4',
        title: 'Quality Therapy',
        subtitle: 'Treatment',
        docomunt: 'Quis id at rhoncus consequat. Aliquam in. Velit phasellus augue tristique integer arcu. Elit sed vestibulum tristique suspendisse ut sit',
        slug: 'Quality-Therapy',
        pimg1: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$4$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2f$4$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        pSimg: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$4$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$4$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        location: '7 Lake Street,London',
        date: '15 Dec 2024'
    },
    {
        id: '5',
        title: 'Pediatric Surgery',
        subtitle: 'Treatment',
        docomunt: 'Quis id at rhoncus consequat. Aliquam in. Velit phasellus augue tristique integer arcu. Elit sed vestibulum tristique suspendisse ut sit',
        slug: 'Neurology-Services',
        pimg1: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$5$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2f$5$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        pSimg: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$5$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$5$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        location: '7 Lake Street,London',
        date: '15 Dec 2024'
    },
    {
        id: '6',
        title: 'Surgical',
        subtitle: 'Treatment',
        docomunt: 'Quis id at rhoncus consequat. Aliquam in. Velit phasellus augue tristique integer arcu. Elit sed vestibulum tristique suspendisse ut sit',
        slug: 'Surgical-Services',
        pimg1: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$6$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2f$6$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        pSimg: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$6$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2d$single$2f$6$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        location: '7 Lake Street,London',
        date: '15 Dec 2024'
    }
];
const __TURBOPACK__default__export__ = Projects;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/api/team.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$1$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$1$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/team/1.png.mjs { IMAGE => "[project]/helpers/images/team/1.png (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$2$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$2$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/team/2.png.mjs { IMAGE => "[project]/helpers/images/team/2.png (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$3$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$3$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/team/3.png.mjs { IMAGE => "[project]/helpers/images/team/3.png (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$4$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$4$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/team/4.png.mjs { IMAGE => "[project]/helpers/images/team/4.png (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$5$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$5$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/team/5.png.mjs { IMAGE => "[project]/helpers/images/team/5.png (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$6$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$6$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/team/6.png.mjs { IMAGE => "[project]/helpers/images/team/6.png (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$1$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$1$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/team-single/1.jpg.mjs { IMAGE => "[project]/helpers/images/team-single/1.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$2$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$2$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/team-single/2.jpg.mjs { IMAGE => "[project]/helpers/images/team-single/2.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$3$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$3$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/team-single/3.jpg.mjs { IMAGE => "[project]/helpers/images/team-single/3.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$4$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$4$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/team-single/4.jpg.mjs { IMAGE => "[project]/helpers/images/team-single/4.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$5$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$5$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/team-single/5.jpg.mjs { IMAGE => "[project]/helpers/images/team-single/5.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$6$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$6$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/team-single/6.jpg.mjs { IMAGE => "[project]/helpers/images/team-single/6.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
;
;
;
;
;
;
;
;
;
;
;
;
const Teams = [
    {
        id: '1',
        title: 'مارلين هنري',
        subtitle: 'جراح',
        slug: 'Marlene-Henry',
        timg: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$1$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$1$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        Sime: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$1$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$1$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    },
    {
        id: '2',
        title: 'ديان راسل',
        subtitle: 'أخصائية قلب',
        slug: 'Dianne-Russell',
        timg: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$2$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$2$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        Sime: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$2$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$2$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    },
    {
        id: '3',
        title: 'جيروم بيل',
        subtitle: 'اختصاصي أمراض الحيوانات',
        slug: 'Jerome-Bell',
        timg: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$3$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$3$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        Sime: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$3$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$3$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    },
    {
        id: '4',
        title: 'ليسلي ألكسندر',
        subtitle: 'جراح',
        slug: 'Leslie-Alexander',
        timg: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$4$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$4$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        Sime: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$4$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$4$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    },
    {
        id: '5',
        title: 'ألكسندر ليسلي',
        subtitle: 'أخصائي قلب',
        slug: 'Alexander-Leslie',
        timg: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$5$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$5$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        Sime: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$5$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$5$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    },
    {
        id: '6',
        title: 'كودي فيشر',
        subtitle: 'جراح',
        slug: 'Cody-Fisher',
        timg: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$6$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$6$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        Sime: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$6$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$6$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    }
];
const __TURBOPACK__default__export__ = Teams;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/api/blogs.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// images
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2f$img$2d$1$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$blog$2f$img$2d$1$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/blog/img-1.jpg.mjs { IMAGE => "[project]/helpers/images/blog/img-1.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2f$img$2d$2$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$blog$2f$img$2d$2$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/blog/img-2.jpg.mjs { IMAGE => "[project]/helpers/images/blog/img-2.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2f$img$2d$3$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$blog$2f$img$2d$3$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/blog/img-3.jpg.mjs { IMAGE => "[project]/helpers/images/blog/img-3.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$1$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$1$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/blog-details/1.jpg.mjs { IMAGE => "[project]/helpers/images/blog-details/1.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$2$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$2$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/blog-details/2.jpg.mjs { IMAGE => "[project]/helpers/images/blog-details/2.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$3$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$3$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/blog-details/3.jpg.mjs { IMAGE => "[project]/helpers/images/blog-details/3.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
;
;
;
;
;
;
const blogsArabic = [
    {
        id: '1',
        title: 'نصائح لمرضى جراحة العظام',
        title2: 'كيف تؤثر مشاعرك على صحتك الجسدية؟',
        tag: 'جراحة',
        slug: 'نصائح-لمرضى-جراحة-العظام',
        screens: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2f$img$2d$1$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$blog$2f$img$2d$1$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        description: 'نقدم في هذا المقال أهم النصائح والتعليمات لما بعد جراحة العظام لضمان تعافٍ سريع وآمن',
        author: 'آنا ويليام',
        create_at: '٣ سبتمبر ٢٠٢٤',
        blogSingleImg: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$1$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$1$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        comment: '٣٥',
        day: '٢٨',
        month: 'مارس',
        blClass: 'format-standard-image',
        animation: '1200'
    },
    {
        id: '2',
        title: 'استراتيجية نقل الدم وجراحة القلب',
        title2: 'الحفاظ على استراتيجية الرعاية وسط تغيرات الغذاء',
        tag: 'عظام',
        slug: 'استراتيجية-نقل-الدم-وجراحة-القلب',
        screens: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2f$img$2d$2$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$blog$2f$img$2d$2$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        description: 'كل ما تريد معرفته عن أحدث التطورات في مجال جراحات القلب واستراتيجيات نقل الدم',
        author: 'آنا ويليام',
        create_at: '٣ سبتمبر ٢٠٢٤',
        blogSingleImg: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$2$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$2$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        comment: '٣٥',
        day: '٢٨',
        month: 'مارس',
        blClass: 'format-standard-image',
        animation: '1200'
    },
    {
        id: '3',
        title: 'تمارين لذوي الحركة المحدودة',
        title2: 'ما هي تحورات فيروس كورونا التي تسبب القلق؟',
        tag: 'جراحة',
        slug: 'تمارين-لذوي-الحركة-المحدودة',
        screens: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2f$img$2d$3$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$blog$2f$img$2d$3$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        description: 'دليل شامل للتمارين الرياضية المناسبة للأشخاص ذوي الحركة المحدودة',
        author: 'آنا ويليام',
        create_at: '٣ سبتمبر ٢٠٢٤',
        blogSingleImg: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$3$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$blog$2d$details$2f$3$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        comment: '٣٥',
        day: '٢٨',
        month: 'مارس',
        blClass: 'format-standard-image',
        animation: '1200'
    }
];
const __TURBOPACK__default__export__ = blogsArabic;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/api/index.js [client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, k: __turbopack_refresh__, m: module, e: exports } = __turbopack_context__;
{
// import data from './data.json';
// export default () => {
//   return data;
// }
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/utils/index.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "filterProductByCategory": (()=>filterProductByCategory),
    "filterProductByColor": (()=>filterProductByColor),
    "filterProductByPrice": (()=>filterProductByPrice),
    "filterProductBySize": (()=>filterProductBySize),
    "getCompareList": (()=>getCompareList),
    "getFeaturedProducts": (()=>getFeaturedProducts),
    "getFlashProducts": (()=>getFlashProducts),
    "isEquals": (()=>isEquals),
    "isWishListed": (()=>isWishListed),
    "minValueOne": (()=>minValueOne),
    "searchFilter": (()=>searchFilter),
    "totalPrice": (()=>totalPrice)
});
function getFlashProducts(products) {
    return products.filter((item)=>item.sale === true).slice(0, 8);
}
function getFeaturedProducts(products) {
    return products.filter((item)=>item.sale === true).slice(0, 12);
}
function totalPrice(items) {
    return items.reduce((itemAcc, item)=>{
        return itemAcc += item.price * item.qty;
    }, 0);
}
function isWishListed(productId, wishList) {
    return wishList.findIndex((product)=>product.id === productId) !== -1;
}
function getCompareList(items) {
    return items.slice(0, 4);
}
function searchFilter(row, search) {
    return row.title.toLowerCase().includes(search.toLowerCase()) || !search;
}
// short helper function
function checkLengNull(data) {
    if (data !== null) {
        return data.length > 0;
    }
    return false;
}
function isEquals(a, b) {
    if (a !== null && b !== null) {
        return a.toLowerCase() === b.toLowerCase();
    }
    return a === b;
}
function minValueOne(qty) {
    if (qty < 1) {
        return 1;
    }
    return qty;
}
// filter function
function filterProductByCategory(product, selected_category) {
    if (checkLengNull(selected_category)) {
        return product.category.toLowerCase() === selected_category.toLowerCase();
    }
    return true;
}
function filterProductByPrice(product, price) {
    if (checkLengNull(price)) {
        return product.price >= price[0] && product.price <= price[1];
    }
    return true;
}
function filterProductByColor(product, color) {
    if (checkLengNull(color)) {
        for(var i = 0; i < product.colors.length; i++){
            if (product.colors[i].toLowerCase() === color.toLowerCase()) {
                return true;
            }
        }
        return false;
    }
    return true;
}
function filterProductBySize(product, size) {
    if (checkLengNull(size)) {
        for(var i = 0; i < product.size.length; i++){
            if (product.size[i].toLowerCase() === size.toLowerCase()) {
                return true;
            }
        }
        return false;
    }
    return true;
}
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/reportWebVitals.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
const reportWebVitals = (onPerfEntry)=>{
    if (onPerfEntry && onPerfEntry instanceof Function) {
        __turbopack_context__.r("[project]/node_modules/web-vitals/dist/web-vitals.js [client] (ecmascript, async loader)")(__turbopack_context__.i).then(({ getCLS, getFID, getFCP, getLCP, getTTFB })=>{
            getCLS(onPerfEntry);
            getFID(onPerfEntry);
            getFCP(onPerfEntry);
            getLCP(onPerfEntry);
            getTTFB(onPerfEntry);
        });
    }
};
const __TURBOPACK__default__export__ = reportWebVitals;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/index.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dom$2f$client$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-dom/client.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$App$2f$App$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/App/App.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$reportWebVitals$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/reportWebVitals.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$scroll$2d$parallax$2f$dist$2f$react$2d$scroll$2d$parallax$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/react-scroll-parallax/dist/react-scroll-parallax.esm.js [client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$scroll$2d$parallax$2f$dist$2f$react$2d$scroll$2d$parallax$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/react-scroll-parallax/dist/react-scroll-parallax.esm.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$redux$2d$persist$2f$es$2f$integration$2f$react$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/redux-persist/es/integration/react.js [client] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module './store/index'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/react-redux/es/index.js [client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$components$2f$Provider$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Provider$3e$__ = __turbopack_context__.i("[project]/node_modules/react-redux/es/components/Provider.js [client] (ecmascript) <export default as Provider>");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const root = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$dom$2f$client$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].createRoot(document.getElementById('root'));
root.render(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$components$2f$Provider$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Provider$3e$__["Provider"], {
    store: store,
    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$redux$2d$persist$2f$es$2f$integration$2f$react$2e$js__$5b$client$5d$__$28$ecmascript$29$__["PersistGate"], {
        loading: null,
        persistor: persistor,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$scroll$2d$parallax$2f$dist$2f$react$2d$scroll$2d$parallax$2e$esm$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ParallaxProvider"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$App$2f$App$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/index.js",
                lineNumber: 24,
                columnNumber: 17
            }, this)
        }, void 0, false, {
            fileName: "[project]/helpers/index.js",
            lineNumber: 23,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/helpers/index.js",
        lineNumber: 22,
        columnNumber: 9
    }, this)
}, void 0, false, {
    fileName: "[project]/helpers/index.js",
    lineNumber: 21,
    columnNumber: 5
}, this));
// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
(0, __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$reportWebVitals$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"])();
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=helpers_13bd26e8._.js.map