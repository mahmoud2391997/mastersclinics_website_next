__turbopack_load_page_chunks__("/services", [
  "static/chunks/[root-of-the-server]__a952f124._.js",
  "static/chunks/node_modules_next_7000703c._.js",
  "static/chunks/node_modules_react_1cad9b0b._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
  "static/chunks/node_modules_react-dom_f14d0471._.js",
  "static/chunks/node_modules_@mui_system_93e0f7bc._.js",
  "static/chunks/node_modules_axios_lib_9aa2336a._.js",
  "static/chunks/node_modules_c9131f8c._.js",
  "static/chunks/pages_services_index_jsx_5771e187._.js",
  "static/chunks/pages_services_index_jsx_3fa1454a._.js"
])
