__turbopack_load_page_chunks__("/offers/[id]", [
  "static/chunks/[root-of-the-server]__6267f446._.js",
  "static/chunks/node_modules_next_dist_compiled_0a3504d8._.js",
  "static/chunks/node_modules_next_dist_shared_lib_629c25b9._.js",
  "static/chunks/node_modules_next_dist_client_fcd6d2c7._.js",
  "static/chunks/node_modules_next_dist_55f53007._.js",
  "static/chunks/node_modules_next_53841057._.js",
  "static/chunks/node_modules_react_1cad9b0b._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
  "static/chunks/node_modules_react-dom_f14d0471._.js",
  "static/chunks/node_modules_axios_lib_9aa2336a._.js",
  "static/chunks/node_modules_@mui_system_93e0f7bc._.js",
  "static/chunks/node_modules_swiper_a30f49b5._.js",
  "static/chunks/node_modules_b2293ef4._.js",
  "static/chunks/node_modules_swiper_d73dda7b._.css",
  "static/chunks/pages_offers_[id]_jsx_5771e187._.js",
  "static/chunks/pages_offers_[id]_jsx_42dd9c98._.js"
])
