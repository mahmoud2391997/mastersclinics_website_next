__turbopack_load_page_chunks__("/offers", [
  "static/chunks/[root-of-the-server]__da244ef4._.js",
  "static/chunks/node_modules_next_0085ff26._.js",
  "static/chunks/node_modules_react_1cad9b0b._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
  "static/chunks/node_modules_react-dom_f14d0471._.js",
  "static/chunks/node_modules_@mui_system_93e0f7bc._.js",
  "static/chunks/node_modules_axios_lib_9aa2336a._.js",
  "static/chunks/node_modules_swiper_1e7dbd3e._.js",
  "static/chunks/node_modules_0e7df8de._.js",
  "static/chunks/node_modules_swiper_85a0f431._.css",
  "static/chunks/pages_offers_index_jsx_5771e187._.js",
  "static/chunks/pages_offers_index_jsx_1098f645._.js"
])
