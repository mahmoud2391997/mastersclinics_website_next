__turbopack_load_page_chunks__("/branches/[id]", [
  "static/chunks/[root-of-the-server]__e52eb669._.js",
  "static/chunks/node_modules_next_9765600b._.js",
  "static/chunks/node_modules_react_1cad9b0b._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
  "static/chunks/node_modules_react-dom_f14d0471._.js",
  "static/chunks/node_modules_axios_lib_9aa2336a._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_bad01e3f._.js",
  "static/chunks/node_modules_react-icons_lib_75a63dfe._.js",
  "static/chunks/node_modules_@mui_system_93e0f7bc._.js",
  "static/chunks/node_modules_7cf901b0._.js",
  "static/chunks/pages_branches_[id]_jsx_5771e187._.js",
  "static/chunks/pages_branches_[id]_jsx_d19a408a._.js"
])
