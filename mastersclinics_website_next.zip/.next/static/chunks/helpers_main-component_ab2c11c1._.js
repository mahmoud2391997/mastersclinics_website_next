(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/helpers/main-component/HomePage2/HomePage2.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/Navbar/Navbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$hero2$2f$Hero2$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/hero2/Hero2.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$ProcessSection$2f$ProcessSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/ProcessSection/ProcessSection.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$about2$2f$about2$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/about2/about2.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$ServiceSection2$2f$ServiceSection2$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/ServiceSection2/ServiceSection2.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$ProjectSectionS2$2f$ProjectSectionS2$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/ProjectSectionS2/ProjectSectionS2.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Testimonial$2f$Testimonial$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/Testimonial/Testimonial.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$FunFactS2$2f$FunFactS2$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/FunFactS2/FunFactS2.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$TeamSection$2f$TeamSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/TeamSection/TeamSection.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$CtafromSection$2f$CtafromSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/CtafromSection/CtafromSection.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$BlogSection$2f$BlogSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/BlogSection/BlogSection.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/footer/Footer.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/scrollbar/scrollbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/logo-2.svg.mjs { IMAGE => "[project]/helpers/images/logo-2.svg (static in ecmascript)" } [client] (structured image object, ecmascript)');
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const HomePage2 = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-header wpo-site-header-s2',
                Logo: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage2/HomePage2.js",
                lineNumber: 20,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$hero2$2f$Hero2$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage2/HomePage2.js",
                lineNumber: 21,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$ProcessSection$2f$ProcessSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: "work_section_s2 section-padding"
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage2/HomePage2.js",
                lineNumber: 22,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$about2$2f$about2$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage2/HomePage2.js",
                lineNumber: 23,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$ServiceSection2$2f$ServiceSection2$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'service_section_s2 section-padding'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage2/HomePage2.js",
                lineNumber: 24,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$ProjectSectionS2$2f$ProjectSectionS2$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'project_section_s2 section-padding'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage2/HomePage2.js",
                lineNumber: 25,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Testimonial$2f$Testimonial$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                tClass: 'testimonial_section testimonial_section_slider section-padding'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage2/HomePage2.js",
                lineNumber: 26,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$FunFactS2$2f$FunFactS2$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'funfact_section_s2'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage2/HomePage2.js",
                lineNumber: 27,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$TeamSection$2f$TeamSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'team_section_s2 section-padding'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage2/HomePage2.js",
                lineNumber: 28,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$CtafromSection$2f$CtafromSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'ctafrom_section_s2'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage2/HomePage2.js",
                lineNumber: 29,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$BlogSection$2f$BlogSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                tClass: 'blog_section section-padding'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage2/HomePage2.js",
                lineNumber: 30,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-footer_s2'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage2/HomePage2.js",
                lineNumber: 31,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage2/HomePage2.js",
                lineNumber: 32,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/helpers/main-component/HomePage2/HomePage2.js",
        lineNumber: 19,
        columnNumber: 9
    }, this);
};
_c = HomePage2;
const __TURBOPACK__default__export__ = HomePage2;
var _c;
__turbopack_context__.k.register(_c, "HomePage2");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/HomePage3/HomePage3.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/Navbar/Navbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$hero3$2f$hero3$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/hero3/hero3.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$AppointmentSection$2f$AppointmentSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/AppointmentSection/AppointmentSection.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$aboutS3$2f$aboutS3$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/aboutS3/aboutS3.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$ProcessSection$2f$ProcessSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/ProcessSection/ProcessSection.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$ServiceSection$2f$ServiceSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/ServiceSection/ServiceSection.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$ProjectSection$2f$ProjectSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/ProjectSection/ProjectSection.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Testimonial$2f$Testimonial$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/Testimonial/Testimonial.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$CtaSectionS2$2f$CtaSectionS2$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/CtaSectionS2/CtaSectionS2.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$TeamSection$2f$TeamSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/TeamSection/TeamSection.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$FunFact$2f$FunFact$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/FunFact/FunFact.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$BlogSection$2f$BlogSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/BlogSection/BlogSection.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$CtafromSection$2f$CtafromSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/CtafromSection/CtafromSection.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/footer/Footer.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/scrollbar/scrollbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/logo-2.svg.mjs { IMAGE => "[project]/helpers/images/logo-2.svg (static in ecmascript)" } [client] (structured image object, ecmascript)');
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const HomePage3 = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-header wpo-site-header-s2',
                Logo: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage3/HomePage3.js",
                lineNumber: 23,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$hero3$2f$hero3$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage3/HomePage3.js",
                lineNumber: 24,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$AppointmentSection$2f$AppointmentSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'appointment_section_s2'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage3/HomePage3.js",
                lineNumber: 25,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$aboutS3$2f$aboutS3$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage3/HomePage3.js",
                lineNumber: 26,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$ProcessSection$2f$ProcessSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: "work_section_s2 section-padding"
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage3/HomePage3.js",
                lineNumber: 27,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$ServiceSection$2f$ServiceSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: "service_section_s3 section-padding"
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage3/HomePage3.js",
                lineNumber: 28,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$ProjectSection$2f$ProjectSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'project_section_s3 section-padding'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage3/HomePage3.js",
                lineNumber: 29,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Testimonial$2f$Testimonial$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                tClass: 'testimonial_section testimonial_section_slider section-padding pt-0'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage3/HomePage3.js",
                lineNumber: 30,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$CtaSectionS2$2f$CtaSectionS2$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage3/HomePage3.js",
                lineNumber: 31,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$TeamSection$2f$TeamSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'team_section_s2 section-padding'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage3/HomePage3.js",
                lineNumber: 32,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$FunFact$2f$FunFact$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'funfact_section'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage3/HomePage3.js",
                lineNumber: 33,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$BlogSection$2f$BlogSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                tClass: 'blog_section section-padding'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage3/HomePage3.js",
                lineNumber: 34,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$CtafromSection$2f$CtafromSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'ctafrom_section'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage3/HomePage3.js",
                lineNumber: 35,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-footer'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage3/HomePage3.js",
                lineNumber: 36,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage3/HomePage3.js",
                lineNumber: 37,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/helpers/main-component/HomePage3/HomePage3.js",
        lineNumber: 22,
        columnNumber: 9
    }, this);
};
_c = HomePage3;
const __TURBOPACK__default__export__ = HomePage3;
var _c;
__turbopack_context__.k.register(_c, "HomePage3");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
const ContactForm = ()=>{
    _s();
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])({
        name: '',
        email: '',
        department: '',
        doctor: '',
        message: ''
    });
    const [formErrors, setFormErrors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])({
        nameError: '',
        emailError: '',
        departmentError: '',
        doctorError: '',
        messageError: ''
    });
    const validateForm = ()=>{
        let isValid = true;
        const errors = {
            nameError: '',
            emailError: '',
            departmentError: '',
            doctorError: '',
            messageError: ''
        };
        if (formData.name.trim() === '') {
            errors.nameError = 'Please enter your name';
            isValid = false;
        }
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(formData.email)) {
            errors.emailError = 'Please enter a valid email';
            isValid = false;
        }
        if (formData.department.trim() === '') {
            errors.departmentError = 'Please select a department';
            isValid = false;
        }
        if (formData.doctor.trim() === '') {
            errors.doctorError = 'Please choose a doctor';
            isValid = false;
        }
        if (formData.message.trim() === '') {
            errors.messageError = 'Please describe your problem';
            isValid = false;
        }
        setFormErrors(errors);
        return isValid;
    };
    const handleInputChange = (event)=>{
        setFormData({
            ...formData,
            [event.target.name]: event.target.value
        });
    };
    const handleSubmit = (event)=>{
        event.preventDefault();
        const isValid = validateForm();
        if (isValid) {
            // Handle form submission logic here
            console.log('Form submitted:', formData);
            // Reset form after submission if needed
            setFormData({
                name: '',
                email: '',
                department: '',
                doctor: '',
                message: ''
            });
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        id: "myForm",
        onSubmit: handleSubmit,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "row",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "col-lg-6 col-md-6 col-12 form_item",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: "Your Name"
                        }, void 0, false, {
                            fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                            lineNumber: 85,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            className: "input-fild",
                            type: "text",
                            name: "name",
                            value: formData.name,
                            onChange: handleInputChange,
                            placeholder: "Name"
                        }, void 0, false, {
                            fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                            lineNumber: 86,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "error",
                            children: formErrors.nameError
                        }, void 0, false, {
                            fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                            lineNumber: 94,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                    lineNumber: 84,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "col-lg-6 col-md-6 col-12 form_item",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: "Your Email"
                        }, void 0, false, {
                            fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                            lineNumber: 97,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            className: "input-fild",
                            type: "email",
                            name: "email",
                            value: formData.email,
                            onChange: handleInputChange,
                            placeholder: "Email"
                        }, void 0, false, {
                            fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                            lineNumber: 98,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "error",
                            children: formErrors.emailError
                        }, void 0, false, {
                            fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                            lineNumber: 106,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                    lineNumber: 96,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "col-lg-6 col-md-6 col-12 form_item",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: "Select Department"
                        }, void 0, false, {
                            fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                            lineNumber: 109,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                            name: "department",
                            value: formData.department,
                            onChange: handleInputChange,
                            className: "input-fild",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: "",
                                    children: "Department"
                                }, void 0, false, {
                                    fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                                    lineNumber: 116,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: "Subject 1",
                                    children: "Subject 1"
                                }, void 0, false, {
                                    fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                                    lineNumber: 117,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: "Subject 2",
                                    children: "Subject 2"
                                }, void 0, false, {
                                    fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                                    lineNumber: 118,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: "Subject 3",
                                    children: "Subject 3"
                                }, void 0, false, {
                                    fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                                    lineNumber: 119,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                            lineNumber: 110,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "error",
                            children: formErrors.departmentError
                        }, void 0, false, {
                            fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                            lineNumber: 121,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                    lineNumber: 108,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "col-lg-6 col-md-6 col-12 form_item",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: "Choose Doctor"
                        }, void 0, false, {
                            fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                            lineNumber: 124,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                            name: "doctor",
                            value: formData.doctor,
                            onChange: handleInputChange,
                            className: "input-fild",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: "",
                                    children: "Choose Doctor"
                                }, void 0, false, {
                                    fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                                    lineNumber: 131,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: "Doctor 1",
                                    children: "Doctor 1"
                                }, void 0, false, {
                                    fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                                    lineNumber: 132,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: "Doctor 2",
                                    children: "Doctor 2"
                                }, void 0, false, {
                                    fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                                    lineNumber: 133,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: "Doctor 3",
                                    children: "Doctor 3"
                                }, void 0, false, {
                                    fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                                    lineNumber: 134,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                            lineNumber: 125,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "error",
                            children: formErrors.doctorError
                        }, void 0, false, {
                            fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                            lineNumber: 136,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                    lineNumber: 123,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "col-12 form_item",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: "Say Details About Your Problem"
                        }, void 0, false, {
                            fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                            lineNumber: 139,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                            name: "message",
                            value: formData.message,
                            onChange: handleInputChange,
                            className: "input-fild",
                            placeholder: "Message.."
                        }, void 0, false, {
                            fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                            lineNumber: 140,
                            columnNumber: 21
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "error s2",
                            children: formErrors.messageError
                        }, void 0, false, {
                            fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                            lineNumber: 147,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                    lineNumber: 138,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "col-12",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "submit",
                        className: "theme-btn",
                        value: "Send Message"
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                        lineNumber: 150,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
                    lineNumber: 149,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
            lineNumber: 83,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js",
        lineNumber: 82,
        columnNumber: 9
    }, this);
};
_s(ContactForm, "UX8suUBP3bzA3uY0PVSSloiyCeM=");
_c = ContactForm;
const __TURBOPACK__default__export__ = ContactForm;
var _c;
__turbopack_context__.k.register(_c, "ContactForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2d$dom$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/react-router-dom/dist/index.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/react-router/dist/index.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/react-redux/es/index.js [client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$hooks$2f$useDispatch$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-redux/es/hooks/useDispatch.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$hooks$2f$useSelector$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-redux/es/hooks/useSelector.js [client] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module '../../store/slices/doctor'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/Navbar/Navbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/pagetitle/PageTitle.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/footer/Footer.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/scrollbar/scrollbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$ServiceSinglePage$2f$ServiceFrom$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/logo-2.svg.mjs { IMAGE => "[project]/helpers/images/logo-2.svg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$arrow$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$arrow$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/team-single/arrow.svg.mjs { IMAGE => "[project]/helpers/images/team-single/arrow.svg (static in ecmascript)" } [client] (structured image object, ecmascript)');
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
const TeamSinglePage = ()=>{
    _s();
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$hooks$2f$useDispatch$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useDispatch"])();
    const { slug } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useParams"])();
    console.log(slug);
    // SINGLE useSelector call to get all state at once
    const teamsState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$hooks$2f$useSelector$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useSelector"])({
        "TeamSinglePage.useSelector[teamsState]": (state)=>state.teams || {}
    }["TeamSinglePage.useSelector[teamsState]"]);
    const { selectedTeam: currentMember = null, loading = false, error = null } = teamsState;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TeamSinglePage.useEffect": ()=>{
            dispatch(fetchTeamBySlug(slug));
        }
    }["TeamSinglePage.useEffect"], [
        dispatch,
        slug
    ]);
    // Debug logs using the already selected state
    console.log('Teams state:', teamsState);
    console.log('Current team member:', currentMember);
    if (loading) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "text-center py-5",
        children: "Loading doctor profile..."
    }, void 0, false, {
        fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
        lineNumber: 33,
        columnNumber: 25
    }, this);
    if (error) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "text-center py-5 text-danger",
        children: [
            "Error: ",
            error
        ]
    }, void 0, true, {
        fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
        lineNumber: 34,
        columnNumber: 23
    }, this);
    if (!currentMember) {
        console.warn('No team member found:', teamsState);
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center py-5",
            children: "Doctor data not available"
        }, void 0, false, {
            fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
            lineNumber: 37,
            columnNumber: 16
        }, this);
    } // Rest of your component...
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                Logo: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                hclass: 'wpo-site-header wpo-site-header-s2'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                lineNumber: 41,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                pageTitle: currentMember.name,
                pagesub: 'Doctor Single'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                lineNumber: 42,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "team_single_page section-padding",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "container",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "row align-items-end",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "col-lg-6 col-12",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "doctor_profile",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                    src: currentMember.image,
                                                    alt: currentMember.title,
                                                    loading: "lazy"
                                                }, void 0, false, {
                                                    fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                    lineNumber: 49,
                                                    columnNumber: 33
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "content",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                            children: currentMember.name
                                                        }, void 0, false, {
                                                            fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                            lineNumber: 55,
                                                            columnNumber: 37
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: currentMember.specialty || 'Professional Surgeon & Expert Doctor'
                                                        }, void 0, false, {
                                                            fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                            lineNumber: 56,
                                                            columnNumber: 37
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                            className: "social-links",
                                                            children: currentMember.socialLinks?.map((link, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2d$dom$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Link"], {
                                                                        to: link.url,
                                                                        target: "_blank",
                                                                        rel: "noopener noreferrer",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                                            className: link.iconClass
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                                            lineNumber: 61,
                                                                            columnNumber: 53
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                                        lineNumber: 60,
                                                                        columnNumber: 49
                                                                    }, this)
                                                                }, index, false, {
                                                                    fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                                    lineNumber: 59,
                                                                    columnNumber: 45
                                                                }, this))
                                                        }, void 0, false, {
                                                            fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                            lineNumber: 57,
                                                            columnNumber: 37
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                    lineNumber: 54,
                                                    columnNumber: 33
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                            lineNumber: 48,
                                            columnNumber: 29
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                        lineNumber: 47,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "col-lg-6 col-12",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "doctor_info",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                        children: "Personal Info"
                                                    }, void 0, false, {
                                                        fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                        lineNumber: 72,
                                                        columnNumber: 33
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        children: currentMember.bio
                                                    }, void 0, false, {
                                                        fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                        lineNumber: 73,
                                                        columnNumber: 33
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                lineNumber: 71,
                                                columnNumber: 29
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "doctor_info s2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                        children: "Education"
                                                    }, void 0, false, {
                                                        fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                        lineNumber: 79,
                                                        columnNumber: 33
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                        className: "education-list",
                                                        children: currentMember.education?.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                                        src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$arrow$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2d$single$2f$arrow$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                                                        alt: "",
                                                                        "aria-hidden": "true"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                                        lineNumber: 83,
                                                                        columnNumber: 45
                                                                    }, this),
                                                                    item
                                                                ]
                                                            }, index, true, {
                                                                fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                                lineNumber: 82,
                                                                columnNumber: 41
                                                            }, this))
                                                    }, void 0, false, {
                                                        fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                        lineNumber: 80,
                                                        columnNumber: 33
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                lineNumber: 78,
                                                columnNumber: 29
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                        lineNumber: 70,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                lineNumber: 46,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "experience_wrap",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "top_content",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                children: "Personal Experience"
                                            }, void 0, false, {
                                                fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                lineNumber: 94,
                                                columnNumber: 29
                                            }, this),
                                            currentMember.experience?.map((paragraph, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    children: paragraph
                                                }, index, false, {
                                                    fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                    lineNumber: 96,
                                                    columnNumber: 33
                                                }, this))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                        lineNumber: 93,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "skill_wrap",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "achievements",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                    children: "Achievements"
                                                }, void 0, false, {
                                                    fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                    lineNumber: 122,
                                                    columnNumber: 33
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                    children: currentMember.achievements?.map((achievement, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: [
                                                                        achievement.year,
                                                                        ": "
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                                    lineNumber: 126,
                                                                    columnNumber: 45
                                                                }, this),
                                                                achievement.description
                                                            ]
                                                        }, index, true, {
                                                            fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                            lineNumber: 125,
                                                            columnNumber: 41
                                                        }, this))
                                                }, void 0, false, {
                                                    fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                    lineNumber: 123,
                                                    columnNumber: 33
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                            lineNumber: 121,
                                            columnNumber: 29
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                        lineNumber: 100,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                lineNumber: 92,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                        lineNumber: 45,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "AppointmentFrom",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "container",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "cta_form_s2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "title s2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                children: "Make An Appointment"
                                            }, void 0, false, {
                                                fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                lineNumber: 140,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: "Get in touch with us to see how we can help you with your Problems."
                                            }, void 0, false, {
                                                fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                                lineNumber: 141,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                        lineNumber: 139,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$ServiceSinglePage$2f$ServiceFrom$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                        doctorId: currentMember.id
                                    }, void 0, false, {
                                        fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                        lineNumber: 143,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                                lineNumber: 138,
                                columnNumber: 25
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                            lineNumber: 137,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                        lineNumber: 136,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                lineNumber: 44,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-footer_s2'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                lineNumber: 149,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
                lineNumber: 150,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js",
        lineNumber: 40,
        columnNumber: 9
    }, this);
};
_s(TeamSinglePage, "MJiZxUH/o9EoJx9PLkKULHPJSpA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$hooks$2f$useDispatch$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useDispatch"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$hooks$2f$useSelector$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useSelector"]
    ];
});
_c = TeamSinglePage;
const __TURBOPACK__default__export__ = TeamSinglePage;
var _c;
__turbopack_context__.k.register(_c, "TeamSinglePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/ShopPage/index.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/react-redux/es/index.js [client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$components$2f$connect$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__connect$3e$__ = __turbopack_context__.i("[project]/node_modules/react-redux/es/components/connect.js [client] (ecmascript) <export default as connect>");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/pagetitle/PageTitle.js [client] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module '../../store/actions/action'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$ShopProduct$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/ShopProduct/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/api/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/Navbar/Navbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$CtafromSection$2f$CtafromSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/CtafromSection/CtafromSection.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/footer/Footer.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/scrollbar/scrollbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/logo-2.svg.mjs { IMAGE => "[project]/helpers/images/logo-2.svg (static in ecmascript)" } [client] (structured image object, ecmascript)');
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
const ShopPage = ({ addToCart: addToCart1 })=>{
    _s();
    const productsArray = (0, __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"])();
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const productsPerPage = 6;
    const totalProducts = productsArray.length;
    const totalPages = Math.ceil(totalProducts / productsPerPage);
    const handlePageChange = (pageNumber)=>{
        setCurrentPage(pageNumber);
    };
    const currentProducts = productsArray.slice((currentPage - 1) * productsPerPage, currentPage * productsPerPage);
    const addToCartProduct = (product, qty = 1)=>{
        addToCart1(product, qty);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-header wpo-site-header-s2',
                Logo: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/ShopPage/index.js",
                lineNumber: 37,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                pageTitle: 'Shop',
                pagesub: 'Shop'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/ShopPage/index.js",
                lineNumber: 38,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "shop_section section-padding",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "row",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "col-lg-12",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$ShopProduct$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                    addToCartProduct: addToCartProduct,
                                    products: currentProducts
                                }, void 0, false, {
                                    fileName: "[project]/helpers/main-component/ShopPage/index.js",
                                    lineNumber: 43,
                                    columnNumber: 29
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "pagination-wrapper pagination-wrapper-center",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                        className: "pg-pagination",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>handlePageChange(currentPage - 1),
                                                    disabled: currentPage === 1,
                                                    "aria-label": "Previous",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                        className: "ti-angle-left"
                                                    }, void 0, false, {
                                                        fileName: "[project]/helpers/main-component/ShopPage/index.js",
                                                        lineNumber: 51,
                                                        columnNumber: 45
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/helpers/main-component/ShopPage/index.js",
                                                    lineNumber: 50,
                                                    columnNumber: 41
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/helpers/main-component/ShopPage/index.js",
                                                lineNumber: 49,
                                                columnNumber: 37
                                            }, this),
                                            [
                                                ...Array(totalPages)
                                            ].map((_, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    className: currentPage === index + 1 ? 'active' : '',
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>handlePageChange(index + 1),
                                                        children: index + 1
                                                    }, void 0, false, {
                                                        fileName: "[project]/helpers/main-component/ShopPage/index.js",
                                                        lineNumber: 56,
                                                        columnNumber: 45
                                                    }, this)
                                                }, index, false, {
                                                    fileName: "[project]/helpers/main-component/ShopPage/index.js",
                                                    lineNumber: 55,
                                                    columnNumber: 41
                                                }, this)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>handlePageChange(currentPage + 1),
                                                    disabled: currentPage === totalPages,
                                                    "aria-label": "Next",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                        className: "ti-angle-right"
                                                    }, void 0, false, {
                                                        fileName: "[project]/helpers/main-component/ShopPage/index.js",
                                                        lineNumber: 63,
                                                        columnNumber: 45
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/helpers/main-component/ShopPage/index.js",
                                                    lineNumber: 62,
                                                    columnNumber: 41
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/helpers/main-component/ShopPage/index.js",
                                                lineNumber: 61,
                                                columnNumber: 37
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/helpers/main-component/ShopPage/index.js",
                                        lineNumber: 48,
                                        columnNumber: 33
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/helpers/main-component/ShopPage/index.js",
                                    lineNumber: 47,
                                    columnNumber: 29
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/helpers/main-component/ShopPage/index.js",
                            lineNumber: 42,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/ShopPage/index.js",
                        lineNumber: 41,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/helpers/main-component/ShopPage/index.js",
                    lineNumber: 40,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/ShopPage/index.js",
                lineNumber: 39,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$CtafromSection$2f$CtafromSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'ctafrom_section'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/ShopPage/index.js",
                lineNumber: 72,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-footer'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/ShopPage/index.js",
                lineNumber: 73,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/ShopPage/index.js",
                lineNumber: 74,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/helpers/main-component/ShopPage/index.js",
        lineNumber: 36,
        columnNumber: 9
    }, this);
};
_s(ShopPage, "6xAUoJ2motYJ38x4zeUWisA+X/4=");
_c = ShopPage;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$components$2f$connect$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__connect$3e$__["connect"])(null, {
    addToCart
})(ShopPage);
var _c;
__turbopack_context__.k.register(_c, "ShopPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/ProductSinglePage/product.js [client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, k: __turbopack_refresh__, m: module, e: exports } = __turbopack_context__;
{
// import React from 'react';
// import Zoom from 'react-medium-image-zoom'
// import 'react-medium-image-zoom/dist/styles.css'
// const Product = ({ item, addToCart }) => {
//   return (
//     <div className="row">
//       <div className="col col-lg-5 col-12">
//         <div className="shop-single-slider">
//           <div className="slider-nav">
//             <div>
//               <Zoom>
//                 <img src={item.proImg ? item.proImg : ''} alt="products" />
//               </Zoom>
//             </div>
//           </div>
//         </div>
//       </div>
//       <div className="col col-lg-7 col-12">
//         <div className="product-details">
//           <h2>{item.title}</h2>
//           <div className="product-rt">
//             <div className="rating">
//               <i className="flaticon-star"></i>
//               <i className="flaticon-star"></i>
//               <i className="flaticon-star"></i>
//               <i className="flaticon-star"></i>
//               <i className="flaticon-star-1"></i>
//             </div>
//             <span>(25 customer reviews)</span>
//           </div>
//           <div className="price">
//             <span className="current">${item.price}</span>
//             <span className="old">${item.delPrice}</span>
//           </div>
//           <p>There are many or randomised words which don't look even slightly believable.</p>
//           <ul>
//             <li>Going through the cites of the word in classNameical.</li>
//             <li>There are many variations of passages.</li>
//           </ul>
//           <div className="product-option">
//             <div className="product-row">
//               <button className="theme-btn"
//                 onClick={() => addToCart(item)}>Add
//                 to cart</button>
//               <div>
//               </div>
//             </div>
//           </div>
//           <div className="tg-btm">
//             <p><span>Categories:</span>Alere Medical</p>
//             <p><span>Tags:</span>Oxygen, Mask</p>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };
// export default Product;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/ProductSinglePage/alltab.js [client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, k: __turbopack_refresh__, m: module, e: exports } = __turbopack_context__;
{
// import React, { useState } from 'react';
// import { TabContent, TabPane, Nav, NavItem,  Row, Col } from 'reactstrap';
// import Link from 'next/link';
// import classnames from 'classnames';
// import rv1 from '../../images/shop/shop-single/review/img-1.jpg'
// import rv2 from '../../images/shop/shop-single/review/img-2.jpg'
// const ProductTabs = (props) => {
//     const [activeTab, setActiveTab] = useState('1');
//     const toggle = tab => {
//         if (activeTab !== tab) setActiveTab(tab);
//     }
//     const SubmitHandler = (e) => {
//         e.preventDefault()
//     }
//     return (
//         <div className="row">
//             <div className="col col-xs-12">
//                 <div className="product-info">
//                     <Nav tabs>
//                  <NavItem>
//     <a
//         className={classnames({ active: activeTab === '1' })}
//         onClick={e => { e.preventDefault(); toggle('1'); }}
//         href="#"
//         role="tab"
//     >
//        Description
//     </a>
// </NavItem>
//       <NavItem>
//     <a
//         className={classnames({ active: activeTab === '2' })}
//         onClick={e => { e.preventDefault(); toggle('2'); }}
//         href="#"
//         role="tab"
//     >
//         Review
//     </a>
// </NavItem>
//                     </Nav>
//                     <TabContent activeTab={activeTab}>
//                         <TabPane tabId="1">
//                             <Row>
//                                 <Col sm="12">
//                                     <div id="Schedule">
//                                     <p>Samsa woke from troubled dreams, he found himself transformed in his bed into a
//                                         horrible vermin. He lay on his armour-like back, and if he lifted his head a
//                                         little he could see his brown belly, slightly domed and divided by arches into
//                                         stiff sections. The bedding was hardly able to cover it and seemed ready to
//                                         slide off any moment. His many legs, pitifully thin compared with the size of
//                                         the rest of him.</p>
//                                     <p>The bedding was hardly able to cover it and seemed ready to slide off any moment.
//                                         His many legs, pitifully thin compared with the size of the rest of himSamsa
//                                         woke from troubled dreams, he found himself transformed in his bed into a
//                                         horrible vermin.</p>
//                                     </div>
//                                 </Col>
//                             </Row>
//                         </TabPane>
//                         <TabPane tabId="2">
//                         <div className="row">
//                             <div className="col col-lg-10 col-12">
//                                 <div className="client-rv">
//                                     <div className="client-pic">
//                                         <img src={rv1} alt=""/>
//                                     </div>
//                                     <div className="details">
//                                         <div className="name-rating-time">
//                                             <div className="name-rating">
//                                                 <div>
//                                                     <h4>Jenefar Willium</h4>
//                                                 </div>
//                                                 <div className="product-rt">
//                                                     <span>25 Sep 2024</span>
//                                                     <div className="rating">
//                                                         <i className="flaticon-star"></i>
//                                                         <i className="flaticon-star"></i>
//                                                         <i className="flaticon-star"></i>
//                                                         <i className="flaticon-star"></i>
//                                                         <i className="flaticon-star-1"></i>
//                                                     </div>
//                                                 </div>
//                                             </div>
//                                         </div>
//                                         <div className="review-body">
//                                             <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look.</p>
//                                         </div>
//                                     </div>
//                                 </div>
//                                 <div className="client-rv">
//                                     <div className="client-pic">
//                                          <img src={rv2} alt=""/>
//                                     </div>
//                                     <div className="details">
//                                         <div className="name-rating-time">
//                                             <div className="name-rating">
//                                                 <div>
//                                                     <h4>Maria Bannet</h4>
//                                                 </div>
//                                                 <div className="product-rt">
//                                                     <span>28 Sep 2024</span>
//                                                     <div className="rating">
//                                                         <i className="flaticon-star"></i>
//                                                         <i className="flaticon-star"></i>
//                                                         <i className="flaticon-star"></i>
//                                                         <i className="flaticon-star"></i>
//                                                         <i className="flaticon-star-1"></i>
//                                                     </div>
//                                                 </div>
//                                             </div>
//                                         </div>
//                                         <div className="review-body">
//                                             <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look.</p>
//                                         </div>
//                                     </div>
//                                 </div>
//                             </div>
//                             <div className="col col-lg-12 col-12 review-form-wrapper">
//                                 <div className="review-form">
//                                     <h4>Add a review</h4>
//                                     <p>Your email address will not be published. Required fields are marked *</p>
//                                     <form onSubmit={SubmitHandler}>
//                                         <div className="give-rat-sec">
//                                             <p>Your rating *</p>
//                                             <div className="give-rating">
//                                                 <label>
//                                                     <input type="radio" name="stars" value="1" />
//                                                     <span className="icon">★</span>
//                                                 </label>
//                                                 <label>
//                                                     <input type="radio" name="stars" value="2" />
//                                                     <span className="icon">★</span>
//                                                     <span className="icon">★</span>
//                                                 </label>
//                                                 <label>
//                                                     <input type="radio" name="stars" value="3" />
//                                                     <span className="icon">★</span>
//                                                     <span className="icon">★</span>
//                                                     <span className="icon">★</span>
//                                                 </label>
//                                                 <label>
//                                                     <input type="radio" name="stars" value="4" />
//                                                     <span className="icon">★</span>
//                                                     <span className="icon">★</span>
//                                                     <span className="icon">★</span>
//                                                     <span className="icon">★</span>
//                                                 </label>
//                                                 <label>
//                                                     <input type="radio" name="stars" value="5" />
//                                                     <span className="icon">★</span>
//                                                     <span className="icon">★</span>
//                                                     <span className="icon">★</span>
//                                                     <span className="icon">★</span>
//                                                     <span className="icon">★</span>
//                                                 </label>
//                                             </div>
//                                         </div>
//                                         <div>
//                                             <input type="text" className="form-control" placeholder="Name *"
//                                                 required/>
//                                         </div>
//                                         <div>
//                                             <input type="email" className="form-control" placeholder="Email *"
//                                                 required/>
//                                         </div>
//                                         <div>
//                                             <textarea className="form-control"
//                                                 placeholder="Review *"></textarea>
//                                         </div>
//                                         <div className="rating-wrapper">
//                                             <div className="submit">
//                                             <button type="submit" className="theme-btn-s2">Post
//                                                     review</button>
//                                             </div>
//                                         </div>
//                                     </form>
//                                 </div>
//                             </div>
//                         </div>
//                         </TabPane>
//                     </TabContent>
//                 </div>
//             </div>
//         </div>
//     );
// }
// export default ProductTabs;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/ProductSinglePage/index.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/react-redux/es/index.js [client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$components$2f$connect$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__connect$3e$__ = __turbopack_context__.i("[project]/node_modules/react-redux/es/components/connect.js [client] (ecmascript) <export default as connect>");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/Navbar/Navbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/pagetitle/PageTitle.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/scrollbar/scrollbar.js [client] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module '../../store/actions/action'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$ProductSinglePage$2f$product$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/ProductSinglePage/product.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/api/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$ProductSinglePage$2f$alltab$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/ProductSinglePage/alltab.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/footer/Footer.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/logo-2.svg.mjs { IMAGE => "[project]/helpers/images/logo-2.svg (static in ecmascript)" } [client] (structured image object, ecmascript)');
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
const ProductSinglePage = (props)=>{
    _s();
    const { slug } = useParams();
    const productsArray = (0, __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"])();
    const Allproduct = productsArray;
    const { addToCart: addToCart1 } = props;
    const [product, setProduct] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])({});
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProductSinglePage.useEffect": ()=>{
            setProduct(Allproduct.filter({
                "ProductSinglePage.useEffect": (Allproduct)=>Allproduct.slug === String(slug)
            }["ProductSinglePage.useEffect"]));
        }
    }["ProductSinglePage.useEffect"], []);
    const item = product[0];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-header wpo-site-header-s2',
                Logo: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/ProductSinglePage/index.js",
                lineNumber: 33,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                pageTitle: 'Shop Single',
                pagesub: 'Shop Single'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/ProductSinglePage/index.js",
                lineNumber: 34,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "shop_single section-padding",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container",
                    children: [
                        item ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$ProductSinglePage$2f$product$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                            item: item,
                            addToCart: addToCart1
                        }, void 0, false, {
                            fileName: "[project]/helpers/main-component/ProductSinglePage/index.js",
                            lineNumber: 37,
                            columnNumber: 29
                        }, this) : null,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$ProductSinglePage$2f$alltab$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/ProductSinglePage/index.js",
                            lineNumber: 41,
                            columnNumber: 21
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/helpers/main-component/ProductSinglePage/index.js",
                    lineNumber: 36,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/ProductSinglePage/index.js",
                lineNumber: 35,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-footer_s2'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/ProductSinglePage/index.js",
                lineNumber: 44,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/ProductSinglePage/index.js",
                lineNumber: 45,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/helpers/main-component/ProductSinglePage/index.js",
        lineNumber: 32,
        columnNumber: 9
    }, this);
};
_s(ProductSinglePage, "5wZiogZnxV0H5Q4n/ZZfvk0w1xk=", true);
_c = ProductSinglePage;
const mapStateToProps = (state)=>{
    return {
        products: state.data.products
    };
};
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$components$2f$connect$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__connect$3e$__["connect"])(mapStateToProps, {
    addToCart
})(ProductSinglePage);
var _c;
__turbopack_context__.k.register(_c, "ProductSinglePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/CartPage/CalculateShipping.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
const countries = [
    'United Arab Emirates',
    'United Kingdom (UK)',
    'Ukraine',
    'United States (US)',
    'Uzbekistan',
    'Virgin Islands (British)',
    'United Arab Emirates',
    'United Kingdom (UK)',
    'Ukraine',
    'United States (US)',
    'Bangladesh',
    'Uzbekistan',
    'Virgin Islands (British)'
];
const CalculateShipping = ()=>{
    _s();
    const [formVisible, setFormVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [countryListVisible, setCountryListVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [searchQuery, setSearchQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [selectedCountry, setSelectedCountry] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])('United Kingdom (UK)');
    const toggleFormVisibility = ()=>{
        setFormVisible(!formVisible);
    };
    const toggleCountryListVisibility = ()=>{
        setCountryListVisible(!countryListVisible);
    };
    const handleCountrySelect = (country)=>{
        setSelectedCountry(country);
        setCountryListVisible(false);
    };
    const filteredCountries = countries.filter((country)=>country.toLowerCase().includes(searchQuery.toLowerCase()));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "calculate-shipping",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                className: "calculate-shipping-label",
                onClick: toggleFormVisibility,
                children: [
                    "Calculate Shipping",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                        className: "flaticon-next fi"
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/CartPage/CalculateShipping.js",
                        lineNumber: 46,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/helpers/main-component/CartPage/CalculateShipping.js",
                lineNumber: 44,
                columnNumber: 13
            }, this),
            formVisible && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                action: "#",
                className: "calculate-shipping-form",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "country-list",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "country-list-label",
                                onClick: toggleCountryListVisibility,
                                children: [
                                    selectedCountry,
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                        className: "flaticon-next fi"
                                    }, void 0, false, {
                                        fileName: "[project]/helpers/main-component/CartPage/CalculateShipping.js",
                                        lineNumber: 53,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/helpers/main-component/CartPage/CalculateShipping.js",
                                lineNumber: 51,
                                columnNumber: 25
                            }, this),
                            countryListVisible && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "countries-wrapper",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "country-search",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "search",
                                                className: "form-control",
                                                placeholder: "Search..",
                                                value: searchQuery,
                                                onChange: (e)=>setSearchQuery(e.target.value)
                                            }, void 0, false, {
                                                fileName: "[project]/helpers/main-component/CartPage/CalculateShipping.js",
                                                lineNumber: 58,
                                                columnNumber: 37
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                    className: "fi flaticon-search"
                                                }, void 0, false, {
                                                    fileName: "[project]/helpers/main-component/CartPage/CalculateShipping.js",
                                                    lineNumber: 66,
                                                    columnNumber: 41
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/helpers/main-component/CartPage/CalculateShipping.js",
                                                lineNumber: 65,
                                                columnNumber: 37
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/helpers/main-component/CartPage/CalculateShipping.js",
                                        lineNumber: 57,
                                        columnNumber: 33
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                        children: filteredCountries.map((country, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                onClick: ()=>handleCountrySelect(country),
                                                children: country
                                            }, index, false, {
                                                fileName: "[project]/helpers/main-component/CartPage/CalculateShipping.js",
                                                lineNumber: 71,
                                                columnNumber: 41
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/helpers/main-component/CartPage/CalculateShipping.js",
                                        lineNumber: 69,
                                        columnNumber: 33
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/helpers/main-component/CartPage/CalculateShipping.js",
                                lineNumber: 56,
                                columnNumber: 29
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/helpers/main-component/CartPage/CalculateShipping.js",
                        lineNumber: 50,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "form-group",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "text",
                            className: "form-control",
                            placeholder: "State / County"
                        }, void 0, false, {
                            fileName: "[project]/helpers/main-component/CartPage/CalculateShipping.js",
                            lineNumber: 80,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/CartPage/CalculateShipping.js",
                        lineNumber: 79,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "form-group",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "text",
                            className: "form-control",
                            placeholder: "Town / City"
                        }, void 0, false, {
                            fileName: "[project]/helpers/main-component/CartPage/CalculateShipping.js",
                            lineNumber: 83,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/CartPage/CalculateShipping.js",
                        lineNumber: 82,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "form-group",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "text",
                            className: "form-control",
                            placeholder: "Postcode / ZIP"
                        }, void 0, false, {
                            fileName: "[project]/helpers/main-component/CartPage/CalculateShipping.js",
                            lineNumber: 86,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/CartPage/CalculateShipping.js",
                        lineNumber: 85,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "form-group",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "submit",
                            className: "btn theme-btn-s2",
                            children: "Update"
                        }, void 0, false, {
                            fileName: "[project]/helpers/main-component/CartPage/CalculateShipping.js",
                            lineNumber: 89,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/CartPage/CalculateShipping.js",
                        lineNumber: 88,
                        columnNumber: 21
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/helpers/main-component/CartPage/CalculateShipping.js",
                lineNumber: 49,
                columnNumber: 17
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/helpers/main-component/CartPage/CalculateShipping.js",
        lineNumber: 43,
        columnNumber: 9
    }, this);
};
_s(CalculateShipping, "gcFuzUgPP6UIClp4n7zuXChfZ24=");
_c = CalculateShipping;
const __TURBOPACK__default__export__ = CalculateShipping;
var _c;
__turbopack_context__.k.register(_c, "CalculateShipping");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/CartPage/index.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/Navbar/Navbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/pagetitle/PageTitle.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/scrollbar/scrollbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$CartPage$2f$CalculateShipping$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/CartPage/CalculateShipping.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/footer/Footer.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/link.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/react-redux/es/index.js [client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$components$2f$connect$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__connect$3e$__ = __turbopack_context__.i("[project]/node_modules/react-redux/es/components/connect.js [client] (ecmascript) <export default as connect>");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$utils$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/utils/index.js [client] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module '../../store/actions/action'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/logo-2.svg.mjs { IMAGE => "[project]/helpers/images/logo-2.svg (static in ecmascript)" } [client] (structured image object, ecmascript)');
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
const CartPage = (props)=>{
    _s();
    const ClickHandler = ()=>{
        window.scrollTo(10, 0);
    };
    const { carts } = props;
    const [shippingMethod, setShippingMethod] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])('Free');
    const handleShippingChange = (e)=>{
        setShippingMethod(e.target.id);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-header wpo-site-header-s2',
                Logo: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/CartPage/index.js",
                lineNumber: 33,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                pageTitle: "Cart",
                pagesub: "Cart"
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/CartPage/index.js",
                lineNumber: 34,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "cart-area-s2 section-padding",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "row",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "col-12",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "single-page-title",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                            children: "Your Cart"
                                        }, void 0, false, {
                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                            lineNumber: 40,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            children: [
                                                "There are ",
                                                carts.length,
                                                " products in this list"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                            lineNumber: 41,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/helpers/main-component/CartPage/index.js",
                                    lineNumber: 39,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/helpers/main-component/CartPage/index.js",
                                lineNumber: 38,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                            lineNumber: 37,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "cart-wrapper",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "row",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "col-lg-8 col-12",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                                            action: "#",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "cart-item",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                                        className: "table-responsive cart-wrap",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                            className: "images images-b",
                                                                            children: "Product"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                            lineNumber: 53,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                            className: "ptice",
                                                                            children: "Price"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                            lineNumber: 54,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                            className: "stock",
                                                                            children: "Quantity"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                            lineNumber: 55,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                            className: "ptice total",
                                                                            children: "Subtotal"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                            lineNumber: 56,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                                            className: "remove remove-b",
                                                                            children: "Remove"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                            lineNumber: 57,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                    lineNumber: 52,
                                                                    columnNumber: 25
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                lineNumber: 51,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                                                children: carts.map((catItem, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                                        className: "wishlist-item",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                                className: "product-item-wish",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                        className: "check-box",
                                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                            type: "checkbox",
                                                                                            className: "myproject-checkbox"
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                            lineNumber: 64,
                                                                                            columnNumber: 58
                                                                                        }, this)
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                        lineNumber: 64,
                                                                                        columnNumber: 31
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                        className: "images",
                                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                                                                src: catItem.proImg,
                                                                                                alt: ""
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                                lineNumber: 69,
                                                                                                columnNumber: 35
                                                                                            }, this)
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                            lineNumber: 68,
                                                                                            columnNumber: 33
                                                                                        }, this)
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                        lineNumber: 67,
                                                                                        columnNumber: 31
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                        className: "product",
                                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                                                            children: [
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                                                    className: "first-cart",
                                                                                                    children: catItem.title
                                                                                                }, void 0, false, {
                                                                                                    fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                                    lineNumber: 74,
                                                                                                    columnNumber: 35
                                                                                                }, this),
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                                        className: "rating-product",
                                                                                                        children: [
                                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                                                                                className: "fi flaticon-star"
                                                                                                            }, void 0, false, {
                                                                                                                fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                                                lineNumber: 77,
                                                                                                                columnNumber: 39
                                                                                                            }, this),
                                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                                                                                className: "fi flaticon-star"
                                                                                                            }, void 0, false, {
                                                                                                                fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                                                lineNumber: 78,
                                                                                                                columnNumber: 39
                                                                                                            }, this),
                                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                                                                                className: "fi flaticon-star"
                                                                                                            }, void 0, false, {
                                                                                                                fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                                                lineNumber: 79,
                                                                                                                columnNumber: 39
                                                                                                            }, this),
                                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                                                                                className: "fi flaticon-star"
                                                                                                            }, void 0, false, {
                                                                                                                fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                                                lineNumber: 80,
                                                                                                                columnNumber: 39
                                                                                                            }, this),
                                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                                                                                className: "fi flaticon-star"
                                                                                                            }, void 0, false, {
                                                                                                                fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                                                lineNumber: 81,
                                                                                                                columnNumber: 39
                                                                                                            }, this),
                                                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                                                children: "130"
                                                                                                            }, void 0, false, {
                                                                                                                fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                                                lineNumber: 82,
                                                                                                                columnNumber: 39
                                                                                                            }, this)
                                                                                                        ]
                                                                                                    }, void 0, true, {
                                                                                                        fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                                        lineNumber: 76,
                                                                                                        columnNumber: 37
                                                                                                    }, this)
                                                                                                }, void 0, false, {
                                                                                                    fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                                    lineNumber: 75,
                                                                                                    columnNumber: 35
                                                                                                }, this)
                                                                                            ]
                                                                                        }, void 0, true, {
                                                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                            lineNumber: 73,
                                                                                            columnNumber: 33
                                                                                        }, this)
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                        lineNumber: 72,
                                                                                        columnNumber: 31
                                                                                    }, this)
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                lineNumber: 63,
                                                                                columnNumber: 29
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                                className: "ptice",
                                                                                children: [
                                                                                    "$",
                                                                                    catItem.price
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                lineNumber: 88,
                                                                                columnNumber: 29
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                                className: "td-quantity",
                                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: "quantity cart-plus-minus",
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                            className: "text-value",
                                                                                            type: "text",
                                                                                            value: catItem.qty,
                                                                                            onChange: (e)=>handleQuantityChange(e, catItem.id)
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                            lineNumber: 91,
                                                                                            columnNumber: 33
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                            className: "dec qtybutton",
                                                                                            onClick: ()=>props.decrementQuantity(catItem.id),
                                                                                            children: "-"
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                            lineNumber: 92,
                                                                                            columnNumber: 33
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                            className: "inc qtybutton",
                                                                                            onClick: ()=>props.incrementQuantity(catItem.id),
                                                                                            children: "+"
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                            lineNumber: 93,
                                                                                            columnNumber: 33
                                                                                        }, this)
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                    lineNumber: 90,
                                                                                    columnNumber: 31
                                                                                }, this)
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                lineNumber: 89,
                                                                                columnNumber: 29
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                                className: "ptice",
                                                                                children: [
                                                                                    "$",
                                                                                    catItem.qty * catItem.price
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                lineNumber: 96,
                                                                                columnNumber: 29
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                                                className: "action",
                                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                                        className: "w-btn",
                                                                                        onClick: ()=>props.removeFromCart(catItem.id),
                                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                                                            className: "fi ti-trash"
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                            lineNumber: 99,
                                                                                            columnNumber: 104
                                                                                        }, this)
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                        lineNumber: 99,
                                                                                        columnNumber: 33
                                                                                    }, this)
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                    lineNumber: 98,
                                                                                    columnNumber: 31
                                                                                }, this)
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                lineNumber: 97,
                                                                                columnNumber: 29
                                                                            }, this)
                                                                        ]
                                                                    }, index, true, {
                                                                        fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                        lineNumber: 62,
                                                                        columnNumber: 27
                                                                    }, this))
                                                            }, void 0, false, {
                                                                fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                lineNumber: 60,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                        lineNumber: 50,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                    lineNumber: 49,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "cart-action",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "apply-area",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "text",
                                                                    className: "form-control",
                                                                    placeholder: "Enter your coupon"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                    lineNumber: 110,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    className: "theme-btn-s2",
                                                                    type: "submit",
                                                                    children: "Apply"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                    lineNumber: 111,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                            lineNumber: 109,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            className: "theme-btn-s2",
                                                            type: "button",
                                                            onClick: ClickHandler,
                                                            children: "Update Cart"
                                                        }, void 0, false, {
                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                            lineNumber: 113,
                                                            columnNumber: 20
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                    lineNumber: 108,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                            lineNumber: 48,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/helpers/main-component/CartPage/index.js",
                                        lineNumber: 47,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "col-lg-4 col-12",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "cart-total-wrap",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    children: "Cart Totals"
                                                }, void 0, false, {
                                                    fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                    lineNumber: 121,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "sub-total",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                            children: "Subtotal"
                                                        }, void 0, false, {
                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                            lineNumber: 123,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: [
                                                                "$",
                                                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$utils$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["totalPrice"])(carts)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                            lineNumber: 124,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                    lineNumber: 122,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "shipping-option",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: "Shipping"
                                                        }, void 0, false, {
                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                            lineNumber: 127,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                    className: "free",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                            id: "Free",
                                                                            type: "radio",
                                                                            name: "shipping",
                                                                            value: "0",
                                                                            checked: shippingMethod === 'Free',
                                                                            onChange: handleShippingChange
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                            lineNumber: 130,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                            htmlFor: "Free",
                                                                            children: "Free Shipping"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                            lineNumber: 131,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                    lineNumber: 129,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                    className: "free",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                            id: "Local",
                                                                            type: "radio",
                                                                            name: "shipping",
                                                                            value: "10",
                                                                            checked: shippingMethod === 'Local',
                                                                            onChange: handleShippingChange
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                            lineNumber: 134,
                                                                            columnNumber: 25
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                            htmlFor: "Local",
                                                                            children: [
                                                                                "Local Pickup: ",
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                    children: "$10.00"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                                    lineNumber: 135,
                                                                                    columnNumber: 62
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                            lineNumber: 135,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                    lineNumber: 133,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                                    className: "free",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        children: "Shipping options will be updated during checkout."
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                        lineNumber: 138,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                                    lineNumber: 137,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                            lineNumber: 128,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                    lineNumber: 126,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$CartPage$2f$CalculateShipping$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                    fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                    lineNumber: 142,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "total",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                            children: "Total"
                                                        }, void 0, false, {
                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                            lineNumber: 144,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: [
                                                                "$",
                                                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$utils$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["totalPrice"])(carts) + (shippingMethod === 'Local' ? 10 : 0)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                            lineNumber: 145,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                    lineNumber: 143,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                                    className: "theme-btn-s2",
                                                    href: "/checkout",
                                                    children: "Proceed To Checkout"
                                                }, void 0, false, {
                                                    fileName: "[project]/helpers/main-component/CartPage/index.js",
                                                    lineNumber: 147,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                                            lineNumber: 120,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/helpers/main-component/CartPage/index.js",
                                        lineNumber: 119,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/helpers/main-component/CartPage/index.js",
                                lineNumber: 46,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/helpers/main-component/CartPage/index.js",
                            lineNumber: 45,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/helpers/main-component/CartPage/index.js",
                    lineNumber: 36,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/CartPage/index.js",
                lineNumber: 35,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-footer_s2'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/CartPage/index.js",
                lineNumber: 154,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/CartPage/index.js",
                lineNumber: 155,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/helpers/main-component/CartPage/index.js",
        lineNumber: 32,
        columnNumber: 5
    }, this);
};
_s(CartPage, "TCpjubZa7J6lFctyd0yHTHiz1Ms=");
_c = CartPage;
const mapStateToProps = (state)=>{
    return {
        carts: state.cartList.cart
    };
};
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$components$2f$connect$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__connect$3e$__["connect"])(mapStateToProps, {
    removeFromCart,
    incrementQuantity,
    decrementQuantity
})(CartPage);
var _c;
__turbopack_context__.k.register(_c, "CartPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/CheckoutPage/index.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/Navbar/Navbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/pagetitle/PageTitle.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$CheckoutSection$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/CheckoutSection/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/scrollbar/scrollbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/react-redux/es/index.js [client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$components$2f$connect$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__connect$3e$__ = __turbopack_context__.i("[project]/node_modules/react-redux/es/components/connect.js [client] (ecmascript) <export default as connect>");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/footer/Footer.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/logo-2.svg.mjs { IMAGE => "[project]/helpers/images/logo-2.svg (static in ecmascript)" } [client] (structured image object, ecmascript)');
;
;
;
;
;
;
;
;
;
const CheckoutPage = ({ cartList })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-header wpo-site-header-s2',
                Logo: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/CheckoutPage/index.js",
                lineNumber: 12,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                pageTitle: 'Checkout',
                pagesub: 'Checkout'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/CheckoutPage/index.js",
                lineNumber: 13,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$CheckoutSection$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                cartList: cartList
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/CheckoutPage/index.js",
                lineNumber: 14,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-footer_s2'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/CheckoutPage/index.js",
                lineNumber: 15,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/CheckoutPage/index.js",
                lineNumber: 16,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/helpers/main-component/CheckoutPage/index.js",
        lineNumber: 11,
        columnNumber: 9
    }, this);
};
_c = CheckoutPage;
const mapStateToProps = (state)=>{
    return {
        cartList: state.cartList.cart,
        symbol: state.data.symbol
    };
};
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$components$2f$connect$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__connect$3e$__["connect"])(mapStateToProps)(CheckoutPage);
var _c;
__turbopack_context__.k.register(_c, "CheckoutPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/OrderRecived/index.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/react-redux/es/index.js [client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$components$2f$connect$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__connect$3e$__ = __turbopack_context__.i("[project]/node_modules/react-redux/es/components/connect.js [client] (ecmascript) <export default as connect>");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$OrderRecivedSec$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/OrderRecivedSec/index.js [client] (ecmascript)");
;
;
;
;
const OrderRecived = ({ cartList })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$OrderRecivedSec$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
            cartList: cartList
        }, void 0, false, {
            fileName: "[project]/helpers/main-component/OrderRecived/index.js",
            lineNumber: 11,
            columnNumber: 14
        }, this)
    }, void 0, false, {
        fileName: "[project]/helpers/main-component/OrderRecived/index.js",
        lineNumber: 10,
        columnNumber: 9
    }, this);
};
_c = OrderRecived;
const mapStateToProps = (state)=>{
    return {
        cartList: state.cartList.cart,
        symbol: state.data.symbol
    };
};
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$es$2f$components$2f$connect$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$export__default__as__connect$3e$__["connect"])(mapStateToProps)(OrderRecived);
var _c;
__turbopack_context__.k.register(_c, "OrderRecived");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/FaqPage/FaqPage.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/Navbar/Navbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/pagetitle/PageTitle.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$FaqSection$2f$FaqSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/FaqSection/FaqSection.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/footer/Footer.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/scrollbar/scrollbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/logo-2.svg.mjs { IMAGE => "[project]/helpers/images/logo-2.svg (static in ecmascript)" } [client] (structured image object, ecmascript)');
;
;
;
;
;
;
;
;
const ProjectPage = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-header wpo-site-header-s2',
                Logo: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/FaqPage/FaqPage.js",
                lineNumber: 13,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                pageTitle: 'Faq',
                pagesub: 'Faq'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/FaqPage/FaqPage.js",
                lineNumber: 14,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$FaqSection$2f$FaqSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/FaqPage/FaqPage.js",
                lineNumber: 15,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-footer_s2'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/FaqPage/FaqPage.js",
                lineNumber: 16,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/FaqPage/FaqPage.js",
                lineNumber: 17,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/helpers/main-component/FaqPage/FaqPage.js",
        lineNumber: 12,
        columnNumber: 9
    }, this);
};
_c = ProjectPage;
const __TURBOPACK__default__export__ = ProjectPage;
var _c;
__turbopack_context__.k.register(_c, "ProjectPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/ProjectSingle/ProjectSingle.js [client] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, k: __turbopack_refresh__, m: module, e: exports } = __turbopack_context__;
{
// import  { Fragment } from 'react';
// import Link from 'next/link'
// import Navbar from '../../components/Navbar/Navbar'
// import PageTitle from '../../components/pagetitle/PageTitle'
// import Projects from '../../api/projects';
// import ContactForm from '../ServiceSinglePage/ServiceFrom';
// import Footer from '../../components/footer/Footer';
// import Scrollbar from '../../components/scrollbar/scrollbar'
// import logo from '../../images/logo-2.svg'
// import Psing1 from '../../images/project-single/img-1.jpg'
// import Psing2 from '../../images/project-single/img-2.jpg'
// const ClickHandler = () => {
//     window.scrollTo(10, 0);
// }
// const ProjectSingle = () => {
//     const { slug } = useParams()
//     const ProjectSingle = Projects.find(item => item.slug === slug)
//     return (
//         <Fragment>
//             <Navbar Logo={logo} hclass={'wpo-site-header wpo-site-header-s2'} />
//             <PageTitle pageTitle={ProjectSingle.title} pagesub={'Portfolio'} />
//             <section className="project_single section-padding">
//                 <div className="container">
//                     <img src={ProjectSingle.pSimg} alt="" />
//                     <div className="row">
//                         <div className="col-lg-7 col-12">
//                             <h2>{ProjectSingle.title}</h2>
//                             <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dis posuere amet tincidunt
//                                 commodo, velit. Ipsum, hac nibh fermentum nisi, platea condimentum cursus velit dui. Massa
//                                 volutpat odio facilisis purus sit elementum. Non, sed velit dictum quam. Id risus pharetra
//                                 est, at rhoncus, nec ullamcorper tincidunt. Id aliquet duis sollicitudin diam, elit sit. Et
//                                 nisi in libero facilisis sed est. Elit curabitur amet risus bibendum. Posuere et eget orci,
//                                 tempor enim.Non, sed velit dictum quam. Id risus pharetra est, at rhoncus, nec ullamcorper
//                                 tincidunt.</p>
//                             <p>Hac nibh fermentum nisi, platea condimentum cursus velit dui. Massa voluat odio facilisis
//                                 purus sit elementum. Non, sed velit dictum quam. Id risus pharetra est, at rhoncus, nec
//                                 ullamcorper tincidunt. Id aliquet duis sollicitudin diam, elit sit.</p>
//                         </div>
//                         <div className="col-lg-5 col-12">
//                             <table>
//                                 <tbody>
//                                     <tr>
//                                         <th>Location :</th>
//                                         <td>{ProjectSingle.location}</td>
//                                     </tr>
//                                     <tr>
//                                         <th>Client :</th>
//                                         <td>Robert William</td>
//                                     </tr>
//                                     <tr>
//                                         <th>Surgeon:</th>
//                                         <td>Harry Johnson</td>
//                                     </tr>
//                                     <tr>
//                                         <th>Category :</th>
//                                         <td>Surgery</td>
//                                     </tr>
//                                     <tr>
//                                         <th>Tag :</th>
//                                         <td>Pediatric, Pain</td>
//                                     </tr>
//                                     <tr>
//                                         <th>Date :</th>
//                                         <td>{ProjectSingle.date}</td>
//                                     </tr>
//                                     <tr>
//                                         <th>Share :</th>
//                                         <td>
//                                             <ul>
//                                                 <li>
//                                                     <a href="https://facebook.com" target="_blank" rel="noopener noreferrer">
//                                                         <i className="flaticon-facebook-app-symbol"></i>
//                                                     </a>
//                                                 </li>
//                                                 <li>
//                                                     <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">
//                                                         <i className="flaticon-twitter"></i>
//                                                     </a>
//                                                 </li>
//                                                 <li>
//                                                     <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer">
//                                                         <i className="flaticon-linkedin"></i>
//                                                     </a>
//                                                 </li>
//                                                 <li>
//                                                     <a href="https://instagram.com" target="_blank" rel="noopener noreferrer">
//                                                         <i className="flaticon-instagram"></i>
//                                                     </a>
//                                                 </li>
//                                             </ul>
//                                         </td>
//                                     </tr>
//                                 </tbody>
//                             </table>
//                         </div>
//                     </div>
//                     <div className="quote">
//                         <h4>"Amazing looking theme and instantly turns your application into a great looking one. Really
//                             shows that pro_ fissional built this theme up. Very happy with the way the theme looks ."</h4>
//                         <p>Robert - <span>Yellow Theme</span></p>
//                     </div>
//                     <div className="row">
//                         <div className="col-lg-6 col-12 strategies s2">
//                             <h2>Our Strategies</h2>
//                             <p>Massa volutpat odio facilisis purus sit elementum. Nonsed velit dictum quam. Id risus
//                                 pharetra est, at rhoncus, nec ullamcorper tincidunt. Id aliquet duis sollicitudin diam.</p>
//                             <ul>
//                                 <li>Non saed velit dictum quam risus pharetra esta.</li>
//                                 <li>Id risus pharetra est, at rhoncus, nec ullamcorper tincidunt.</li>
//                                 <li>Hac nibh fermentum nisi, platea condimentum cursus.</li>
//                                 <li>Massa volutpat odio facilisis purus sit elementum.</li>
//                             </ul>
//                         </div>
//                         <div className="col-lg-6 col-12 strategies">
//                             <h2>Our approach</h2>
//                             <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Consequat suspendisse aenean tellus
//                                 augue morbi risus. Sit morbi vitae morbi sed urna sed purus. Orci facilisi eros sed
//                                 pellentesque. Risus id sed tortor sed scelerisque. Vestibulum elit elementum, magna id
//                                 viverra non, velit. Pretium, eros, porttitor fusce auctor. Phasellus scelerisque nibh
//                                 eleifend vel enim mauris purus. Rutrum vel sem adipiscing nisi vulputate molestie
//                                 scelerisque molestie ultrices.</p>
//                         </div>
//                     </div>
//                     <div className="row">
//                         <div className="col-lg-6 col-12">
//                             <img src={Psing1} alt="" />
//                         </div>
//                         <div className="col-lg-6 col-12">
//                             <img src={Psing2} alt="" />
//                         </div>
//                     </div>
//                     <div className="row">
//                         <div className="col-lg-6 col-12 strategies s3">
//                             <h2>Received Goals</h2>
//                             <p>Tristique donec pellentesque malesuada enim viverra. Aliquam tortor id fringilla in tincidunt
//                                 ipsum non molestie. Mattis vitae nulla in nulla habitant purus lacus nibh.</p>
//                             <ul>
//                                 <li>Feugiat tincidunt arcu blandit et maecenas est. </li>
//                                 <li>Eget a in massa scelerisque ut etiam pharetra nascetur</li>
//                                 <li>Integer laoreet vive nunc aliquam commodo integer arcu.</li>
//                                 <li>Fermentum feugiat varius faucibus habitasse.</li>
//                             </ul>
//                         </div>
//                         <div className="col-lg-6 col-12 strategies s3 ">
//                             <h2>Result</h2>
//                             <p>Nibh arcu enim amet pellentesque. Nisi quam enim re nec amet in. Leo pretium dolor sed erat
//                                 dignissim. Integer laoreet viverra nunc aliquam commodo integer arcu.</p>
//                             <ul>
//                                 <li>Mattis vitae nulla in nulla habitant purus.</li>
//                                 <li>Amet nunc augue nisi consectetur ac laoreet elit vulputate.</li>
//                                 <li>Hac nibh fermentum platea condimentum cursus.</li>
//                                 <li>Massa volutpat odio facilisis purus sit elementum.</li>
//                             </ul>
//                         </div>
//                     </div>
//                     <div className="related_project">
//                         <h5>Related Portfolio</h5>
//                         <div className="row">
//                             {Projects.slice(0, 3).map((project, pitem) => (
//                                 <div className="col-lg-4 col-md-6 col-12" key={pitem}>
//                                     <div className="project_card">
//                                         <img src={project.pimg1} alt="" />
//                                         <div className="text">
//                                             <h2><Link onClick={ClickHandler} to={`/project-single/${project.slug}`}>{project.title}</Link></h2>
//                                             <span>{project.subtitle}</span>
//                                         </div>
//                                     </div>
//                                 </div>
//                             ))}
//                         </div>
//                     </div>
//                 </div>
//                 <div className="AppointmentFrom">
//                     <div className="container">
//                         <div className="cta_form_s2">
//                             <div className="title s2">
//                                 <h3>Make An Appointment</h3>
//                                 <p>Get in touch with us to see how we can help you with your Problems.</p>
//                             </div>
//                             <ContactForm />
//                         </div>
//                     </div>
//                 </div>
//             </section>
//             <Footer hclass={'wpo-site-footer_s2'} />
//             <Scrollbar />
//         </Fragment>
//     )
// };
// export default ProjectSingle;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/ServiceSinglePage/sidebar.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/link.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$1$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$instagram$2f$1$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/instagram/1.jpg.mjs { IMAGE => "[project]/helpers/images/instagram/1.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$2$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$instagram$2f$2$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/instagram/2.jpg.mjs { IMAGE => "[project]/helpers/images/instagram/2.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$3$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$instagram$2f$3$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/instagram/3.jpg.mjs { IMAGE => "[project]/helpers/images/instagram/3.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$4$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$instagram$2f$4$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/instagram/4.jpg.mjs { IMAGE => "[project]/helpers/images/instagram/4.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$5$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$instagram$2f$5$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/instagram/5.jpg.mjs { IMAGE => "[project]/helpers/images/instagram/5.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$6$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$instagram$2f$6$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/instagram/6.jpg.mjs { IMAGE => "[project]/helpers/images/instagram/6.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
const insData = [
    {
        id: 1,
        img: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$1$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$instagram$2f$1$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    },
    {
        id: 2,
        img: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$2$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$instagram$2f$2$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    },
    {
        id: 3,
        img: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$3$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$instagram$2f$3$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    },
    {
        id: 4,
        img: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$4$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$instagram$2f$4$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    },
    {
        id: 5,
        img: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$5$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$instagram$2f$5$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    },
    {
        id: 6,
        img: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$instagram$2f$6$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$instagram$2f$6$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    }
];
const ServiceSidebar = ()=>{
    _s();
    const ClickHandler = ()=>{
        window.scrollTo(10, 0);
    };
    const [searchTerm, setSearchTerm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [showError, setShowError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleInputChange = (event)=>{
        setSearchTerm(event.target.value);
        if (showError) {
            setShowError(false);
        }
    };
    const handleSubmit = (event)=>{
        event.preventDefault();
        if (searchTerm.trim() === '') {
            setShowError(true);
        } else {
            setShowError(false);
            console.log('Searching for:', searchTerm);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "service_sidebar",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "search_widget widget",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                        className: "searchForm",
                        onSubmit: handleSubmit,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                className: "fild",
                                type: "text",
                                name: "search",
                                value: searchTerm,
                                onChange: handleInputChange,
                                placeholder: "Search..."
                            }, void 0, false, {
                                fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                lineNumber: 77,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "submit",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                    className: "flaticon-search"
                                }, void 0, false, {
                                    fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                    lineNumber: 86,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                lineNumber: 85,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                        lineNumber: 76,
                        columnNumber: 17
                    }, this),
                    showError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        style: {
                            color: 'red'
                        },
                        children: "Please enter a search term."
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                        lineNumber: 89,
                        columnNumber: 31
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                lineNumber: 75,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "services_widget widget",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        children: "Services"
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                        lineNumber: 92,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                    onClick: ClickHandler,
                                    href: "/services",
                                    children: [
                                        "Dental Care ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: "2"
                                        }, void 0, false, {
                                            fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                            lineNumber: 94,
                                            columnNumber: 83
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                    lineNumber: 94,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                lineNumber: 94,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                    onClick: ClickHandler,
                                    href: "/services",
                                    children: [
                                        "Orthopedic ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: "5"
                                        }, void 0, false, {
                                            fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                            lineNumber: 95,
                                            columnNumber: 82
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                    lineNumber: 95,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                lineNumber: 95,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                    onClick: ClickHandler,
                                    href: "/services",
                                    children: [
                                        "Pharmacology ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: "3"
                                        }, void 0, false, {
                                            fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                            lineNumber: 96,
                                            columnNumber: 84
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                    lineNumber: 96,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                lineNumber: 96,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                    onClick: ClickHandler,
                                    href: "/services",
                                    children: [
                                        "Genealogy ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: "7"
                                        }, void 0, false, {
                                            fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                            lineNumber: 97,
                                            columnNumber: 81
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                    lineNumber: 97,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                lineNumber: 97,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                    onClick: ClickHandler,
                                    href: "/services",
                                    children: [
                                        "Rehabilitation ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: "8"
                                        }, void 0, false, {
                                            fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                            lineNumber: 98,
                                            columnNumber: 86
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                    lineNumber: 98,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                lineNumber: 98,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                    onClick: ClickHandler,
                                    href: "/services",
                                    children: [
                                        "Heart Surgery ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: "4"
                                        }, void 0, false, {
                                            fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                            lineNumber: 99,
                                            columnNumber: 85
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                    lineNumber: 99,
                                    columnNumber: 25
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                lineNumber: 99,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                        lineNumber: 93,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                lineNumber: 91,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "newsletter_widget widget",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        children: "Newsletter"
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                        lineNumber: 103,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: "Join 20,000 Sabscribers!"
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                        lineNumber: 104,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                        className: "emailForm",
                        id: "emailForm",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                className: "fild",
                                type: "email",
                                name: "email",
                                id: "email2",
                                placeholder: "Email Address"
                            }, void 0, false, {
                                fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                lineNumber: 106,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "submit",
                                children: "Sign Up"
                            }, void 0, false, {
                                fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                lineNumber: 108,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                        lineNumber: 105,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: "By signing up you agree to our Privacy Policy"
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                        lineNumber: 110,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                lineNumber: 102,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "instagram_widget widget",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        children: "Instagram"
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                        lineNumber: 113,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                        children: insData.map((instag, iky)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    src: instag.img,
                                    alt: ""
                                }, void 0, false, {
                                    fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                    lineNumber: 116,
                                    columnNumber: 39
                                }, this)
                            }, iky, false, {
                                fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                                lineNumber: 116,
                                columnNumber: 25
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                        lineNumber: 114,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
                lineNumber: 112,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/helpers/main-component/ServiceSinglePage/sidebar.js",
        lineNumber: 74,
        columnNumber: 9
    }, this);
};
_s(ServiceSidebar, "XQithEYeKY8HiQBK9dMg1lL27Jo=");
_c = ServiceSidebar;
const __TURBOPACK__default__export__ = ServiceSidebar;
var _c;
__turbopack_context__.k.register(_c, "ServiceSidebar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/link.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$Services$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/api/Services.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$ServiceSinglePage$2f$ServiceFrom$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/ServiceSinglePage/ServiceFrom.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$ServiceSinglePage$2f$sidebar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/ServiceSinglePage/sidebar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/Navbar/Navbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/pagetitle/PageTitle.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/footer/Footer.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/scrollbar/scrollbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$img$2d$1$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$img$2d$1$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/service-single/img-1.jpg.mjs { IMAGE => "[project]/helpers/images/service-single/img-1.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$img$2d$2$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$img$2d$2$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/service-single/img-2.jpg.mjs { IMAGE => "[project]/helpers/images/service-single/img-2.jpg (static in ecmascript)" } [client] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/logo-2.svg.mjs { IMAGE => "[project]/helpers/images/logo-2.svg (static in ecmascript)" } [client] (structured image object, ecmascript)');
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
const ServiceSinglePage = ()=>{
    _s();
    const ClickHandler = ()=>{
        window.scrollTo(10, 0);
    };
    const { slug } = useParams();
    const serviceDetails = __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$Services$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].find((item)=>item.slug === slug);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                Logo: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                hclass: 'wpo-site-header wpo-site-header-s2'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                lineNumber: 24,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                pageTitle: serviceDetails.title,
                pagesub: 'Service Single'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                lineNumber: 25,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "service_single section-padding",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "row g-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "col-lg-8 col-12 service_content",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                src: serviceDetails.simage,
                                                alt: ""
                                            }, void 0, false, {
                                                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                lineNumber: 31,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                children: serviceDetails.title
                                            }, void 0, false, {
                                                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                lineNumber: 32,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Metus dis posuere amet tincidunt commodo, velit. Ipsum, hac nibh fermentum nisi, platea condimentum cursus velit dui. Massa volutpat odio facilisis purus sit elementum. Non, sed velit dictum quam. Id risus pharetra est, at rhoncus, nec ullamcorper tincidunt. Id aliquet duis sollicitudin diam, elit sit. Et nisi in libero facilisis sed est. Elit curabitur amet risus bibendum. Posuere et eget orci, tempor enim."
                                            }, void 0, false, {
                                                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                lineNumber: 33,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: "Hac nibh fermentum nisi, platea condimentum cursus velit dui. Massa volutpat odio facilisis purus sit elementum. Non, sed velit dictum quam. Id risus pharetra est, at rhoncus, nec ullamcorper tincidunt. Id aliquet duis sollicitudin diam, elit sit."
                                            }, void 0, false, {
                                                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                lineNumber: 43,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                        lineNumber: 30,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "row",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "col-lg-6 col-12",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$img$2d$1$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$img$2d$1$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                                    alt: ""
                                                }, void 0, false, {
                                                    fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                    lineNumber: 50,
                                                    columnNumber: 37
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                lineNumber: 49,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "col-lg-6 col-12",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$img$2d$2$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$service$2d$single$2f$img$2d$2$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                                                    alt: ""
                                                }, void 0, false, {
                                                    fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                    lineNumber: 53,
                                                    columnNumber: 37
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                lineNumber: 52,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                        lineNumber: 48,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                children: "Our Capabilities"
                                            }, void 0, false, {
                                                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                lineNumber: 57,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: "Massa volutpat odio facilisis purus sit elementum. Non, sed velit dictum quam. Id risus pharetra est, at rhoncus, nec ullamcorper tincidunt. Id aliquet duis sollicitudin diam."
                                            }, void 0, false, {
                                                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                lineNumber: 58,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                        children: "Non saed velit dictum quam risus pharetra esta."
                                                    }, void 0, false, {
                                                        fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                        lineNumber: 62,
                                                        columnNumber: 37
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                        children: "Id risus pharetra est, at rhoncus, nec ullamcorper tincidunt."
                                                    }, void 0, false, {
                                                        fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                        lineNumber: 63,
                                                        columnNumber: 37
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                        children: "Hac nibh fermentum nisi, platea condimentum cursus."
                                                    }, void 0, false, {
                                                        fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                        lineNumber: 64,
                                                        columnNumber: 37
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                        children: "Massa volutpat odio facilisis purus sit elementum."
                                                    }, void 0, false, {
                                                        fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                        lineNumber: 65,
                                                        columnNumber: 37
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                        children: "Elit curabitur amet risus bibendum."
                                                    }, void 0, false, {
                                                        fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                        lineNumber: 66,
                                                        columnNumber: 37
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                lineNumber: 61,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                        lineNumber: 56,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                children: "Our approach"
                                            }, void 0, false, {
                                                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                lineNumber: 70,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Consequat suspendisse aenean tellus augue morbi risus. Sit morbi vitae morbi sed urna sed purus. Orci facilisi eros sed pellentesque. Risus id sed tortor sed scelerisque. Vestibulum elit elementum, magna id viverra non, velit. Pretium, eros, porttitor fusce auctor vitae id. Phasellus scelerisque nibh eleifend vel enim mauris purus. Rutrum vel sem adipiscing nisi vulputate molestie scelerisque molestie ultrices. Eu, fusce vulputate diam interdum morbi ac a."
                                            }, void 0, false, {
                                                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                lineNumber: 71,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                        lineNumber: 69,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "other-service",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                children: "Related Service"
                                            }, void 0, false, {
                                                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                lineNumber: 83,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "row",
                                                children: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$Services$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].slice(0, 3).map((serves, sitem)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "col-lg-4 col-md-6 col-12",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "service_card",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "icon",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                                        className: serves.icon
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                                        lineNumber: 89,
                                                                        columnNumber: 53
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                                    lineNumber: 88,
                                                                    columnNumber: 49
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "content",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                                            children: serves.title
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                                            lineNumber: 92,
                                                                            columnNumber: 53
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                            children: serves.description
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                                            lineNumber: 93,
                                                                            columnNumber: 53
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$link$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                                                                            onClick: ClickHandler,
                                                                            to: `/service-single/${serves.slug}`,
                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                                                                className: "flaticon-right-arrow"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                                                lineNumber: 94,
                                                                                columnNumber: 120
                                                                            }, this)
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                                            lineNumber: 94,
                                                                            columnNumber: 53
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                                    lineNumber: 91,
                                                                    columnNumber: 49
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                            lineNumber: 87,
                                                            columnNumber: 45
                                                        }, this)
                                                    }, sitem, false, {
                                                        fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                        lineNumber: 86,
                                                        columnNumber: 41
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                lineNumber: 84,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                        lineNumber: 82,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "cta_form_s2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "title",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                        children: "Make An Appointment"
                                                    }, void 0, false, {
                                                        fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                        lineNumber: 103,
                                                        columnNumber: 37
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        children: "Get in touch with us to see how we can help you with your Problems."
                                                    }, void 0, false, {
                                                        fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                        lineNumber: 104,
                                                        columnNumber: 37
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                lineNumber: 102,
                                                columnNumber: 33
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$ServiceSinglePage$2f$ServiceFrom$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                                lineNumber: 106,
                                                columnNumber: 33
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                        lineNumber: 101,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                lineNumber: 29,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "col-lg-4 col-12",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$ServiceSinglePage$2f$sidebar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                    lineNumber: 111,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                                lineNumber: 110,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                        lineNumber: 28,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                    lineNumber: 27,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                lineNumber: 26,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-footer_s2'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                lineNumber: 116,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
                lineNumber: 117,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js",
        lineNumber: 23,
        columnNumber: 9
    }, this);
};
_s(ServiceSinglePage, "DpOdpe+T7d3Ytb7f6neHj0L13w0=", true);
_c = ServiceSinglePage;
const __TURBOPACK__default__export__ = ServiceSinglePage;
var _c;
__turbopack_context__.k.register(_c, "ServiceSinglePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/BlogPageLeft/BlogPageLeft.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/pagetitle/PageTitle.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$BlogList$2f$BlogList$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/BlogList/BlogList.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/scrollbar/scrollbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/Navbar/Navbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/footer/Footer.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/logo-2.svg.mjs { IMAGE => "[project]/helpers/images/logo-2.svg (static in ecmascript)" } [client] (structured image object, ecmascript)');
;
;
;
;
;
;
;
;
const BlogPageLeft = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-header wpo-site-header-s2',
                Logo: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogPageLeft/BlogPageLeft.js",
                lineNumber: 12,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                pageTitle: 'Latest News',
                pagesub: 'Blog'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogPageLeft/BlogPageLeft.js",
                lineNumber: 13,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$BlogList$2f$BlogList$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                blLeft: 'order-lg-1',
                blRight: 'order-lg-2'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogPageLeft/BlogPageLeft.js",
                lineNumber: 14,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-footer_s2'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogPageLeft/BlogPageLeft.js",
                lineNumber: 15,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogPageLeft/BlogPageLeft.js",
                lineNumber: 16,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/helpers/main-component/BlogPageLeft/BlogPageLeft.js",
        lineNumber: 11,
        columnNumber: 9
    }, this);
};
_c = BlogPageLeft;
const __TURBOPACK__default__export__ = BlogPageLeft;
var _c;
__turbopack_context__.k.register(_c, "BlogPageLeft");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/BlogPageFullwidth/BlogPageFullwidth.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/Navbar/Navbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/pagetitle/PageTitle.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$BlogList$2f$BlogList$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/BlogList/BlogList.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/scrollbar/scrollbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/footer/Footer.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/logo-2.svg.mjs { IMAGE => "[project]/helpers/images/logo-2.svg (static in ecmascript)" } [client] (structured image object, ecmascript)');
;
;
;
;
;
;
;
;
const BlogPageFullwidth = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-header wpo-site-header-s2',
                Logo: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogPageFullwidth/BlogPageFullwidth.js",
                lineNumber: 13,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                pageTitle: 'Latest News',
                pagesub: 'Blog'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogPageFullwidth/BlogPageFullwidth.js",
                lineNumber: 14,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$BlogList$2f$BlogList$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                blLeft: 'd-none',
                blRight: 'col-lg-10 offset-lg-1'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogPageFullwidth/BlogPageFullwidth.js",
                lineNumber: 15,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-footer_s2'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogPageFullwidth/BlogPageFullwidth.js",
                lineNumber: 16,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogPageFullwidth/BlogPageFullwidth.js",
                lineNumber: 17,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/helpers/main-component/BlogPageFullwidth/BlogPageFullwidth.js",
        lineNumber: 12,
        columnNumber: 9
    }, this);
};
_c = BlogPageFullwidth;
const __TURBOPACK__default__export__ = BlogPageFullwidth;
var _c;
__turbopack_context__.k.register(_c, "BlogPageFullwidth");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/BlogDetails/BlogDetails.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/Navbar/Navbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/pagetitle/PageTitle.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/scrollbar/scrollbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$blogs$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/api/blogs.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$BlogDetails$2f$BlogSingle$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/BlogDetails/BlogSingle.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/footer/Footer.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/logo-2.svg.mjs { IMAGE => "[project]/helpers/images/logo-2.svg (static in ecmascript)" } [client] (structured image object, ecmascript)');
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
const BlogDetails = ()=>{
    _s();
    const { slug } = useParams();
    const BlogDetails = __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$blogs$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].find((item)=>item.slug === slug);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                Logo: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                hclass: 'wpo-site-header wpo-site-header-s2'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogDetails/BlogDetails.js",
                lineNumber: 17,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                pageTitle: BlogDetails.title,
                pagesub: 'Blog Single'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogDetails/BlogDetails.js",
                lineNumber: 18,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$BlogDetails$2f$BlogSingle$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogDetails/BlogDetails.js",
                lineNumber: 19,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: "wpo-site-footer_s2"
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogDetails/BlogDetails.js",
                lineNumber: 20,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogDetails/BlogDetails.js",
                lineNumber: 21,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/helpers/main-component/BlogDetails/BlogDetails.js",
        lineNumber: 16,
        columnNumber: 9
    }, this);
};
_s(BlogDetails, "DpOdpe+T7d3Ytb7f6neHj0L13w0=", true);
_c = BlogDetails;
const __TURBOPACK__default__export__ = BlogDetails;
var _c;
__turbopack_context__.k.register(_c, "BlogDetails");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/BlogDetailsLeftSiide/BlogDetailsLeftSiide.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/pagetitle/PageTitle.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$BlogDetails$2f$BlogSingle$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/BlogDetails/BlogSingle.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/scrollbar/scrollbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$blogs$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/api/blogs.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/Navbar/Navbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/footer/Footer.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/logo-2.svg.mjs { IMAGE => "[project]/helpers/images/logo-2.svg (static in ecmascript)" } [client] (structured image object, ecmascript)');
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
const BlogDetailsLeftSiide = ()=>{
    _s();
    const { slug } = useParams();
    const BlogDetails = __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$blogs$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].find((item)=>item.slug === slug);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-header wpo-site-header-s2',
                Logo: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogDetailsLeftSiide/BlogDetailsLeftSiide.js",
                lineNumber: 16,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                pageTitle: BlogDetails.title,
                pagesub: 'Blog'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogDetailsLeftSiide/BlogDetailsLeftSiide.js",
                lineNumber: 17,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$BlogDetails$2f$BlogSingle$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                blLeft: 'order-lg-1',
                blRight: 'order-lg-2'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogDetailsLeftSiide/BlogDetailsLeftSiide.js",
                lineNumber: 18,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-footer_s2'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogDetailsLeftSiide/BlogDetailsLeftSiide.js",
                lineNumber: 19,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogDetailsLeftSiide/BlogDetailsLeftSiide.js",
                lineNumber: 20,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/helpers/main-component/BlogDetailsLeftSiide/BlogDetailsLeftSiide.js",
        lineNumber: 15,
        columnNumber: 9
    }, this);
};
_s(BlogDetailsLeftSiide, "DpOdpe+T7d3Ytb7f6neHj0L13w0=", true);
_c = BlogDetailsLeftSiide;
const __TURBOPACK__default__export__ = BlogDetailsLeftSiide;
var _c;
__turbopack_context__.k.register(_c, "BlogDetailsLeftSiide");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/BlogDetailsFull/BlogDetailsFull.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$blogs$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/api/blogs.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/Navbar/Navbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/pagetitle/PageTitle.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$BlogDetails$2f$BlogSingle$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/BlogDetails/BlogSingle.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/scrollbar/scrollbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/footer/Footer.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/logo-2.svg.mjs { IMAGE => "[project]/helpers/images/logo-2.svg (static in ecmascript)" } [client] (structured image object, ecmascript)');
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
const BlogDetailsFull = ()=>{
    _s();
    const { slug } = useParams();
    const BlogDetails = __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$blogs$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"].find((item)=>item.slug === slug);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                Logo: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
                hclass: 'wpo-site-header wpo-site-header-s2'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogDetailsFull/BlogDetailsFull.js",
                lineNumber: 16,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                pageTitle: BlogDetails.title,
                pagesub: 'Blog'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogDetailsFull/BlogDetailsFull.js",
                lineNumber: 17,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$BlogDetails$2f$BlogSingle$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                blLeft: 'd-none',
                blRight: 'col-lg-10 offset-lg-1'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogDetailsFull/BlogDetailsFull.js",
                lineNumber: 18,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-footer_s2'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogDetailsFull/BlogDetailsFull.js",
                lineNumber: 19,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/BlogDetailsFull/BlogDetailsFull.js",
                lineNumber: 20,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/helpers/main-component/BlogDetailsFull/BlogDetailsFull.js",
        lineNumber: 15,
        columnNumber: 9
    }, this);
};
_s(BlogDetailsFull, "DpOdpe+T7d3Ytb7f6neHj0L13w0=", true);
_c = BlogDetailsFull;
const __TURBOPACK__default__export__ = BlogDetailsFull;
var _c;
__turbopack_context__.k.register(_c, "BlogDetailsFull");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/ErrorPage/ErrorPage.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/Navbar/Navbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/pagetitle/PageTitle.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$404$2f$404$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/404/404.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/scrollbar/scrollbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/footer/Footer.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/logo-2.svg.mjs { IMAGE => "[project]/helpers/images/logo-2.svg (static in ecmascript)" } [client] (structured image object, ecmascript)');
;
;
;
;
;
;
;
;
const ErrorPage = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-header wpo-site-header-s2',
                Logo: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$logo$2d$2$2e$svg__$28$static__in__ecmascript$2922$__$7d$__$5b$client$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/ErrorPage/ErrorPage.js",
                lineNumber: 11,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$pagetitle$2f$PageTitle$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                pageTitle: '404',
                pagesub: '404'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/ErrorPage/ErrorPage.js",
                lineNumber: 12,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$404$2f$404$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/ErrorPage/ErrorPage.js",
                lineNumber: 13,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-footer_s2'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/ErrorPage/ErrorPage.js",
                lineNumber: 14,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/ErrorPage/ErrorPage.js",
                lineNumber: 15,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/helpers/main-component/ErrorPage/ErrorPage.js",
        lineNumber: 10,
        columnNumber: 9
    }, this);
};
_c = ErrorPage;
const __TURBOPACK__default__export__ = ErrorPage;
var _c;
__turbopack_context__.k.register(_c, "ErrorPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/router/index.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2d$dom$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/react-router-dom/dist/index.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/react-router/dist/index.js [client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$HomePage$2f$HomePage$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/HomePage/HomePage.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$HomePage2$2f$HomePage2$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/HomePage2/HomePage2.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$HomePage3$2f$HomePage3$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/HomePage3/HomePage3.js [client] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module '../AboutPage/AboutPage'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
(()=>{
    const e = new Error("Cannot find module '../TeamPage/TeamPage'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$TeamSinglePage$2f$TeamSinglePage$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/TeamSinglePage/TeamSinglePage.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$ShopPage$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/ShopPage/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$ProductSinglePage$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/ProductSinglePage/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$CartPage$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/CartPage/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$CheckoutPage$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/CheckoutPage/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$OrderRecived$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/OrderRecived/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$FaqPage$2f$FaqPage$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/FaqPage/FaqPage.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$project$2f$index$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/pages/project/index.jsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$ProjectSingle$2f$ProjectSingle$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/ProjectSingle/ProjectSingle.js [client] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module '../ServicePage/ServicePage'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$ServiceSinglePage$2f$ServiceSinglePage$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/ServiceSinglePage/ServiceSinglePage.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$blog$2f$index$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/pages/blog/index.jsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$BlogPageLeft$2f$BlogPageLeft$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/BlogPageLeft/BlogPageLeft.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$BlogPageFullwidth$2f$BlogPageFullwidth$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/BlogPageFullwidth/BlogPageFullwidth.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$BlogDetails$2f$BlogDetails$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/BlogDetails/BlogDetails.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$BlogDetailsLeftSiide$2f$BlogDetailsLeftSiide$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/BlogDetailsLeftSiide/BlogDetailsLeftSiide.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$BlogDetailsFull$2f$BlogDetailsFull$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/BlogDetailsFull/BlogDetailsFull.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$contact$2f$index$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/pages/contact/index.jsx [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$ErrorPage$2f$ErrorPage$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/ErrorPage/ErrorPage.js [client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const AllRoute = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "App",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2d$dom$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["BrowserRouter"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Routes"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "/",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$HomePage$2f$HomePage$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 35,
                            columnNumber: 36
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 35,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "home",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$HomePage$2f$HomePage$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 36,
                            columnNumber: 39
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 36,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "home-2",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$HomePage2$2f$HomePage2$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 37,
                            columnNumber: 41
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 37,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "home-3",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$HomePage3$2f$HomePage3$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 38,
                            columnNumber: 41
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 38,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "about",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AboutPage, {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 39,
                            columnNumber: 40
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 39,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "team",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TeamPage, {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 40,
                            columnNumber: 39
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 40,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "team-single/:slug",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$TeamSinglePage$2f$TeamSinglePage$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 41,
                            columnNumber: 52
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 41,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "shop",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$ShopPage$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 42,
                            columnNumber: 39
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 42,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "shop-single/:slug",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$ProductSinglePage$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 43,
                            columnNumber: 52
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 43,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "cart",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$CartPage$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 44,
                            columnNumber: 39
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 44,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "checkout",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$CheckoutPage$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 45,
                            columnNumber: 43
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 45,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "order_received",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$OrderRecived$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 46,
                            columnNumber: 49
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 46,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "faq",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$FaqPage$2f$FaqPage$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 47,
                            columnNumber: 38
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 47,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "services",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ServicePages, {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 48,
                            columnNumber: 43
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 48,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "service-single/:slug",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$ServiceSinglePage$2f$ServiceSinglePage$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 49,
                            columnNumber: 55
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 49,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "project",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$project$2f$index$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 50,
                            columnNumber: 42
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 50,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "project-single/:slug",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$ProjectSingle$2f$ProjectSingle$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 51,
                            columnNumber: 55
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 51,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "blog",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$blog$2f$index$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 52,
                            columnNumber: 39
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 52,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "blog-left-sidebar",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$BlogPageLeft$2f$BlogPageLeft$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 53,
                            columnNumber: 52
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 53,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "blog-fullwidth",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$BlogPageFullwidth$2f$BlogPageFullwidth$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 54,
                            columnNumber: 49
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 54,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "blog-single/:slug",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$BlogDetails$2f$BlogDetails$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 55,
                            columnNumber: 52
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 55,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "blog-single-left-sidebar/:slug",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$BlogDetailsLeftSiide$2f$BlogDetailsLeftSiide$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 56,
                            columnNumber: 65
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 56,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "blog-single-fullwidth/:slug",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$BlogDetailsFull$2f$BlogDetailsFull$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 57,
                            columnNumber: 62
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 57,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "contact",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$contact$2f$index$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 58,
                            columnNumber: 42
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 58,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$router$2f$dist$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Route"], {
                        path: "404",
                        element: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$ErrorPage$2f$ErrorPage$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/helpers/main-component/router/index.js",
                            lineNumber: 59,
                            columnNumber: 38
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/helpers/main-component/router/index.js",
                        lineNumber: 59,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/helpers/main-component/router/index.js",
                lineNumber: 34,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/helpers/main-component/router/index.js",
            lineNumber: 33,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/helpers/main-component/router/index.js",
        lineNumber: 32,
        columnNumber: 5
    }, this);
};
_c = AllRoute;
const __TURBOPACK__default__export__ = AllRoute;
var _c;
__turbopack_context__.k.register(_c, "AllRoute");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/App/App.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$router$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/main-component/router/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$toastify$2f$dist$2f$react$2d$toastify$2e$esm$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-toastify/dist/react-toastify.esm.mjs [client] (ecmascript)");
;
;
;
;
;
const App = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "App",
        id: "scrool",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$main$2d$component$2f$router$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/App/App.js",
                lineNumber: 11,
                columnNumber: 11
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$toastify$2f$dist$2f$react$2d$toastify$2e$esm$2e$mjs__$5b$client$5d$__$28$ecmascript$29$__["ToastContainer"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/App/App.js",
                lineNumber: 12,
                columnNumber: 11
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/helpers/main-component/App/App.js",
        lineNumber: 10,
        columnNumber: 5
    }, this);
};
_c = App;
const __TURBOPACK__default__export__ = App;
var _c;
__turbopack_context__.k.register(_c, "App");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/helpers/main-component/HomePage/HomePage.js [client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/index.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/Navbar/Navbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$hero$2f$hero$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/hero/hero.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$ServiceSection$2f$ServiceSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/ServiceSection/ServiceSection.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$about$2f$about$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/about/about.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$ProcessSection$2f$ProcessSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/ProcessSection/ProcessSection.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$ProjectSection$2f$ProjectSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/ProjectSection/ProjectSection.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Testimonial$2f$Testimonial$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/Testimonial/Testimonial.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$TeamSection$2f$TeamSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/TeamSection/TeamSection.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$FunFact$2f$FunFact$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/FunFact/FunFact.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$BlogSection$2f$BlogSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/BlogSection/BlogSection.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$CtafromSection$2f$CtafromSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/CtafromSection/CtafromSection.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/footer/Footer.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/scrollbar/scrollbar.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$adsSlider$2f$index$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/components/adsSlider/index.jsx [client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const HomePage = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$index$2e$js__$5b$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-[#f6eecd] pb-5",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Navbar$2f$Navbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                    hclass: 'wpo-site-header'
                }, void 0, false, {
                    fileName: "[project]/helpers/main-component/HomePage/HomePage.js",
                    lineNumber: 22,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage/HomePage.js",
                lineNumber: 20,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$hero$2f$hero$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'static-hero'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage/HomePage.js",
                lineNumber: 24,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$adsSlider$2f$index$2e$jsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage/HomePage.js",
                lineNumber: 25,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$ServiceSection$2f$ServiceSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: "service_section section-padding"
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage/HomePage.js",
                lineNumber: 26,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$about$2f$about$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'about_section section-padding'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage/HomePage.js",
                lineNumber: 27,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$ProcessSection$2f$ProcessSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: "work_section section-padding"
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage/HomePage.js",
                lineNumber: 28,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$ProjectSection$2f$ProjectSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'project_section section-padding'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage/HomePage.js",
                lineNumber: 29,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$Testimonial$2f$Testimonial$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                tClass: 'testimonial_section testimonial_section_slider'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage/HomePage.js",
                lineNumber: 30,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$TeamSection$2f$TeamSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'team_section section-padding',
                sliceEnd: 3
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage/HomePage.js",
                lineNumber: 31,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$FunFact$2f$FunFact$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'funfact_section'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage/HomePage.js",
                lineNumber: 32,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$BlogSection$2f$BlogSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                tClass: 'blog_section section-padding'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage/HomePage.js",
                lineNumber: 33,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$CtafromSection$2f$CtafromSection$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'ctafrom_section'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage/HomePage.js",
                lineNumber: 34,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$footer$2f$Footer$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                hclass: 'wpo-site-footer'
            }, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage/HomePage.js",
                lineNumber: 35,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$components$2f$scrollbar$2f$scrollbar$2e$js__$5b$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/helpers/main-component/HomePage/HomePage.js",
                lineNumber: 36,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/helpers/main-component/HomePage/HomePage.js",
        lineNumber: 19,
        columnNumber: 9
    }, this);
};
_c = HomePage;
const __TURBOPACK__default__export__ = HomePage;
var _c;
__turbopack_context__.k.register(_c, "HomePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=helpers_main-component_ab2c11c1._.js.map