(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__9e7321da._.js",
  "static/chunks/node_modules_next_dist_compiled_399f4c28._.js",
  "static/chunks/node_modules_next_dist_shared_lib_b83882bf._.js",
  "static/chunks/node_modules_next_dist_client_dce79224._.js",
  "static/chunks/node_modules_next_dist_a53df08c._.js",
  "static/chunks/node_modules_next_cf0cd5c3._.js",
  "static/chunks/node_modules_react_1cad9b0b._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
  "static/chunks/node_modules_react-dom_f14d0471._.js",
  "static/chunks/node_modules_axios_lib_9aa2336a._.js",
  "static/chunks/node_modules_@mui_system_93e0f7bc._.js",
  "static/chunks/node_modules_24a9b6b0._.js"
],
    source: "entry"
});
