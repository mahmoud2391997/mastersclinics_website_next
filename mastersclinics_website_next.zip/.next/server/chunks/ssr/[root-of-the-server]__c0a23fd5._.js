module.exports = {

"[externals]/react-redux [external] (react-redux, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("react-redux", () => require("react-redux"));

module.exports = mod;
}}),
"[externals]/redux [external] (redux, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("redux", () => require("redux"));

module.exports = mod;
}}),
"[externals]/redux-thunk [external] (redux-thunk, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("redux-thunk", () => require("redux-thunk"));

module.exports = mod;
}}),
"[externals]/redux-persist [external] (redux-persist, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("redux-persist", () => require("redux-persist"));

module.exports = mod;
}}),
"[externals]/axios [external] (axios, esm_import)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, a: __turbopack_async_module__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
const mod = await __turbopack_context__.y("axios");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[project]/pages/api/fetching.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, a: __turbopack_async_module__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__),
    "get": (()=>get),
    "getById": (()=>getById)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$axios__$5b$external$5d$__$28$axios$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/axios [external] (axios, esm_import)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f$axios__$5b$external$5d$__$28$axios$2c$__esm_import$29$__
]);
([__TURBOPACK__imported__module__$5b$externals$5d2f$axios__$5b$external$5d$__$28$axios$2c$__esm_import$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
// Axios instance
const api = __TURBOPACK__imported__module__$5b$externals$5d2f$axios__$5b$external$5d$__$28$axios$2c$__esm_import$29$__["default"].create({
    baseURL: "https://www.ss.mastersclinics.com",
    headers: {
        "Content-Type": "application/json"
    },
    timeout: 15000
});
// Request Interceptor: Attach token
// Error handler
const handleApiError = (error)=>{
    if (__TURBOPACK__imported__module__$5b$externals$5d2f$axios__$5b$external$5d$__$28$axios$2c$__esm_import$29$__["default"].isAxiosError(error)) {
        const serverError = error.response?.data;
        if (serverError && typeof serverError === "object") {
            return new Error(serverError.message || "An unexpected error occurred");
        }
    }
    return error instanceof Error ? error : new Error("An unexpected error occurred");
};
const get = async (url)=>{
    try {
        const response = await api.get(url, {
            timeout: 30000
        });
        return response.data;
    } catch (error) {
        throw handleApiError(error);
    }
};
const getById = async (url, id, config = {})=>{
    return get(`${url}/${id}`, config);
};
const __TURBOPACK__default__export__ = api;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/store/slices/services.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, a: __turbopack_async_module__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__),
    "fetchServiceById": (()=>fetchServiceById),
    "fetchServices": (()=>fetchServices)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/pages/api/fetching.js [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__
]);
([__TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
// Local fallback data matching your component's schema
const localServices = [
    {
        id: '1',
        name: 'الفحص الشامل',
        title: 'فحص طبي شامل',
        description: 'فحص طبي شامل لجميع أعضاء الجسم',
        longDescription: 'يقدم مركزنا فحص طبي شامل يشمل جميع أعضاء الجسم مع تحاليل الدم الشاملة وصور الأشعة اللازمة لتقييم الحالة الصحية العامة.',
        image: '/services/comprehensive-checkup.jpg',
        capabilities: [
            'فحص القلب والأوعية الدموية',
            'فحص الجهاز التنفسي',
            'فحص الجهاز الهضمي',
            'فحص الغدد الصماء'
        ],
        capabilitiesDescription: 'نقدم مجموعة متكاملة من الفحوصات لتقييم صحتك العامة',
        approach: 'نتبع نهجًا شاملاً يركز على الوقاية والتشخيص المبكر للأمراض',
        icon: 'flaticon-health-check'
    },
    {
        id: '2',
        name: 'علاج الأسنان',
        title: 'حزمة العناية بالأسنان',
        description: 'علاج وتجميل الأسنان بأحدث التقنيات',
        longDescription: 'يقدم قسم الأسنان لدينا جميع خدمات علاج وتجميل الأسنان باستخدام أحدث الأجهزة والتقنيات العالمية.',
        image: '/services/dental-care.jpg',
        capabilities: [
            'حشوات تجميلية',
            'تبييض الأسنان',
            'تركيبات ثابتة ومتحركة',
            'علاج الجذور'
        ],
        capabilitiesDescription: 'جميع علاجات الأسنان بجودة عالية وضمان طويل المدى',
        approach: 'نهتم براحة المريض ونستخدم أحدث التقنيات الخالية من الألم',
        icon: 'flaticon-dental-care'
    },
    {
        id: '3',
        name: 'جراحة العظام',
        title: 'جراحات العظام والمفاصل',
        description: 'علاج إصابات وجراحات العظام والمفاصل',
        longDescription: 'يقدم فريقنا المتخصص أحدث جراحات العظام والمفاصل بما في ذلك جراحات المناظير واستبدال المفاصل.',
        image: '/services/orthopedic.jpg',
        capabilities: [
            'جراحات المناظير',
            'استبدال المفاصل',
            'علاج كسور العظام',
            'جراحات العمود الفقري'
        ],
        capabilitiesDescription: 'حلول متكاملة لجميع مشاكل العظام والمفاصل',
        approach: 'نستخدم أحدث التقنيات الجراحية لضمان الشفاء السريع',
        icon: 'flaticon-bone'
    }
];
// Initial state
const initialState = {
    services: [],
    selectedService: null,
    loading: false,
    error: null
};
// Action Types
const FETCH_SERVICES_START = "services/fetch_start";
const FETCH_SERVICES_SUCCESS = "services/fetch_success";
const FETCH_SERVICES_ERROR = "services/fetch_error";
const FETCH_SERVICE_BY_ID_START = "services/fetch_by_id_start";
const FETCH_SERVICE_BY_ID_SUCCESS = "services/fetch_by_id_success";
const FETCH_SERVICE_BY_ID_ERROR = "services/fetch_by_id_error";
// Reducer
const serviceReducer = (state = initialState, action)=>{
    switch(action.type){
        case FETCH_SERVICES_START:
        case FETCH_SERVICE_BY_ID_START:
            return {
                ...state,
                loading: true,
                error: null
            };
        case FETCH_SERVICES_SUCCESS:
            return {
                ...state,
                loading: false,
                services: action.payload
            };
        case FETCH_SERVICE_BY_ID_SUCCESS:
            return {
                ...state,
                loading: false,
                selectedService: action.payload
            };
        case FETCH_SERVICES_ERROR:
        case FETCH_SERVICE_BY_ID_ERROR:
            return {
                ...state,
                loading: false,
                error: action.payload
            };
        default:
            return state;
    }
};
const __TURBOPACK__default__export__ = serviceReducer;
const fetchServices = ()=>async (dispatch)=>{
        dispatch({
            type: FETCH_SERVICES_START
        });
        try {
            const data = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["get"])("/services");
            console.log(data);
            // If API returns no data or empty array, use local services data
            if (!data || data.length === 0) {
                dispatch({
                    type: FETCH_SERVICES_SUCCESS,
                    payload: localServices
                });
            } else {
                dispatch({
                    type: FETCH_SERVICES_SUCCESS,
                    payload: data
                });
            }
        } catch (error) {
            // If API fails, use local services data
            dispatch({
                type: FETCH_SERVICES_SUCCESS,
                payload: localServices
            });
        }
    };
const fetchServiceById = (id)=>async (dispatch)=>{
        dispatch({
            type: FETCH_SERVICE_BY_ID_START
        });
        try {
            const data = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["get"])(`/services/${id}`);
            // If API returns no data, try to find in local services
            if (!data) {
                const localService = localServices.find((service)=>service.id === id);
                if (localService) {
                    dispatch({
                        type: FETCH_SERVICE_BY_ID_SUCCESS,
                        payload: localService
                    });
                } else {
                    throw new Error('Service not found');
                }
            } else {
                dispatch({
                    type: FETCH_SERVICE_BY_ID_SUCCESS,
                    payload: data
                });
            }
        } catch (error) {
            // If API fails, try to find in local services
            const localService = localServices.find((service)=>service.id === id);
            if (localService) {
                dispatch({
                    type: FETCH_SERVICE_BY_ID_SUCCESS,
                    payload: localService
                });
            } else {
                dispatch({
                    type: FETCH_SERVICE_BY_ID_ERROR,
                    payload: error.message
                });
            }
        }
    };
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/helpers/images/team/1.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/1.0392cd80.png");}}),
"[project]/helpers/images/team/1.png.mjs { IMAGE => \"[project]/helpers/images/team/1.png (static in ecmascript)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$1$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/team/1.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$1$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 364,
    height: 547,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAL0lEQVR42pWMsQkAMBAC3X8P+V6xy3CRdKlCDhSuOawbvNz2zJDsS0LHQz0JPnsbi4VWKQCZhPkAAAAASUVORK5CYII=",
    blurWidth: 5,
    blurHeight: 8
};
}}),
"[project]/helpers/images/team/2.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/2.0392cd80.png");}}),
"[project]/helpers/images/team/2.png.mjs { IMAGE => \"[project]/helpers/images/team/2.png (static in ecmascript)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$2$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/team/2.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$2$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 364,
    height: 547,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAL0lEQVR42pWMsQkAMBAC3X8P+V6xy3CRdKlCDhSuOawbvNz2zJDsS0LHQz0JPnsbi4VWKQCZhPkAAAAASUVORK5CYII=",
    blurWidth: 5,
    blurHeight: 8
};
}}),
"[project]/helpers/images/team/3.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/3.0392cd80.png");}}),
"[project]/helpers/images/team/3.png.mjs { IMAGE => \"[project]/helpers/images/team/3.png (static in ecmascript)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$3$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/team/3.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$3$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 364,
    height: 547,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAL0lEQVR42pWMsQkAMBAC3X8P+V6xy3CRdKlCDhSuOawbvNz2zJDsS0LHQz0JPnsbi4VWKQCZhPkAAAAASUVORK5CYII=",
    blurWidth: 5,
    blurHeight: 8
};
}}),
"[project]/helpers/images/team/4.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/4.9941eaa9.png");}}),
"[project]/helpers/images/team/4.png.mjs { IMAGE => \"[project]/helpers/images/team/4.png (static in ecmascript)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$4$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/team/4.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$4$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 370,
    height: 520,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAIAAABVpBlvAAAAM0lEQVR42p3MMQoAIAxD0d7/HJFC14RMHk4UnFykb/zDj/mIv2Q7MwGMQ9JOVYWLZHT3C60qZ0smO5jfAAAAAElFTkSuQmCC",
    blurWidth: 6,
    blurHeight: 8
};
}}),
"[project]/helpers/images/team/5.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/5.859d9202.png");}}),
"[project]/helpers/images/team/5.png.mjs { IMAGE => \"[project]/helpers/images/team/5.png (static in ecmascript)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$5$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/team/5.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$5$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 387,
    height: 557,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAIAAABVpBlvAAAAOElEQVR42p2MuQkAMAwDvf8Y/sC1BWoyXJw6TYgKwV1xsq7JmwKgqhHh7vPdfZSZVdVwZpKU3/wGpj1nPHsrOOgAAAAASUVORK5CYII=",
    blurWidth: 6,
    blurHeight: 8
};
}}),
"[project]/helpers/images/team/6.png (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/6.a4c2b897.png");}}),
"[project]/helpers/images/team/6.png.mjs { IMAGE => \"[project]/helpers/images/team/6.png (static in ecmascript)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$6$2e$png__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/team/6.png (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$6$2e$png__$28$static__in__ecmascript$29$__["default"],
    width: 396,
    height: 592,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAALklEQVR42pXMsQ0AIAwDwew/h+0B7JbhEIiGKsp313ytv+qcBIAkkrafeTse/jaFJVYOkrsZngAAAABJRU5ErkJggg==",
    blurWidth: 5,
    blurHeight: 8
};
}}),
"[project]/helpers/api/team.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$1$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$1$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/team/1.png.mjs { IMAGE => "[project]/helpers/images/team/1.png (static in ecmascript)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$2$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$2$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/team/2.png.mjs { IMAGE => "[project]/helpers/images/team/2.png (static in ecmascript)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$3$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$3$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/team/3.png.mjs { IMAGE => "[project]/helpers/images/team/3.png (static in ecmascript)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$4$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$4$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/team/4.png.mjs { IMAGE => "[project]/helpers/images/team/4.png (static in ecmascript)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$5$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$5$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/team/5.png.mjs { IMAGE => "[project]/helpers/images/team/5.png (static in ecmascript)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$6$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$6$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/team/6.png.mjs { IMAGE => "[project]/helpers/images/team/6.png (static in ecmascript)" } [ssr] (structured image object, ecmascript)');
;
;
;
;
;
;
const Teams = [
    {
        id: '1',
        name: 'مارلين هنري',
        specialization: 'جراح',
        slug: 'Marlene-Henry',
        image: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$1$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$1$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        branches: [
            'alawali',
            'alkhalidiyah'
        ]
    },
    {
        id: '2',
        name: 'ديان راسل',
        specialization: 'أخصائية قلب',
        slug: 'Dianne-Russell',
        image: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$2$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$2$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        branches: [
            'alshatee',
            'albasateen'
        ]
    },
    {
        id: '3',
        name: 'جيروم بيل',
        specialization: 'اختصاصي أمراض الحيوانات',
        slug: 'Jerome-Bell',
        image: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$3$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$3$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        branches: [
            'alkhalidiyah'
        ]
    },
    {
        id: '4',
        name: 'ليسلي ألكسندر',
        specialization: 'جراح',
        slug: 'Leslie-Alexander',
        image: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$4$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$4$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        branches: [
            'alawali',
            'alshatee',
            'albasateen'
        ]
    },
    {
        id: '5',
        name: 'ألكسندر ليسلي',
        specialization: 'أخصائي قلب',
        slug: 'Alexander-Leslie',
        image: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$5$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$5$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        branches: [
            'abhur'
        ]
    },
    {
        id: '6',
        name: 'كودي فيشر',
        specialization: 'جراح',
        slug: 'Cody-Fisher',
        image: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$team$2f$6$2e$png$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$team$2f$6$2e$png__$28$static__in__ecmascript$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"],
        branches: [
            'altaif'
        ]
    }
];
const __TURBOPACK__default__export__ = Teams;
}}),
"[project]/store/slices/doctor.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, a: __turbopack_async_module__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__),
    "fetchTeamById": (()=>fetchTeamById),
    "fetchTeams": (()=>fetchTeams)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/pages/api/fetching.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$team$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/api/team.js [ssr] (ecmascript)"); // Adjust the import path as needed
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__
]);
([__TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
;
// Initial State
const initialState = {
    teams: [],
    selectedTeam: null,
    loading: false,
    error: null
};
// Action Types
const FETCH_TEAMS_START = "teams/fetch_start";
const FETCH_TEAMS_SUCCESS = "teams/fetch_success";
const FETCH_TEAMS_ERROR = "teams/fetch_error";
const FETCH_TEAM_BY_ID_START = "teams/fetch_by_id_start";
const FETCH_TEAM_BY_ID_SUCCESS = "teams/fetch_by_id_success";
const FETCH_TEAM_BY_ID_ERROR = "teams/fetch_by_id_error";
// Reducer
const teamReducer = (state = initialState, action)=>{
    switch(action.type){
        case FETCH_TEAMS_START:
        case FETCH_TEAM_BY_ID_START:
            return {
                ...state,
                loading: true,
                error: null
            };
        case FETCH_TEAMS_SUCCESS:
            return {
                ...state,
                loading: false,
                teams: action.payload
            };
        case FETCH_TEAM_BY_ID_SUCCESS:
            return {
                ...state,
                loading: false,
                selectedTeam: action.payload
            };
        case FETCH_TEAMS_ERROR:
        case FETCH_TEAM_BY_ID_ERROR:
            return {
                ...state,
                loading: false,
                error: action.payload
            };
        default:
            return state;
    }
};
const __TURBOPACK__default__export__ = teamReducer;
const fetchTeams = ()=>async (dispatch)=>{
        dispatch({
            type: FETCH_TEAMS_START
        });
        try {
            let data = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["get"])("/doctors"); // Try to fetch from API
            // If API returns no data or empty array, use local Teams data
            if (!data || data.length === 0) {
                data = __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$team$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"];
            }
            dispatch({
                type: FETCH_TEAMS_SUCCESS,
                payload: data
            });
        } catch (error) {
            // If API fails, use local Teams data as fallback
            dispatch({
                type: FETCH_TEAMS_SUCCESS,
                payload: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$team$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"]
            });
        }
    };
const fetchTeamById = (id)=>async (dispatch)=>{
        dispatch({
            type: FETCH_TEAM_BY_ID_START
        });
        try {
            let data = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["getById"])("/doctors", id);
            // If API returns no data, try to find in local Teams data
            if (!data) {
                data = __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$team$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"].find((team)=>team.id === id);
            }
            if (data) {
                dispatch({
                    type: FETCH_TEAM_BY_ID_SUCCESS,
                    payload: data
                });
            } else {
                dispatch({
                    type: FETCH_TEAM_BY_ID_ERROR,
                    payload: `Team member with ID ${id} not found`
                });
            }
        } catch (error) {
            // If API fails, try to find in local Teams data
            const localData = __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$team$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"].find((team)=>team.id === id);
            if (localData) {
                dispatch({
                    type: FETCH_TEAM_BY_ID_SUCCESS,
                    payload: localData
                });
            } else {
                dispatch({
                    type: FETCH_TEAM_BY_ID_ERROR,
                    payload: error.message || `Team member with ID ${id} not found`
                });
            }
        }
    };
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[externals]/@reduxjs/toolkit [external] (@reduxjs/toolkit, esm_import)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, a: __turbopack_async_module__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
const mod = await __turbopack_context__.y("@reduxjs/toolkit");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[project]/helpers/images/project/1.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/1.2c49641e.jpg");}}),
"[project]/helpers/images/project/1.jpg.mjs { IMAGE => \"[project]/helpers/images/project/1.jpg (static in ecmascript)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$1$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/project/1.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$1$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 415,
    height: 550,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAIAAABVpBlvAAAANUlEQVR42p3MIQ4AMAgEQf7/CnIIsORO9nFNmrqahpUj1taT/ZGkzIwIAO7e3UayqnC6NN1vk9pm9AB6D6QAAAAASUVORK5CYII=",
    blurWidth: 6,
    blurHeight: 8
};
}}),
"[project]/helpers/images/project/2.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/2.2c49641e.jpg");}}),
"[project]/helpers/images/project/2.jpg.mjs { IMAGE => \"[project]/helpers/images/project/2.jpg (static in ecmascript)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$2$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/project/2.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$2$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 415,
    height: 550,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAIAAABVpBlvAAAANUlEQVR42p3MIQ4AMAgEQf7/CnIIsORO9nFNmrqahpUj1taT/ZGkzIwIAO7e3UayqnC6NN1vk9pm9AB6D6QAAAAASUVORK5CYII=",
    blurWidth: 6,
    blurHeight: 8
};
}}),
"[project]/helpers/images/project/3.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/3.2c49641e.jpg");}}),
"[project]/helpers/images/project/3.jpg.mjs { IMAGE => \"[project]/helpers/images/project/3.jpg (static in ecmascript)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$3$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/project/3.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$3$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 415,
    height: 550,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAIAAABVpBlvAAAANUlEQVR42p3MIQ4AMAgEQf7/CnIIsORO9nFNmrqahpUj1taT/ZGkzIwIAO7e3UayqnC6NN1vk9pm9AB6D6QAAAAASUVORK5CYII=",
    blurWidth: 6,
    blurHeight: 8
};
}}),
"[project]/helpers/images/project/4.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/4.2c49641e.jpg");}}),
"[project]/helpers/images/project/4.jpg.mjs { IMAGE => \"[project]/helpers/images/project/4.jpg (static in ecmascript)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$4$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/project/4.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$4$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 415,
    height: 550,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAIAAABVpBlvAAAANUlEQVR42p3MIQ4AMAgEQf7/CnIIsORO9nFNmrqahpUj1taT/ZGkzIwIAO7e3UayqnC6NN1vk9pm9AB6D6QAAAAASUVORK5CYII=",
    blurWidth: 6,
    blurHeight: 8
};
}}),
"[project]/helpers/images/project/5.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/5.2c49641e.jpg");}}),
"[project]/helpers/images/project/5.jpg.mjs { IMAGE => \"[project]/helpers/images/project/5.jpg (static in ecmascript)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$5$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/project/5.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$5$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 415,
    height: 550,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAIAAABVpBlvAAAANUlEQVR42p3MIQ4AMAgEQf7/CnIIsORO9nFNmrqahpUj1taT/ZGkzIwIAO7e3UayqnC6NN1vk9pm9AB6D6QAAAAASUVORK5CYII=",
    blurWidth: 6,
    blurHeight: 8
};
}}),
"[project]/helpers/images/project/6.jpg (static in ecmascript)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v("/_next/static/media/6.2c49641e.jpg");}}),
"[project]/helpers/images/project/6.jpg.mjs { IMAGE => \"[project]/helpers/images/project/6.jpg (static in ecmascript)\" } [ssr] (structured image object, ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$6$2e$jpg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/images/project/6.jpg (static in ecmascript)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$6$2e$jpg__$28$static__in__ecmascript$29$__["default"],
    width: 415,
    height: 550,
    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAIAAABVpBlvAAAANUlEQVR42p3MIQ4AMAgEQf7/CnIIsORO9nFNmrqahpUj1taT/ZGkzIwIAO7e3UayqnC6NN1vk9pm9AB6D6QAAAAASUVORK5CYII=",
    blurWidth: 6,
    blurHeight: 8
};
}}),
"[project]/helpers/api/projects.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$1$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2f$1$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/project/1.jpg.mjs { IMAGE => "[project]/helpers/images/project/1.jpg (static in ecmascript)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$2$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2f$2$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/project/2.jpg.mjs { IMAGE => "[project]/helpers/images/project/2.jpg (static in ecmascript)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$3$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2f$3$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/project/3.jpg.mjs { IMAGE => "[project]/helpers/images/project/3.jpg (static in ecmascript)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$4$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2f$4$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/project/4.jpg.mjs { IMAGE => "[project]/helpers/images/project/4.jpg (static in ecmascript)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$5$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2f$5$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/project/5.jpg.mjs { IMAGE => "[project]/helpers/images/project/5.jpg (static in ecmascript)" } [ssr] (structured image object, ecmascript)');
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$6$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2f$6$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__ = __turbopack_context__.i('[project]/helpers/images/project/6.jpg.mjs { IMAGE => "[project]/helpers/images/project/6.jpg (static in ecmascript)" } [ssr] (structured image object, ecmascript)');
;
;
;
;
;
;
const Projects = [
    {
        _id: '1',
        name: 'Heart Institute',
        subtitle: 'Treatment',
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSPPnn7ieaDAQbvg_f37_pB_ILw8quxYBTXKw&s"
    },
    {
        _id: '2',
        name: 'Orthopaedics Center',
        subtitle: 'Treatment',
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSPPnn7ieaDAQbvg_f37_pB_ILw8quxYBTXKw&s"
    },
    {
        _id: '3',
        name: 'Neurology Services',
        subtitle: 'Treatment',
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSPPnn7ieaDAQbvg_f37_pB_ILw8quxYBTXKw&s"
    },
    {
        _id: '4',
        name: 'Quality Therapy',
        subtitle: 'Treatment',
        image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSPPnn7ieaDAQbvg_f37_pB_ILw8quxYBTXKw&s"
    },
    {
        _id: '5',
        name: 'Pediatric Surgery',
        subtitle: 'Treatment',
        image: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$5$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2f$5$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    },
    {
        _id: '6',
        name: 'Surgical',
        subtitle: 'Treatment',
        image: __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$images$2f$project$2f$6$2e$jpg$2e$mjs__$7b$__IMAGE__$3d3e$__$225b$project$5d2f$helpers$2f$images$2f$project$2f$6$2e$jpg__$28$static__in__ecmascript$2922$__$7d$__$5b$ssr$5d$__$28$structured__image__object$2c$__ecmascript$29$__["default"]
    }
];
const __TURBOPACK__default__export__ = Projects;
}}),
"[project]/store/slices/devices.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, a: __turbopack_async_module__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__),
    "fetchDeviceById": (()=>fetchDeviceById),
    "fetchDevices": (()=>fetchDevices)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f40$reduxjs$2f$toolkit__$5b$external$5d$__$2840$reduxjs$2f$toolkit$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/@reduxjs/toolkit [external] (@reduxjs/toolkit, esm_import)");
var __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/pages/api/fetching.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$projects$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/helpers/api/projects.js [ssr] (ecmascript)"); // Import the static data
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f40$reduxjs$2f$toolkit__$5b$external$5d$__$2840$reduxjs$2f$toolkit$2c$__esm_import$29$__,
    __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__
]);
([__TURBOPACK__imported__module__$5b$externals$5d2f40$reduxjs$2f$toolkit__$5b$external$5d$__$2840$reduxjs$2f$toolkit$2c$__esm_import$29$__, __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
;
;
const fetchDevices = (0, __TURBOPACK__imported__module__$5b$externals$5d2f40$reduxjs$2f$toolkit__$5b$external$5d$__$2840$reduxjs$2f$toolkit$2c$__esm_import$29$__["createAsyncThunk"])('devices/fetchDevices', async (_, thunkAPI)=>{
    try {
        const devices = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["get"])('/devices');
        console.log("Fetched devices:", devices);
        // If API returns no data or empty array, use local devices data
        if (!devices || devices.length === 0) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$projects$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"];
        }
        return devices;
    } catch (error) {
        // If API fails, return local devices data
        return __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$projects$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"];
    }
});
const fetchDeviceById = (0, __TURBOPACK__imported__module__$5b$externals$5d2f40$reduxjs$2f$toolkit__$5b$external$5d$__$2840$reduxjs$2f$toolkit$2c$__esm_import$29$__["createAsyncThunk"])('devices/fetchDeviceById', async (id, thunkAPI)=>{
    try {
        const device = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["getById"])('/devices', id);
        console.log("Fetched device by ID:", device);
        // If API returns no data, try to find in local devices
        if (!device) {
            const localDevice = __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$projects$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"].find((d)=>d.id === id);
            if (localDevice) return localDevice;
            throw new Error('Device not found');
        }
        return device;
    } catch (error) {
        // If API fails, try to find in local devices
        const localDevice = __TURBOPACK__imported__module__$5b$project$5d2f$helpers$2f$api$2f$projects$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"].find((d)=>d.id === id);
        if (localDevice) return localDevice;
        return thunkAPI.rejectWithValue(error.message);
    }
});
const devicesSlice = (0, __TURBOPACK__imported__module__$5b$externals$5d2f40$reduxjs$2f$toolkit__$5b$external$5d$__$2840$reduxjs$2f$toolkit$2c$__esm_import$29$__["createSlice"])({
    name: 'devices',
    initialState: {
        items: [],
        selectedDevice: null,
        loading: false,
        error: null
    },
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(fetchDevices.pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(fetchDevices.fulfilled, (state, action)=>{
            state.loading = false;
            state.items = action.payload;
        }).addCase(fetchDevices.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload;
        }).addCase(fetchDeviceById.pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(fetchDeviceById.fulfilled, (state, action)=>{
            state.loading = false;
            state.selectedDevice = action.payload;
        }).addCase(fetchDeviceById.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload;
        });
    }
});
const __TURBOPACK__default__export__ = devicesSlice.reducer;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/pages/branches/branches.json (json)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v(JSON.parse("[{\"_id\":\"1\",\"id\":1,\"region_id\":1,\"name\":\"فرع العوالي\",\"address\":\"حي العوالي شارع ابراهيم الجفالي قبل بنك الراجحي\",\"location_link\":\"https://maps.app.goo.gl/1ibregK8ZArXVA9W9\",\"coordinates\":{\"latitude\":21.35643494168666,\"longitude\":39.87606743757779},\"region\":\"مكة\",\"working_hours\":[{\"days\":\"من السبت إلى الأربعاء\",\"time\":\"9:00 صباحًا - 10:00 مساءً\"},{\"days\":\"الخميس\",\"time\":\"9:00 صباحًا - 9:00 مساءً\"}]},{\"_id\":\"2\",\"id\":2,\"region_id\":1,\"name\":\"فرع الخالدية\",\"address\":\"طريق الدائري الثالث حي الخالدية برج المشارق الدور الرابع\",\"location_link\":\"https://maps.app.goo.gl/Rvtpe9143U2wasQh9\",\"working_hours\":[{\"days\":\"من السبت إلى الأربعاء\",\"time\":\"9:00 صباحًا - 10:00 مساءً\"},{\"days\":\"الخميس\",\"time\":\"9:00 صباحًا - 8:00 مساءً\"}],\"coordinates\":{\"latitude\":21.399068460295886,\"longitude\":39.7991578847404}},{\"_id\":\"3\",\"id\":3,\"region_id\":2,\"name\":\"فرع الشاطئ\",\"address\":\"حي الشاطئ طريق الكورنيش برج النخبة خلف برج الشاشة طريق الملك الدور الثالث\",\"location_link\":\"https://maps.app.goo.gl/R1GvSn8F9Zyemd5C7\",\"working_hours\":[{\"days\":\"من السبت إلى الأربعاء\",\"time\":\"9:00 صباحًا - 10:00 مساءً\"},{\"days\":\"الخميس\",\"time\":\"9:00 صباحًا - 8:00 مساءً\"}],\"coordinates\":{\"latitude\":21.61200113668299,\"longitude\":39.12492434975755}},{\"_id\":\"4\",\"id\":4,\"region_id\":2,\"name\":\"فرع البساتين\",\"address\":\"حي البساتين شارع اسماعيل بن كثير\",\"location_link\":\"https://maps.app.goo.gl/BZjojSyV4xSdE32U9\",\"working_hours\":[{\"days\":\"من السبت إلى الأربعاء\",\"time\":\"2:00 مساءً - 10:00 مساءً\"},{\"days\":\"الخميس\",\"time\":\"1:00 مساءً - 9:00 مساءً\"}],\"coordinates\":{\"latitude\":21.74581388140332,\"longitude\":39.091236812391045}},{\"_id\":\"5\",\"id\":5,\"region_id\":2,\"name\":\"ابحر الشمالية\",\"address\":\"ابحر الشمالية شارع عبر القارات برج الجوهرة\",\"location_link\":\"https://maps.app.goo.gl/QKGoAYWYorAR8riKA\",\"coordinates\":{\"latitude\":21.765875885393115,\"longitude\":39.11321074232811}},{\"_id\":\"6\",\"id\":6,\"region_id\":3,\"name\":\"فرع الطائف\",\"address\":\"الدور الارضي شارع قريش اسفل جو فالي\",\"location_link\":\"https://maps.app.goo.gl/L54ngMRmpofW5ski7\",\"coordinates\":{\"latitude\":21.23460590468905,\"longitude\":40.41442388465623}}]"));}}),
"[project]/store/slices/branches.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, a: __turbopack_async_module__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__),
    "fetchBranchById": (()=>fetchBranchById),
    "fetchBranches": (()=>fetchBranches)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f40$reduxjs$2f$toolkit__$5b$external$5d$__$2840$reduxjs$2f$toolkit$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/@reduxjs/toolkit [external] (@reduxjs/toolkit, esm_import)");
var __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/pages/api/fetching.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$branches$2f$branches$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/pages/branches/branches.json (json)"); // Import the static data
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f40$reduxjs$2f$toolkit__$5b$external$5d$__$2840$reduxjs$2f$toolkit$2c$__esm_import$29$__,
    __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__
]);
([__TURBOPACK__imported__module__$5b$externals$5d2f40$reduxjs$2f$toolkit__$5b$external$5d$__$2840$reduxjs$2f$toolkit$2c$__esm_import$29$__, __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
;
;
const fetchBranches = (0, __TURBOPACK__imported__module__$5b$externals$5d2f40$reduxjs$2f$toolkit__$5b$external$5d$__$2840$reduxjs$2f$toolkit$2c$__esm_import$29$__["createAsyncThunk"])('branches/fetchBranches', async (_, thunkAPI)=>{
    try {
        const branches = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["get"])('/branches');
        console.log("Fetched branches:", branches);
        // If API returns no data or empty array, use local branches data
        if (!branches || branches.length === 0) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$branches$2f$branches$2e$json__$28$json$29$__["default"];
        }
        return branches;
    } catch (error) {
        // If API fails, return local branches data
        return __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$branches$2f$branches$2e$json__$28$json$29$__["default"];
    }
});
const fetchBranchById = (0, __TURBOPACK__imported__module__$5b$externals$5d2f40$reduxjs$2f$toolkit__$5b$external$5d$__$2840$reduxjs$2f$toolkit$2c$__esm_import$29$__["createAsyncThunk"])('branches/fetchBranchById', async (id, thunkAPI)=>{
    try {
        const branch = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["getById"])('/branches', id);
        console.log("Fetched branch by ID:", branch);
        // If API returns no data, try to find in local branches
        if (!branch) {
            const localBranch = __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$branches$2f$branches$2e$json__$28$json$29$__["default"].find((b)=>b.id === id);
            if (localBranch) return localBranch;
            throw new Error('Branch not found');
        }
        return branch;
    } catch (error) {
        // If API fails, try to find in local branches
        const localBranch = __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$branches$2f$branches$2e$json__$28$json$29$__["default"].find((b)=>b.id === id);
        if (localBranch) return localBranch;
        return thunkAPI.rejectWithValue(error.message);
    }
});
const branchesSlice = (0, __TURBOPACK__imported__module__$5b$externals$5d2f40$reduxjs$2f$toolkit__$5b$external$5d$__$2840$reduxjs$2f$toolkit$2c$__esm_import$29$__["createSlice"])({
    name: 'branches',
    initialState: {
        items: [],
        selectedBranch: null,
        loading: false,
        error: null
    },
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(fetchBranches.pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(fetchBranches.fulfilled, (state, action)=>{
            state.loading = false;
            state.items = action.payload;
        }).addCase(fetchBranches.rejected, (state, action)=>{
            // This case won't be reached since we return local data on error
            state.loading = false;
            state.error = action.payload;
        }).addCase(fetchBranchById.pending, (state)=>{
            state.loading = true;
            state.error = null;
        }).addCase(fetchBranchById.fulfilled, (state, action)=>{
            state.loading = false;
            state.selectedBranch = action.payload;
        }).addCase(fetchBranchById.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload;
        });
    }
});
const __TURBOPACK__default__export__ = branchesSlice.reducer;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/store/slices/offers.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, a: __turbopack_async_module__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_context__.s({
    "clearSelectedOffer": (()=>clearSelectedOffer),
    "default": (()=>__TURBOPACK__default__export__),
    "fetchOfferById": (()=>fetchOfferById),
    "fetchOffers": (()=>fetchOffers)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f40$reduxjs$2f$toolkit__$5b$external$5d$__$2840$reduxjs$2f$toolkit$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/@reduxjs/toolkit [external] (@reduxjs/toolkit, esm_import)");
var __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/pages/api/fetching.js [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f40$reduxjs$2f$toolkit__$5b$external$5d$__$2840$reduxjs$2f$toolkit$2c$__esm_import$29$__,
    __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__
]);
([__TURBOPACK__imported__module__$5b$externals$5d2f40$reduxjs$2f$toolkit__$5b$external$5d$__$2840$reduxjs$2f$toolkit$2c$__esm_import$29$__, __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
;
// Local fallback data matching your component's schema
const localOffers = [
    {
        id: '1',
        title: 'فحص شامل بخصم 30%',
        description: 'احصل على فحص طبي شامل بخصم 30% لجميع الفحوصات الأساسية',
        discount: 30,
        validUntil: '2023-12-31',
        image: '/offers/comprehensive-checkup.jpg',
        branches: [
            'alawali',
            'alkhalidiyah'
        ],
        terms: 'هذا العرض ساري لمرة واحدة لكل مريض ولا يمكن جمعه مع عروض أخرى'
    },
    {
        id: '2',
        title: 'حزمة العناية بالأسنان',
        description: 'تنظيف وفحص الأسنان مع تبييض مجاني',
        discount: 25,
        validUntil: '2023-11-30',
        image: '/offers/dental-care.jpg',
        branches: [
            'alshatee',
            'albasateen'
        ],
        terms: 'يشمل العرض تنظيف الأسنان وفحصها فقط'
    },
    {
        id: '3',
        title: 'كشف القلب بخصم 40%',
        description: 'فحص القلب والايكو بخصم 40% للمرة الأولى',
        discount: 40,
        validUntil: '2023-10-15',
        image: '/offers/heart-check.jpg',
        branches: [
            'alkhalidiyah'
        ],
        terms: 'يشمل الفحص الأساسي فقط'
    }
];
const fetchOffers = (0, __TURBOPACK__imported__module__$5b$externals$5d2f40$reduxjs$2f$toolkit__$5b$external$5d$__$2840$reduxjs$2f$toolkit$2c$__esm_import$29$__["createAsyncThunk"])('offers/fetchOffers', async (_, thunkAPI)=>{
    try {
        const offers = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["get"])('/offers');
        console.log("Fetched offers:", offers);
        // If API returns no data or empty array, use local offers data
        if (!offers || offers.length === 0) {
            return localOffers;
        }
        return offers;
    } catch (error) {
        // If API fails, return local offers data
        return localOffers;
    }
});
const fetchOfferById = (0, __TURBOPACK__imported__module__$5b$externals$5d2f40$reduxjs$2f$toolkit__$5b$external$5d$__$2840$reduxjs$2f$toolkit$2c$__esm_import$29$__["createAsyncThunk"])('offers/fetchOfferById', async (id, thunkAPI)=>{
    try {
        const offer = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$pages$2f$api$2f$fetching$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["getById"])('/offers', id);
        console.log("Fetched offer by ID:", offer);
        // If API returns no data, try to find in local offers
        if (!offer) {
            const localOffer = localOffers.find((o)=>o.id === id);
            if (localOffer) return localOffer;
            throw new Error('Offer not found');
        }
        return offer;
    } catch (error) {
        // If API fails, try to find in local offers
        const localOffer = localOffers.find((o)=>o.id === id);
        if (localOffer) return localOffer;
        return thunkAPI.rejectWithValue(error.message);
    }
});
const offersSlice = (0, __TURBOPACK__imported__module__$5b$externals$5d2f40$reduxjs$2f$toolkit__$5b$external$5d$__$2840$reduxjs$2f$toolkit$2c$__esm_import$29$__["createSlice"])({
    name: 'offers',
    initialState: {
        items: [],
        itemsLoading: false,
        itemsError: null,
        selectedOffer: null,
        selectedOfferLoading: false,
        selectedOfferError: null
    },
    reducers: {
        // You can add any manual reducers here if needed
        clearSelectedOffer: (state)=>{
            state.selectedOffer = null;
            state.selectedOfferLoading = false;
            state.selectedOfferError = null;
        }
    },
    extraReducers: (builder)=>{
        builder// fetchOffers
        .addCase(fetchOffers.pending, (state)=>{
            state.itemsLoading = true;
            state.itemsError = null;
        }).addCase(fetchOffers.fulfilled, (state, action)=>{
            state.itemsLoading = false;
            state.items = action.payload;
        }).addCase(fetchOffers.rejected, (state, action)=>{
            state.itemsLoading = false;
            state.itemsError = action.payload;
        })// fetchOfferById
        .addCase(fetchOfferById.pending, (state)=>{
            state.selectedOfferLoading = true;
            state.selectedOfferError = null;
        }).addCase(fetchOfferById.fulfilled, (state, action)=>{
            state.selectedOfferLoading = false;
            state.selectedOffer = action.payload;
        }).addCase(fetchOfferById.rejected, (state, action)=>{
            state.selectedOfferLoading = false;
            state.selectedOfferError = action.payload;
        });
    }
});
const { clearSelectedOffer } = offersSlice.actions;
const __TURBOPACK__default__export__ = offersSlice.reducer;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/store/rootReducer.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, a: __turbopack_async_module__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$redux__$5b$external$5d$__$28$redux$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/redux [external] (redux, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$slices$2f$services$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/store/slices/services.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$slices$2f$doctor$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/store/slices/doctor.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$slices$2f$devices$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/store/slices/devices.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$slices$2f$branches$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/store/slices/branches.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$slices$2f$offers$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/store/slices/offers.js [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$slices$2f$services$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__,
    __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$slices$2f$doctor$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__,
    __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$slices$2f$devices$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__,
    __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$slices$2f$branches$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__,
    __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$slices$2f$offers$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__
]);
([__TURBOPACK__imported__module__$5b$project$5d2f$store$2f$slices$2f$services$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__, __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$slices$2f$doctor$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__, __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$slices$2f$devices$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__, __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$slices$2f$branches$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__, __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$slices$2f$offers$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
;
;
;
;
;
const rootReducer = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$redux__$5b$external$5d$__$28$redux$2c$__cjs$29$__["combineReducers"])({
    services: __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$slices$2f$services$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"],
    teams: __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$slices$2f$doctor$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"],
    devices: __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$slices$2f$devices$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"],
    branches: __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$slices$2f$branches$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"],
    offers: __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$slices$2f$offers$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"]
});
const __TURBOPACK__default__export__ = rootReducer;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/store/presistConfig.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$redux$2d$persist$2f$lib$2f$storage$2f$index$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/redux-persist/lib/storage/index.js [ssr] (ecmascript)");
;
const persistConfig = {
    key: "root",
    storage: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$redux$2d$persist$2f$lib$2f$storage$2f$index$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"],
    whitelist: [
        "services"
    ]
};
const __TURBOPACK__default__export__ = persistConfig;
}}),
"[project]/store/index.js [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, a: __turbopack_async_module__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_context__.s({
    "persistor": (()=>persistor),
    "store": (()=>store)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$redux__$5b$external$5d$__$28$redux$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/redux [external] (redux, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$redux$2d$thunk__$5b$external$5d$__$28$redux$2d$thunk$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/redux-thunk [external] (redux-thunk, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$redux$2d$persist__$5b$external$5d$__$28$redux$2d$persist$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/redux-persist [external] (redux-persist, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$redux$2d$persist$2f$lib$2f$storage$2f$index$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/redux-persist/lib/storage/index.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$rootReducer$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/store/rootReducer.js [ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$presistConfig$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/store/presistConfig.js [ssr] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$rootReducer$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__
]);
([__TURBOPACK__imported__module__$5b$project$5d2f$store$2f$rootReducer$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
;
;
;
;
;
const persistedReducer = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$redux$2d$persist__$5b$external$5d$__$28$redux$2d$persist$2c$__cjs$29$__["persistReducer"])(__TURBOPACK__imported__module__$5b$project$5d2f$store$2f$presistConfig$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$rootReducer$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"]);
const composeEnhancers = ("TURBOPACK compile-time falsy", 0) ? ("TURBOPACK unreachable", undefined) : __TURBOPACK__imported__module__$5b$externals$5d2f$redux__$5b$external$5d$__$28$redux$2c$__cjs$29$__["compose"];
const store = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$redux__$5b$external$5d$__$28$redux$2c$__cjs$29$__["createStore"])(persistedReducer, composeEnhancers((0, __TURBOPACK__imported__module__$5b$externals$5d2f$redux__$5b$external$5d$__$28$redux$2c$__cjs$29$__["applyMiddleware"])(__TURBOPACK__imported__module__$5b$externals$5d2f$redux$2d$thunk__$5b$external$5d$__$28$redux$2d$thunk$2c$__cjs$29$__["default"])));
const persistor = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$redux$2d$persist__$5b$external$5d$__$28$redux$2d$persist$2c$__cjs$29$__["persistStore"])(store);
;
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/pages/_app.tsx [ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, a: __turbopack_async_module__ } = __turbopack_context__;
__turbopack_async_module__(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {
__turbopack_context__.s({
    "default": (()=>App)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$redux__$5b$external$5d$__$28$react$2d$redux$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react-redux [external] (react-redux, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$index$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/store/index.js [ssr] (ecmascript)"); // Adjust path
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$index$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__
]);
([__TURBOPACK__imported__module__$5b$project$5d2f$store$2f$index$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__);
;
;
;
;
;
;
function App({ Component, pageProps }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$externals$5d2f$react$2d$redux__$5b$external$5d$__$28$react$2d$redux$2c$__cjs$29$__["Provider"], {
        store: __TURBOPACK__imported__module__$5b$project$5d2f$store$2f$index$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["store"],
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(Component, {
            ...pageProps
        }, void 0, false, {
            fileName: "[project]/pages/_app.tsx",
            lineNumber: 12,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/pages/_app.tsx",
        lineNumber: 11,
        columnNumber: 5
    }, this);
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/node_modules/redux-persist/lib/storage/getStorage.js [ssr] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
exports.__esModule = true;
exports.default = getStorage;
function _typeof(obj) {
    if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
        _typeof = function _typeof(obj) {
            return typeof obj;
        };
    } else {
        _typeof = function _typeof(obj) {
            return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
        };
    }
    return _typeof(obj);
}
function noop() {}
var noopStorage = {
    getItem: noop,
    setItem: noop,
    removeItem: noop
};
function hasStorage(storageType) {
    if ((typeof self === "undefined" ? "undefined" : _typeof(self)) !== 'object' || !(storageType in self)) {
        return false;
    }
    try {
        var storage = self[storageType];
        var testKey = "redux-persist ".concat(storageType, " test");
        storage.setItem(testKey, 'test');
        storage.getItem(testKey);
        storage.removeItem(testKey);
    } catch (e) {
        if ("TURBOPACK compile-time truthy", 1) console.warn("redux-persist ".concat(storageType, " test failed, persistence will be disabled."));
        return false;
    }
    return true;
}
function getStorage(type) {
    var storageType = "".concat(type, "Storage");
    if (hasStorage(storageType)) return self[storageType];
    else {
        if ("TURBOPACK compile-time truthy", 1) {
            console.error("redux-persist failed to create sync storage. falling back to noop storage.");
        }
        return noopStorage;
    }
}
}}),
"[project]/node_modules/redux-persist/lib/storage/createWebStorage.js [ssr] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
exports.__esModule = true;
exports.default = createWebStorage;
var _getStorage = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/redux-persist/lib/storage/getStorage.js [ssr] (ecmascript)"));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function createWebStorage(type) {
    var storage = (0, _getStorage.default)(type);
    return {
        getItem: function getItem(key) {
            return new Promise(function(resolve, reject) {
                resolve(storage.getItem(key));
            });
        },
        setItem: function setItem(key, item) {
            return new Promise(function(resolve, reject) {
                resolve(storage.setItem(key, item));
            });
        },
        removeItem: function removeItem(key) {
            return new Promise(function(resolve, reject) {
                resolve(storage.removeItem(key));
            });
        }
    };
}
}}),
"[project]/node_modules/redux-persist/lib/storage/index.js [ssr] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
exports.__esModule = true;
exports.default = void 0;
var _createWebStorage = _interopRequireDefault(__turbopack_context__.r("[project]/node_modules/redux-persist/lib/storage/createWebStorage.js [ssr] (ecmascript)"));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
var _default = (0, _createWebStorage.default)('local');
exports.default = _default;
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__c0a23fd5._.js.map