module.exports = {

"[externals]/web-vitals [external] (web-vitals, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("web-vitals", () => require("web-vitals"));

module.exports = mod;
}}),

};