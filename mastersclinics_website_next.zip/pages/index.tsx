// Update the import path below to the correct location of HomePage
import HomePage from "../helpers/main-component/HomePage/HomePage";

export default function Home() {
  return <HomePage />
}
